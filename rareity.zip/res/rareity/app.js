/****************************************************************
* rareity version 1.1
* 6200 lines 2018-08-10
****************************************************************/
var dialogbox;
var actalarm;
var prayalarm;
var fajralarm;
var welcomeaudio;
var tinyready  = false;

$(document).ready(
    function () {
        activtytemplate.init();
        pageaction.pageprep();
        $('#scrollcontainer').scrollLeft(pageaction.totalwidth);
        $('#scrollcontainer').on('scroll',function(event){
            $('#hourheader').css('left',(0-$('#scrollcontainer')[0].scrollLeft));
            $('.theday').css('left',$('#scrollcontainer')[0].scrollLeft);
        });
        pageaction.init();
        
        actalarm = new Audio();
        actalarm.src = actalarmurl;
        
        prayalarm = new Audio();
        prayalarm.src = prayalarmurl;
        
        fajralarm = new Audio();
        fajralarm.src = fajralarmurl;
    }
);
var pagevar = {
    wasedited:false,
    gotonow:false,
    defaultviewmode:'weekly',
    priostyle:['one','two','three','four','five','six','seven','eight','nine','ten'],
    contentheight:0,
    theboxheight:0,
    theboxwidth:0,
    thenodesize:0,
    cact:false,
    cscrolled:0,
    thedaywidth:0,
    thetime:false,
    startdates:[],
    enddates:[],
    calendaridx:0,
    calendar:[],
    activities:[],
    activtype:[],
    adeactivtype:[],
    newactiv:false,
    gotocalendar:[],
    gotocalendaridx:0,
    gotomode:false,
    activityinedit:false,
    reviewedactivity:false,
    cacttimer:false,
    clocktimer:false,
    debug:false,
    viewgoto:function(time,range){
        for(var o=0;o<this.gotocalendar.length;o++){
            for(var i=0;i<this.gotocalendar[o].time.length;i++){
                if(this.gotocalendar[o].time[i]==time && this.gotocalendar[o].range[i]==range){
                    dialogbox.close();
                    this.gotocalendaridx=o;
                    this.gotocalendar[o].cpage = i;
                    this.displaygoto();
                    return this.gotocalendaridx;
                }   
            }
        }
        return false;
    },
    displaygoto:function(){
        pageaction.loadingpage(true);
        $('#scrollcontainer').html(this.gotocalendar[this.gotocalendaridx].pagelayout[this.gotocalendar[this.gotocalendaridx].cpage]);
        pageaction.pageprep();
        setTimeout(function(){
            pagevar.drawgotocalendar();
        },10);
    },
    drawgotocalendar:function(){
        for(var p=0;p<this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage].length;p++){
            this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][p].drawcalendar();
        }
        console.log('drawgotocalendar');
        this.gotomode=true;
        $('#currenttime').addClass('gotomode');
        pagevar.updatecact();
        mboxloading.unload();
        pageaction.pageprep();
        pageaction.pageloaded();
    },
    addgotopage:function(msg){
        this.gotocalendaridx = this.gotocalendar.length;
        this.gotocalendar[this.gotocalendaridx] = [];
        this.gotocalendar[this.gotocalendaridx].cpage = 0;
        this.gotocalendar[this.gotocalendaridx].time = [];
        this.gotocalendar[this.gotocalendaridx].time[this.gotocalendar[this.gotocalendaridx].cpage] = msg.time;
        this.gotocalendar[this.gotocalendaridx].timeend = [];
        this.gotocalendar[this.gotocalendaridx].timeend[this.gotocalendar[this.gotocalendaridx].cpage] = $('.theday').eq($('.theday').length-1).find('.tablecell').html().split('<br>')[1];
        this.gotocalendar[this.gotocalendaridx].range   = [];
        this.gotocalendar[this.gotocalendaridx].range[this.gotocalendar[this.gotocalendaridx].cpage]= msg.range;
        this.gotocalendar[this.gotocalendaridx].pagelayout = [];
        this.gotocalendar[this.gotocalendaridx].pagelayout[this.gotocalendar[this.gotocalendaridx].cpage] = msg.pagecontent;
        
        this.gotocalendar[this.gotocalendaridx].activities = [];
        this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage] = [];
        for(var i=0;i<msg.activities.length;i++){
            this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage].length] = new activity(msg.activities[i]);
            this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage].length-1].drawcalendar();
        }
        this.gotomode=true;
        $('#currenttime').addClass('gotomode');
        pagevar.updatecact();
        mboxloading.unload();
        pageaction.pageprep();
        pageaction.pageloaded();
    },
    gotoforward:function(){
        if(this.gotocalendar[this.gotocalendaridx].cpage == this.gotocalendar[this.gotocalendaridx].time.length-1){
            var time = this.gotocalendar[this.gotocalendaridx].time[this.gotocalendar[this.gotocalendaridx].cpage];
            var range = this.gotocalendar[this.gotocalendaridx].range[this.gotocalendar[this.gotocalendaridx].cpage];
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'activityc',a:'gotoforward',d:{time:time,range:range}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                $('#scrollcontainer').html(msg.pagecontent);
                
                pagevar.gotofo(msg);
                
                pageaction.pageprep();
                dialogbox.close();
                pageaction.pageloaded();
            });
        }
        else{
            this.gotocalendar[this.gotocalendaridx].cpage++;
            this.displaygoto();
        }        
    },
    gotofo:function(msg){
        this.gotocalendar[this.gotocalendaridx].cpage++;
        this.gotocalendar[this.gotocalendaridx].time[this.gotocalendar[this.gotocalendaridx].cpage] = msg.time;
        this.gotocalendar[this.gotocalendaridx].timeend[this.gotocalendar[this.gotocalendaridx].cpage] = $('.theday').eq($('.theday').length-1).find('.tablecell').html().split('<br>')[1];
        this.gotocalendar[this.gotocalendaridx].range[this.gotocalendar[this.gotocalendaridx].cpage]= msg.range;
        this.gotocalendar[this.gotocalendaridx].pagelayout[this.gotocalendar[this.gotocalendaridx].cpage] = msg.pagecontent;
        this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage] = [];
        for(var i=0;i<msg.activities.length;i++){
            this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage].length] = new activity(msg.activities[i]);
            this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage].length-1].drawcalendar();
        }
        this.gotomode=true;
        $('#currenttime').addClass('gotomode');
        pagevar.updatecact();
        mboxloading.unload();
        pageaction.pageprep();
        pageaction.pageloaded();
    },
    gotoback:function(msg){
        this.gotocalendar[this.gotocalendaridx].cpage=0;
        this.gotocalendar[this.gotocalendaridx].time.unshift('');
        this.gotocalendar[this.gotocalendaridx].timeend.unshift('');
        this.gotocalendar[this.gotocalendaridx].range.unshift('');
        this.gotocalendar[this.gotocalendaridx].pagelayout.unshift('');
        this.gotocalendar[this.gotocalendaridx].activities.unshift('');
        
        this.gotocalendar[this.gotocalendaridx].time[this.gotocalendar[this.gotocalendaridx].cpage] = msg.time;
        this.gotocalendar[this.gotocalendaridx].timeend[this.gotocalendar[this.gotocalendaridx].cpage] = $('.theday').eq($('.theday').length-1).find('.tablecell').html().split('<br>')[1];
        this.gotocalendar[this.gotocalendaridx].range[this.gotocalendar[this.gotocalendaridx].cpage]= msg.range;
        this.gotocalendar[this.gotocalendaridx].pagelayout[this.gotocalendar[this.gotocalendaridx].cpage] = msg.pagecontent;
        this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage] = [];
        for(var i=0;i<msg.activities.length;i++){
            this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage].length] = new activity(msg.activities[i]);
            this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage].length-1].drawcalendar();
        }
        this.gotomode=true;
        $('#currenttime').addClass('gotomode');
        pagevar.updatecact();
        mboxloading.unload();
        pageaction.pageprep();
        pageaction.pageloaded();
    },
    gotobackward:function(){
        if(this.gotocalendar[this.gotocalendaridx].cpage ==0){
            var time = this.gotocalendar[this.gotocalendaridx].time[this.gotocalendar[this.gotocalendaridx].cpage];
            var range = this.gotocalendar[this.gotocalendaridx].range[this.gotocalendar[this.gotocalendaridx].cpage];
            
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'activityc',a:'gotobackward',d:{time:time,range:range}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                $('#scrollcontainer').html(msg.pagecontent);
                
                pagevar.gotoback(msg);
                
                pageaction.pageprep();
                dialogbox.close();
                pageaction.pageloaded();
            });
        }
        else{
            this.debug = true;
            this.gotocalendar[this.gotocalendaridx].cpage--;
            this.displaygoto();
        }
    },
    gotoviewrange:function(){
        return '<option value="view range">view range</option><option value="1">1 month</option><option value="2">1 week</option></option><option value="33">n days</option>';
    },
    setthetime:function(){
        pagevar.thetime.setSeconds(pagevar.thetime.getSeconds()+1);
        $('#currenttime').html(pagevar.thetime.toTimeString().split(' ')[0]);
    },
    scrollintocact:function(){
        if(typeof $('.calitem.startrareity').attr('class') === 'undefined'){
            pageaction.returnscrolled();
            return;
        }
        
        $('#scrollcontainer').scrollLeft(pageaction.totalwidth);
        var startrareity='.calitem.startrareity';
        $(startrareity).eq(0)[0].scrollIntoView();
        if(($(startrareity).eq(0).parent()[0].offsetLeft+$(startrareity).eq(0)[0].offsetLeft) < ($('#dayinaweek').width()-$('body').width()+pagevar.thedaywidth) ){
            $('#scrollcontainer').scrollLeft($('#scrollcontainer')[0].scrollLeft-pagevar.thedaywidth);
        }
        $('#scrollcontainer').scrollTop($(startrareity).eq(0).parent().parent().parent()[0].offsetTop-31);
        
        alarming.setalarm();
    },
    initcact:function(msg){
        pagevar.cact = new activity({id:0,name:"R",description:"start rareity",type:"startrareity",date:msg.currenttime.split(' ')[0],time:msg.currenttime.split(' ')[1],duration:0,priority:5});
        pagevar.addactivity(pagevar.cact);
        this.updatecact();
    },
    updatecact:function(){
        if(typeof $('.calitem.startrareity').attr('class') !=='undefined'){
            $('.calitem.startrareity').remove();
        }
        if(pagevar.cact.date != pagevar.getNow()){
            pagevar.reloadpage(false);
            return;
        }
        pagevar.cact.time = pagevar.thetime.toTimeString().split(' ')[0];
        pagevar.cact.date = pagevar.getNow();
        pagevar.cact.drawcalendar();
    },
    initnodesize:function(){
        pagevar.thenodesize = $('.calitem.startrareity').eq(0).width();
        viewopts.updatenodesize();
    },
    reloadpage:function(dialogboxmessage){
        var startdate = this.getNow();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'ajax',a:'pagereload',d:{startdate:startdate,viewmode:viewopts.defaultviewmode}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            clearTimeout(pagevar.cacttimer);
            clearInterval(pagevar.clocktimer);
            
            pagevar.startdates  = [];
            pagevar.enddates = [];
            pagevar.calendar = [];
            pagevar.calendaridx = 0;
            pagevar.activities = [];
            
            pagevar.gotomode=false;
            $('#currenttime').removeClass('gotomode');
            
            pagevar.thetime = new Date(Date.parse(msg.currenttimejs));
            pagevar.activtype = msg.activtype;
            pagevar.adeactivtype = msg.adeactivtype;
            
            pagevar.clocktimer = setInterval(pagevar.setthetime,1000);
            
            $('#scrollcontainer').html(msg.pagecontent);
            pageaction.pageprep();
            
            pagevar.fillactivities(msg.activities);
            pageaction.loadingpage();
        
            pagevar.drawcalendar();
            pageaction.pageloaded();
            pagevar.initcact(msg);
            pagevar.initnodesize();
            
            if(dialogboxmessage)
                dialogbox.dispmsg('page updated!',true);
        });
    },
    init:function(){
        var startdate = $('.theday').children().children().eq(0).html().split('<br>');
        startdate = startdate[startdate.length-1];
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'ajax',a:'pagevarinit',d:{startdate:startdate,viewmode:viewopts.defaultviewmode}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            pagevar.thetime = new Date(Date.parse(msg.currenttimejs));
            pagevar.activtype = msg.activtype;
            pagevar.adeactivtype = msg.adeactivtype;
            
            pagevar.clocktimer = setInterval(pagevar.setthetime,1000);
            
            pagevar.calendaridx = 0;
            pagevar.fillactivities(msg.activities);
            pageaction.loadingpage();
            
            if(typeof msg.pagecontent !=='undefined'){
                $('#scrollcontainer').html(msg.pagecontent);
                //pageaction.pageprep();
            }
            
                pagevar.drawcalendar();
                pagevar.initcact(msg);
                pagevar.initnodesize();
        });
    },
    resetforward:function(){
        if(this.gotomode){
            var temptemp = this.gotocalendar[this.gotocalendaridx];
            this.gotocalendar = [];
            this.gotocalendaridx = 0;
            this.gotocalendar[this.gotocalendaridx] = temptemp;
            
            for(var t=(this.gotocalendar[this.gotocalendaridx].cpage+1);t<this.gotocalendar[this.gotocalendaridx].activities.length;t++){
                this.gotocalendar[this.gotocalendaridx].activities.splice(t,1);
                this.gotocalendar[this.gotocalendaridx].time.splice(t,1);
                this.gotocalendar[this.gotocalendaridx].timeend.splice(t,1);
                this.gotocalendar[this.gotocalendaridx].range.splice(t,1);
                this.gotocalendar[this.gotocalendaridx].pagelayout.splice(t,1);
                
                t--;
            }
            
            
            this.startdates = [];
            this.calendar = [];
            this.activities = [];
              
        }
        else{
            for(var i=(this.calendaridx+1);i<this.activities.length;i++){
                this.startdates.splice(i,this.activities.length-(this.calendaridx+1));
                this.calendar.splice(i,this.activities.length-(this.calendaridx+1));
                this.activities.splice(i,this.activities.length-(this.calendaridx+1));
                
                break;
            }   
            
            this.gotocalendar = [];
            this.gotocalendaridx = 0;
        }
    },
    deleterecurring:function(parentid){
        for(var t=0;t<this.gotocalendar.length;t++){
            for(var i=0;i<this.gotocalendar[t].time.length;i++){
                for(var o=0;o<this.gotocalendar[t].activities[i].length;o++){
                    if(this.gotocalendar[t].activities[i][o].parentactivity==parentid){
                        if(typeof $('#calitem_'+this.gotocalendar[t].activities[i][o].id).attr('class') !=='undefined')
                            $('#calitem_'+this.gotocalendar[t].activities[i][o].id).remove();
                        if(typeof $('#calitemnextday_'+this.gotocalendar[t].activities[i][o].id).attr('class') !=='undefined')
                            $('#calitemnextday_'+this.gotocalendar[t].activities[i][o].id).remove();
                            
                            
                        parentid = this.gotocalendar[t].activities[i][o].id;
                        this.gotocalendar[t].activities[i].splice(o,1);
                        o--;
                    }   
                }
            }   
        }
        
        for(var e=0;e<this.activities[this.calendaridx].length;e++){
            if(this.activities[this.calendaridx][e].parentactivity == parentid){
                if(typeof $('#calitem_'+this.activities[this.calendaridx][e].id).attr('class') !=='undefined')
                    $('#calitem_'+this.activities[this.calendaridx][e].id).remove();
                    
                parentid = this.activities[this.calendaridx][e].id;
                this.activities[this.calendaridx].splice(e,1);
                e--;
            }
        }
    },
    gotocheckactpos:function(acte,checkdate){
        var id=acte.id
        var inrange;
        var inrange2;
        var st;
        var et;
        var tmp;
        var spliced;
        for(var i=0;i<this.gotocalendar.length;i++){
            tmp = this.gotocalendar[i].time[0].split('-');
            st = new Date(tmp[0],(parseInt(tmp[1])-1),tmp[2]);
            tmp = this.gotocalendar[i].timeend[this.gotocalendar[i].timeend.length-1].split('-');
            et = new Date(tmp[0],(parseInt(tmp[1])-1),tmp[2]);
            
            inrange = (checkdate >=st && checkdate <= et) ? true : false;
            if(inrange){
                for(var t=0;t<this.gotocalendar[i].time.length;t++){
                    tmp = this.gotocalendar[i].time[t].split('-');
                    st = new Date(tmp[0],(parseInt(tmp[1])-1),tmp[2]);
                    tmp = this.gotocalendar[i].timeend[t].split('-');
                    et = new Date(tmp[0],(parseInt(tmp[1])-1),tmp[2]);
                    
                    inrange2 = (checkdate >=st && checkdate <= et) ? true : false;
                    if(!inrange2){
                        for(var o=0;o<this.gotocalendar[i].activities[t].length;o++){
                            if(this.gotocalendar[i].activities[t][o].id==id){
                                this.gotocalendar[i].activities[t].splice(o,1);
                                break;
                            }
                        }   
                    }
                    else{
                        var exists = false;
                        for(var o=0;o<this.gotocalendar[i].activities[t].length;o++){
                            if(this.gotocalendar[i].activities[t][o].id==id){
                                this.gotocalendar[i].activities[t][o] = acte;
                                exists = o;
                                break;
                            }
                        }   
                        
                        if(exists===false){
                            this.gotocalendar[i].activities[t][this.gotocalendar[i].activities[t].length] = acte;
                        }
                    }
                }
            }
            else{
                for(var t=0;t<this.gotocalendar[i].time.length;t++){
                    for(var o=0;o<this.gotocalendar[i].activities[t].length;o++){
                        if(this.gotocalendar[i].activities[t][o].id==id){
                            this.gotocalendar[i].activities[t].splice(o,1);
                            
                            break;
                        }
                    }
                }
            }
        }
    },
    checkactpos:function(acte){
        var checkdate=acte.date;
        checkdate = new Date(checkdate.split('-')[0],parseInt(checkdate.split('-')[1])-1,checkdate.split('-')[2]);
        this.gotocheckactpos(acte,checkdate);
        if(!this.gotomode){
            var sd = new Date(this.startdates[this.calendaridx].split('-')[0],(parseInt(this.startdates[this.calendaridx].split('-')[1])-1),this.startdates[this.calendaridx].split('-')[2]);
            var ed = new Date(this.enddates[this.calendaridx].split('-')[0],(parseInt(this.enddates[this.calendaridx].split('-')[1])-1),this.enddates[this.calendaridx].split('-')[2]);
            
            if(checkdate >= sd && checkdate <=ed){
                for(var e=0;e<this.activities[this.calendaridx].length;e++){
                    if(this.activities[this.calendaridx][e].id == acte.id){
                        this.activities[this.calendaridx][e] = acte;
                        break;
                    }
                }
                return true;
            }
            for(var e=0;e<this.activities[this.calendaridx].length;e++){
                if(this.activities[this.calendaridx][e].id == acte.id){
                    this.activities[this.calendaridx].splice(e,1);
                    break;
                }
            }
            for(var e=0;e<this.activities.length;e++){
                if(e!=this.calendaridx){
                    sd = new Date(this.startdates[e].split('-')[0],(parseInt(this.startdates[e].split('-')[1])-1),this.startdates[e].split('-')[2]);
                    ed = new Date(this.enddates[e].split('-')[0],(parseInt(this.enddates[e].split('-')[1])-1),this.enddates[e].split('-')[2]);
                    if(checkdate >= sd && checkdate <=ed){
                        this.activities[e][this.activities[e].length] = acte;
                    }
                }
            }
            return false;
        }
        else{
            for(var e=0;e<this.activities.length;e++){
                sd = new Date(this.startdates[e].split('-')[0],(parseInt(this.startdates[e].split('-')[1])-1),this.startdates[e].split('-')[2]);
                ed = new Date(this.enddates[e].split('-')[0],(parseInt(this.enddates[e].split('-')[1])-1),this.enddates[e].split('-')[2]);
                if(checkdate >= sd && checkdate <=ed){
                    var exists=false;
                    for(var l=0;l<this.activities[e].length;l++){
                        if(this.activities[e][l].id==acte.id){
                            this.activities[e][l]=acte;
                            exists=l;
                            break;
                        }
                    }
                    if(exists===false){
                        this.activities[e][this.activities[e].length] = acte;
                    }
                }
                else{
                    for(var l=0;l<this.activities[e].length;l++){
                        if(this.activities[e][l].id==acte.id){
                            this.activities[e].splice(l,1);
                            break;
                        }
                    }
                }
            }
        }
    },
    updateactivity:function(weekly){
        for(var w=0;w<weekly.length;w++){
            weekly[w].id = parseInt(weekly[w].id);
            weekly[w] = new activity(weekly[w]);
            if(typeof $('#calitem_'+weekly[w].id).attr('id') !=='undefined')
                $('#calitem_'+weekly[w].id).remove();
            if(typeof $('#calitemnextday_'+weekly[w].id).attr('id') !=='undefined')
                $('#calitemnextday_'+weekly[w].id).remove(); 
                
                
            weekly[w].drawcalendar();
            inpage = true;
            
            
            if(this.gotocalendar.length)
            for(var t=0;t<this.gotocalendar.length;t++){
                for(var i=0;i<this.gotocalendar[t].time.length;i++){
                    for(var o=0;o<this.gotocalendar[t].activities[i].length;o++){
                        if(this.gotocalendar[t].activities[i][o].id==weekly[w].id){
                            inpage=false;
                            this.gotocalendar[t].activities[i][o] = weekly[w];
                        }   
                    }
                }   
            }
            
            
            if(typeof this.activities[this.calendaridx] !== 'undefined')
            for(var e=0;e<this.activities[this.calendaridx].length;e++){
                if(this.activities[this.calendaridx][e].id == weekly[w].id){
                    inpage=false;
                    this.activities[this.calendaridx][e] = weekly[w];
                }
            }
            if(inpage){
                this.addactivity(weekly[w]);
            }
        }
    },
    fillactivities:function(act){
        this.startdates[this.calendaridx]   = $('.theday').eq(0).find('.tablecell').html().split('<br>')[1];
        this.enddates[this.calendaridx]     = $('.theday').eq($('.theday').length-1).find('.tablecell').html().split('<br>')[1];
        this.calendar[this.calendaridx]     = $('#scrollcontainer').html();
        this.activities[this.calendaridx]   = [];
        for(var i=0;i<act.length;i++){
            this.activities[this.calendaridx][this.activities[this.calendaridx].length] = new activity(act[i]);
        }
    },
    currentstartdate:function(){
        return this.startdates[this.calendaridx];
    },
    addgotoactivity:function(act){
        var checkdate = act.date.split('-');
        checkdate = new Date(checkdate[0],parseInt(checkdate[1])-1,checkdate[2]);
        var inrange;
        var st;
        var et;
        var tmp;
        for(var i=0;i<this.gotocalendar.length;i++){
            tmp = this.gotocalendar[i].time[0].split('-');
            st = new Date(tmp[0],(parseInt(tmp[1])-1),tmp[2]);
            tmp = this.gotocalendar[i].timeend[this.gotocalendar[i].timeend.length-1].split('-');
            et = new Date(tmp[0],(parseInt(tmp[1])-1),tmp[2]);
            
            inrange = (checkdate >=st && checkdate <= et) ? true : false;
            if(inrange){
                for(var t=0;t<this.gotocalendar[i].time.length;t++){
                    tmp = this.gotocalendar[i].time[t].split('-');
                    st = new Date(tmp[0],(parseInt(tmp[1])-1),tmp[2]);
                    tmp = this.gotocalendar[i].timeend[t].split('-');
                    et = new Date(tmp[0],(parseInt(tmp[1])-1),tmp[2]);
                    
                    inrange = (checkdate >=st && checkdate <= et) ? true : false;
                    if(inrange){
                        this.gotocalendar[i].activities[t][this.gotocalendar[i].activities[t].length] = act;
                        break;
                    }
                }
            }
        }
    },
    addnormalactivity:function(act){
        var st;
        var et;
        var checkdate = act.date.split('-');
        checkdate = new Date(checkdate[0],parseInt(checkdate[1])-1,checkdate[2]);
        
        for(var t=0;t<this.activities.length;t++){
            st=this.startdates[t].split('-');
            et=this.enddates[t].split('-'); 
            st = new Date(st[0],(parseInt(st[1])-1),st[2]);
            et = new Date(et[0],(parseInt(et[1])-1),et[2]);
            
            if(checkdate >=st && checkdate <= et){
                this.activities[t][this.activities[t].length] = act;
                break;
            }
        }
    },
    addactivity:function(act){
        if(this.gotomode){
            this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage].length] = act;
            this.addnormalactivity(act);
            return;
        }
        this.activities[this.calendaridx][this.activities[this.calendaridx].length] = act;
        this.addgotoactivity(act);
    },
    deleteactivityoftype:function(type){
        for(var t=0;t<this.gotocalendar.length;t++){
            for(var i=0;i<this.gotocalendar[t].time.length;i++){
                for(var o=0;o<this.gotocalendar[t].activities[i].length;o++){
                    if(this.gotocalendar[t].activities[i][o].type==type){
                        if(typeof $('#calitem_'+this.gotocalendar[t].activities[i][o].id).attr('class') !== 'undefined')
                            $('#calitem_'+this.gotocalendar[t].activities[i][o].id).remove();
                        if(typeof $('#calitemnextday_'+this.gotocalendar[t].activities[i][o].id).attr('class') !== 'undefined')
                            $('#calitemnextday_'+this.gotocalendar[t].activities[i][o].id).remove();
                        if(typeof $('#ade_'+this.gotocalendar[t].activities[i][o].id).attr('class') !== 'undefined'){
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).removeClass(type);
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).removeClass('alldayevent');
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).css('background','');
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).find('.addadeactiv').css('display','');
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).prop('id','');
                        }
                            
                        this.gotocalendar[t].activities[i].splice(o,1) ;
                        o--;
                    }
                }
            }   
        }
        
        for(var i=0;i<this.activities[this.calendaridx].length;i++){
            if(this.activities[this.calendaridx][i].type==type){
                if(typeof $('#calitem_'+this.activities[this.calendaridx][i].id).attr('class') !== 'undefined')
                    $('#calitem_'+this.activities[this.calendaridx][i].id).remove();
                if(typeof $('#calitemnextday_'+this.activities[this.calendaridx][i].id).attr('class') !== 'undefined')
                    $('#calitemnextday_'+this.activities[this.calendaridx][i].id).remove();
                if(typeof $('#ade_'+this.activities[this.calendaridx][i].id).attr('class') !== 'undefined'){
                    $('#ade_'+this.activities[this.calendaridx][i].id).removeClass(type);
                    $('#ade_'+this.activities[this.calendaridx][i].id).removeClass('alldayevent');
                    $('#ade_'+this.activities[this.calendaridx][i].id).css('background','');
                    $('#ade_'+this.activities[this.calendaridx][i].id).find('.addadeactiv').css('display','');
                    $('#ade_'+this.activities[this.calendaridx][i].id).prop('id','');
                }
                        
                this.activities[this.calendaridx].splice(i,1) ;
                i--;
            }
        }
    },
    deleteactivity:function(id){
        var todel = [];
        todel[todel.length] = parseInt(id);
        for(var t=0;t<this.gotocalendar.length;t++){
            for(var i=0;i<this.gotocalendar[t].time.length;i++){
                for(var o=0;o<this.gotocalendar[t].activities[i].length;o++){
                    if($.inArray(parseInt(this.gotocalendar[t].activities[i][o].id),todel) !== -1){
                        if(typeof $('#calitem_'+this.gotocalendar[t].activities[i][o].id).attr('class') !=='undefined')
                            $('#calitem_'+this.gotocalendar[t].activities[i][o].id).remove();
                        if(typeof $('#calitemnextday_'+this.gotocalendar[t].activities[i][o].id).attr('class') !=='undefined')
                            $.each($('#scrollcontainer').find('.calitemnextday_'+this.gotocalendar[t].activities[i][o].id),function(fi,fe){
                                $(fe).remove();
                            });
                        if(typeof $('#ade_'+this.gotocalendar[t].activities[i][o].id).attr('class') !=='undefined'){
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).removeClass(this.gotocalendar[t].activities[i][o].type);
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).removeClass('alldayevent');
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).css('background','');
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).find('.addadeactiv').css('display','');
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).prop('id','');
                        }
                        
                        this.gotocalendar[t].activities[i].splice(o,1) ;
                        o--;
                    }
                    else if((this.gotocalendar[t].activities[i][o].parentactivity != 0 && $.inArray(parseInt(this.gotocalendar[t].activities[i][o].parentactivity),todel) !== -1)){
                        if(typeof $('#calitem_'+this.gotocalendar[t].activities[i][o].id).attr('class') !=='undefined')
                            $('#calitem_'+this.gotocalendar[t].activities[i][o].id).remove();
                        if(typeof $('#calitemnextday_'+this.gotocalendar[t].activities[i][o].id).attr('class') !=='undefined')
                            $.each($('#scrollcontainer').find('.calitemnextday_'+this.gotocalendar[t].activities[i][o].id),function(fi,fe){
                                $(fe).remove();
                            });
                        if(typeof $('#ade_'+this.gotocalendar[t].activities[i][o].id).attr('class') !=='undefined'){
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).removeClass(this.gotocalendar[t].activities[i][o].type);
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).removeClass('alldayevent');
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).css('background','');
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).find('.addadeactiv').css('display','');
                            $('#ade_'+this.gotocalendar[t].activities[i][o].id).prop('id','');
                        }
                        todel[todel.length] = parseInt(this.gotocalendar[t].activities[i][o].id);
                        
                        this.gotocalendar[t].activities[i].splice(o,1) ;
                        o--;
                    }
                }
            }   
        }
        
        for(var p=this.calendaridx;p<this.activities.length;p++){
            for(var i=0;i<this.activities[p].length;i++){
                if($.inArray(parseInt(this.activities[p][i].id),todel) !== -1){
                    if(typeof $('#calitem_'+this.activities[p][i].id).attr('class') !=='undefined')
                        $('#calitem_'+this.activities[p][i].id).remove();
                    if(typeof $('#calitemnextday_'+this.activities[p][i].id).attr('class') !=='undefined')
                        $.each($('#scrollcontainer').find('.calitemnextday_'+this.activities[p][i].id),function(fi,fe){
                            $(fe).remove();
                        });
                    if(typeof $('#ade_'+this.activities[p][i].id).attr('class') !=='undefined'){
                        $('#ade_'+this.activities[p][i].id).removeClass(this.gotocalendar[t].activities[i][o].type);
                        $('#ade_'+this.activities[p][i].id).removeClass('alldayevent');
                        $('#ade_'+this.activities[p][i].id).css('background','');
                        $('#ade_'+this.activities[p][i].id).find('.addadeactiv').css('display','');
                        $('#ade_'+this.activities[p][i].id).prop('id','');
                    }
                        
                    this.activities[p].splice(i,1) ;
                    i--;
                }
                else if((this.activities[p][i].parentactivity!=0 && $.inArray(parseInt(this.activities[p][i].parentactivity),todel) !== -1)){
                    if(typeof $('#calitem_'+this.activities[p][i].id).attr('class') !=='undefined')
                        $('#calitem_'+this.activities[p][i].id).remove();
                    if(typeof $('#calitemnextday_'+this.activities[p][i].id).attr('class') !=='undefined')
                        $.each($('#scrollcontainer').find('.calitemnextday_'+this.activities[p][i].id),function(fi,fe){
                            $(fe).remove();
                        });
                    if(typeof $('#ade_'+this.activities[p][i].id).attr('class') !=='undefined'){
                        $('#ade_'+this.activities[p][i].id).removeClass(this.gotocalendar[t].activities[i][o].type);
                        $('#ade_'+this.activities[p][i].id).removeClass('alldayevent');
                        $('#ade_'+this.activities[p][i].id).css('background','');
                        $('#ade_'+this.activities[p][i].id).find('.addadeactiv').css('display','');
                        $('#ade_'+this.activities[p][i].id).prop('id','');
                    }
                    
                    todel[todel.length] = parseInt(this.activities[p][i].id);
                        
                    this.activities[p].splice(i,1) ;
                    i--;
                }
            }   
        }
    },
    rarifyrecurring:function(thisact){
        for(var t=0;t<this.gotocalendar.length;t++){
            for(var i=0;i<this.gotocalendar[t].time.length;i++){
                for(var o=0;o<this.gotocalendar[t].activities[i].length;o++){
                    if(this.gotocalendar[t].activities[i][o].id==thisact.parentactivity){
                        this.gotocalendar[t].activities[i][o].recurring=0;
                    }
                }
            }   
        }
        
        for(var t=0;t<this.activities.length;t++){
            for(var i=0;i<this.activities[t].length;i++){
                if(this.activities[t][i].id==thisact.parentactivity){
                    this.activities[t][i].recurring=0;
                    return;
                }
            }   
        }
    },
    resetothermode:function(){
        if(this.gotomode){
            this.startdates = [];
            this.calendar = [];
            this.activities = [];    
            return;
        }
        
            this.gotocalendar = [];
            this.gotocalendaridx = 0;
    },
    adddurationlineonlyact:function(act){
        if(this.gotomode){
            if(typeof this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1] !== 'undefined'){
                this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1][this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1].length] = act;
                
                this.resetothermode(); 
                
            }
            return;
        }
        if(typeof this.activities[this.calendaridx+1] !== 'undefined'){
            this.activities[this.calendaridx+1][this.activities[this.calendaridx+1].length] = act;
                   
            this.resetothermode();
        }
    },
    editdurationlineonlyact:function(tisact){
        if(this.gotomode){
            for(var i=0;i<this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1].length;i++){
                if(this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1][i].id==tisact.id){
                    if(this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1][i].durationlineonly){
                        this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1][i] = new activity(tisact);
                        this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1][i].durationlineonly = true;
                        
                        this.resetothermode();
                        return;
                    }
                }
            }
        }
        for(var i=0;i<this.activities[this.calendaridx+1].length;i++){
            if(this.activities[this.calendaridx+1][i].id==tisact.id){
                if(this.activities[this.calendaridx+1][i].durationlineonly){
                    this.activities[this.calendaridx+1][i] = new activity(tisact);
                    this.activities[this.calendaridx+1][i].durationlineonly = true;
                    
                    this.resetothermode();
                    return;
                }
            }
        }  
    },
    deletedurationlineonly:function(tisact){
        if(this.gotomode){
            for(var i=0;i<this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1].length;i++){
                if(this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1][i].id==tisact.id){
                    if(this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1][i].durationlineonly){
                        this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1].splice(i,1);
                        this.resetothermode();
                        return;
                    }
                }
            }
        }
        for(var i=0;i<this.activities[this.calendaridx+1].length;i++){
            if(this.activities[this.calendaridx+1][i].id==tisact.id){
                if(this.activities[this.calendaridx+1][i].durationlineonly){
                    this.activities[this.calendaridx+1].splice(i,1);
                    this.resetothermode();
                    return;
                }
            }
        } 
    },
    existdurationlineonly:function(id){
        if(this.gotomode){
            if(typeof this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1] !== 'undefined')
            for(var i=0;i<this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1].length;i++){
                if(this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1][i].id==id){
                    if(this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage+1][i].durationlineonly)
                    return true;
                }
            }
            return false;
        }
        
        if(typeof this.activities[this.calendaridx+1] !== 'undefined')
        for(var i=0;i<this.activities[this.calendaridx+1].length;i++){
            if(this.activities[this.calendaridx+1][i].id==id){
                if(this.activities[this.calendaridx+1][i].durationlineonly)
                    return true;
            }
        }   
        return false;
    },
    getactivityforreview:function(id){
        if(this.gotomode){
            for(var i=0;i<this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage].length;i++){
                if(this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][i].id==id){
                    this.reviewedactivity = this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][i];
                    return;
                }
            }
        }
        for(var i=0;i<this.activities[this.calendaridx].length;i++){
            if(this.activities[this.calendaridx][i].id==id){
                this.reviewedactivity = this.activities[this.calendaridx][i];
                return;
            }
        }
    },
    getactivitydata:function(id){
        if(this.gotomode){
            for(var t=0;t<this.gotocalendar.length;t++){
                for(var i=0;i<this.gotocalendar[t].time.length;i++){
                    for(var o=0;o<this.gotocalendar[t].activities[i].length;o++){
                        if(this.gotocalendar[t].activities[i][o].id==id){
                            return this.gotocalendar[t].activities[i][o].postdata();
                        }
                    }
                }
            }
        }
        for(var i=0;i<this.activities[this.calendaridx].length;i++){
            if(this.activities[this.calendaridx][i].id==id){
                return this.activities[this.calendaridx][i].postdata();
            }
        }
        for(var p=0;p<this.activities.length;p++){
            if(p!=this.calendaridx)
            for(var i=0;i<this.activities[p].length;i++){
                if(this.activities[p][i].id==id){
                    return this.activities[p][i].postdata();
                }
            }   
        }
        return false;
    },
    getactivity:function(id){
        if(this.gotomode){
            for(var i=0;i<this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage].length;i++){
                if(this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][i].id==id){
                    this.activityinedit = this.gotocalendar[this.gotocalendaridx].activities[this.gotocalendar[this.gotocalendaridx].cpage][i];
                    return;
                }
            }
        }
        for(var i=0;i<this.activities[this.calendaridx].length;i++){
            if(this.activities[this.calendaridx][i].id==id){
                this.activityinedit = this.activities[this.calendaridx][i];
                return;
            }
        }
        
        for(var p=0;p<this.activities.length;p++){
            if(p!=this.calendaridx)
            for(var i=0;i<this.activities[p].length;i++){
                if(this.activities[p][i].id==id){
                    this.activityinedit = this.activities[p][i];
                    return;
                }
            }   
        }
    },
    drawcalendar:function(){
        for(var i=0;i<this.activities[this.calendaridx].length;i++){
            this.activities[this.calendaridx][i].drawcalendar();
        }
        console.log('drawcalendar');
        mboxloading.unload();
        pageaction.pageprep();
        pageaction.pageloaded();
        
        if(!$('.startrareity').length){
            $('#currenttime').addClass('gotomode');
        }
        else{
            $('#currenttime').removeClass('gotomode');
        }
    },
    activtypename:function(type){
        for(var i=0;i<this.activtype.length;i++){
            if(this.activtype[i].id == type){
                return this.activtype[i].name;
            }
        }
        for(var i=0;i<this.adeactivtype.length;i++){
            if(this.adeactivtype[i].id == type){
                return this.adeactivtype[i].name;
            }
        }
        return 'false';
    },
    activitytypeoption:function(ade){
        var opt = '<option value="type">type</option>';
        if((ade!=1440 && ade !='all day') || ade==='all'){
            for(var i=0;i<this.activtype.length;i++){
                opt+='<option value="'+this.activtype[i].id+'">'+this.activtype[i].name+'</option>';
            }
            if(ade!=='all')
                return opt;   
        }
        
        for(var i=0;i<this.adeactivtype.length;i++){
            opt+='<option value="'+this.adeactivtype[i].id+'">'+this.adeactivtype[i].name+'</option>';
        }
        return opt;
    },
    acttypeadderpro:function(ade){
        var opt = '';
        
        if(ade!==true)
        for(var i=0;i<this.activtype.length;i++){
            opt+='<li id="acttypeadderopt_'+this.activtype[i].id+'" class="">'+this.activtype[i].name+'</li>';
        }
        
        if(ade!==false)
        for(var i=0;i<this.adeactivtype.length;i++){
            opt+='<li id="acttypeadderopt_'+this.adeactivtype[i].id+'" class="">'+this.adeactivtype[i].name+'</li>';
        }
        return opt;
    },
    acttypeeditopt:function(tes){
        var opt = '';
        if(tes===true){
            for(var i=0;i<this.activtype.length;i++){
                opt+='<div class="row multiinput bottomed"><span id="atname_'+this.activtype[i].id+'" class="atname">'+this.activtype[i].name+'</span></div>';
            }
            return opt;   
        }
        if(tes===false){
            for(var i=0;i<this.adeactivtype.length;i++){
                opt+='<div class="row multiinput bottomed"><span id="atname_'+this.adeactivtype[i].id+'" class="atname">'+this.adeactivtype[i].name+'</span></div>';
            }
            return opt;  
        }
        
        if(tes==='regularevent'){
            for(var i=0;i<this.activtype.length;i++){
                opt+='<div class="row multiinput bottomed"><span id="atname_'+this.activtype[i].id+'" class="atname">'+this.activtype[i].name+'</span></div>';
            }
            return opt;  
        }
        if(tes==='alldayevent'){
            for(var i=0;i<this.adeactivtype.length;i++){
                opt+='<div class="row multiinput bottomed"><span id="atname_'+this.adeactivtype[i].id+'" class="atname">'+this.adeactivtype[i].name+'</span></div>';
            }
            return opt;  
        }
        
        switch($(tes).attr('id')){
            case 'regularevent':
                for(var i=0;i<this.activtype.length;i++){
                    opt+='<div class="row multiinput bottomed"><span id="atname_'+this.activtype[i].id+'" class="atname">'+this.activtype[i].name+'</span></div>';
                }
            break;
            case 'alldayevent':
                for(var i=0;i<this.adeactivtype.length;i++){
                    opt+='<div class="row multiinput bottomed"><span id="atname_'+this.adeactivtype[i].id+'" class="atname">'+this.adeactivtype[i].name+'</span></div>';
                }
            break;
        }
        return opt;   
    },
    recurringtypestr:function(){
        return '<option value="recurring type">rareity</option><option value="1">yearly</option><option value="2">monthly</option><option value="3">weekly</option>';
    },
    getNow:function(){
        if(this.thetime===false){
            return false;
        }
        return this.thetime.getFullYear()+'-'+this.fixdatestr(this.thetime.getMonth()+1)+'-'+this.fixdatestr(this.thetime.getDate());
    },
    fixdatestr:function(str){
        str+='';
        if(str.length==1){
            str = '0'+str;
        }
        return str;
    }
};

var pageaction = {
    hboxesxy:[],
    cursorpos:[],
    boxmovecandid:false,
    moveabox:function(){
        $(pageaction.boxmovecandid).css('left',(pageaction.cursorpos[0]-($(pageaction.boxmovecandid).width()/2))+'px');
        $(pageaction.boxmovecandid).css('top',(pageaction.cursorpos[1]-($(pageaction.boxmovecandid).height()/2))+'px');
    },
    boxmove:function(elem,event){
        pageaction.cursorpos = [event.clientX,event.clientY];
        
        pageaction.boxmovecandid = elem;
        $(pageaction.boxmovecandid).addClass('mdown');
        $(pageaction.boxmovecandid).on('mouseup',function(event){
            event.stopPropagation();
                if(pageaction.boxmovecandid===false){
                    return;
                }
            $(pageaction.boxmovecandid).removeClass('mdown');
            if($(pageaction.boxmovecandid).attr('class').indexOf('moving')===-1){
                pageaction.detailsofact(pageaction.boxmovecandid);
                pageaction.boxmovecandid = false;
            }
        });
            setTimeout(function(){
                if(pageaction.boxmovecandid===false){
                    return;
                }
                if($(pageaction.boxmovecandid).attr('class').indexOf('mdown') !== -1){
                    $(pageaction.boxmovecandid).removeClass('mdown');
                    $(pageaction.boxmovecandid).addClass('moving');
                    $('.calitemnextday_'+$(pageaction.boxmovecandid).attr('id').split('_')[1]).remove();
                    
                    pageaction.cursorpos = [event.clientX,event.clientY];
                    pageaction.moveabox();
                        
                    $(pageaction.boxmovecandid).on('mousemove',function(event){
                        pageaction.cursorpos = [event.clientX,event.clientY];
                        pageaction.moveabox();
                    });
                    
                    $(pageaction.boxmovecandid).on('mouseup',function(event){
                        pageaction.cursorpos = [event.clientX,event.clientY];
                        pageaction.moveabox();
                        
                        pageaction.dropabox();
                    });
                }
            },1200);
    },
    dropabox:function(){
        pageaction.cursorpos[0] = parseInt(pageaction.cursorpos[0]);
        pageaction.cursorpos[1] = $('#scrollcontainer')[0].scrollTop+parseInt(pageaction.cursorpos[1]);
        
        $(pageaction.boxmovecandid).removeClass('moving');
        var oftop=parseInt($('#hourheader').height());
        
            $.each($('.anhour'),function(ai,ae){
                if($(ae).attr('class').indexOf('header')!==-1){
                    
                }
                else{
                    if((ai-24)%24==0 && ai > 24){
                        oftop=oftop+parseInt(viewopts.boxheight);
                    }
                    pageaction.hboxesxy[pageaction.hboxesxy.length] = [];
                    pageaction.hboxesxy[pageaction.hboxesxy.length-1].elem = ae;
                    pageaction.hboxesxy[pageaction.hboxesxy.length-1].pos = [parseInt(ae.offsetLeft)-$('#scrollcontainer')[0].scrollLeft,oftop]; 
                }
            });
        
        
        for(var p=0;p<pageaction.hboxesxy.length;p++){
            if( (pageaction.cursorpos[0] >= pageaction.hboxesxy[p].pos[0]) &&  (pageaction.cursorpos[0] <= (pageaction.hboxesxy[p].pos[0]+parseInt(viewopts.boxwidth))) ){
                if( (pageaction.cursorpos[1] >= pageaction.hboxesxy[p].pos[1]) && (pageaction.cursorpos[1] <= (pageaction.hboxesxy[p].pos[1]+parseInt(viewopts.boxheight))) ){
                    
                    pageaction.gentlydropthebox(pageaction.boxmovecandid,pageaction.hboxesxy[p].elem);
                    break;
                }
            }
        }
        pageaction.boxmovecandid = false;
        pageaction.hboxesxy = [];
    },
    gentlydropthebox:function(elem,tbox){
        var time = $(tbox).attr('class').split('_')[1];
        time = time.split(' ')[0]+':00:00';
        var date = $(tbox).parent().prev().find('.tablecell').html().split('<br>')[1];
        
        pagevar.getactivity($(elem).attr('id').split('_')[1]);
        pagevar.activityinedit.searchresult = false;
        pagevar.activityinedit.date = date;
        pagevar.activityinedit.time = time;
        $(elem).remove();
        
        pagevar.activityinedit.drawcalendar();
        pagevar.activityinedit.submitedited_();
    },
    loadqueue:[],
    pageloaded:function(){
        if(!this.loadqueue.length){
            $('#pageloading').removeClass('active');
            return;
        }
        
        this.loadqueue.splice(0,1);
        if(!this.loadqueue.length){
            $('#pageloading').removeClass('active');
        }
    },
    loadingpage:function(newlayout){
        if(newlayout){
            this.loadqueue[0] = true;
        }
        else
            this.loadqueue[this.loadqueue.length] = true;
          
        $('#pageloading').addClass('active');
        
        return true;
    },
    backupaweek:function(){
         if(pagevar.calendaridx==0){
            return false;
        }
        
        pagevar.calendaridx--;
        this.displaypage();
        return true;
    },
    forwardaweek:function(){
        if(pagevar.calendaridx==pagevar.activities.length-1){
            return false;
        }

        pagevar.calendaridx++;
        this.displaypage();
        return true;
    },
    displaypage:function(){
        console.log('displaypage');
        $('#scrollcontainer').html(pagevar.calendar[pagevar.calendaridx]);
        pageaction.pageprep();
        pageaction.loadingpage();
        setTimeout(function(){
            pagevar.drawcalendar();
            if(pagevar.gotonow){
                pagevar.gotonow = false;
            }
        },10);
    },
    returnscrolled:function(){
        $('#scrollcontainer')[0].scrollLeft=pagevar.cscrolled;
        $('#hourheader').css('left',(0-pagevar.cscrolled));
        $('.theday').css('left',pagevar.cscrolled);
    },
    totalwidth:0,
    pagesetup:function(){
        console.log('pagesetup');
        this.pageprep();
        $('.calitem').remove();
        $('.nextday').remove();
        
        if(!pagevar.gotomode){
            pagevar.drawcalendar();
            return;
        }
        pagevar.drawgotocalendar();
    },
    pageprep:function(){
        if(pagevar.contentheight==0){
            pagevar.contentheight = $('#scrollcontainer').height()-$('#hourheader').height();
        }
        if(!viewopts.userslayout){
            pagevar.theboxheight = ismobile ? 200 : Math.floor(Math.max((pagevar.contentheight/$('#dayinaweek').children('.aday').length),60));
            $('.aday').css('height',pagevar.theboxheight+'px');
            pagevar.theboxwidth = $('.anhour').eq(0).width();
            pagevar.thedaywidth = $('.theday').eq(0).width();
        }
        else{
            $('.anhour').css('width',viewopts.boxwidth);
            $('.aday').css('height',viewopts.boxheight);
        }
        viewopts.updatequeue[viewopts.updatequeue.length] = true;
        viewopts.waitingforqueue('extrapprep');
        setTimeout(function(){
            viewopts.splicequeue(true);
        },300);
        
            if(!userpref.pref['rareity_pages'].length){
                $('#savedview').addClass('disabled');
            }
    },
    extrapprep:function(){
        this.totalwidth = $('.hourinaday').eq(0).width()+pagevar.thedaywidth+24;
        $('#dayinaweek').css('width',this.totalwidth+'px');
        $('#hourheader').css('width',this.totalwidth+'px');
        $('#hourheader').css('left','0px');
        $('.theday').css('left','0px');
        $('#scrollcontainer').scrollLeft(0);
        $('#scrollcontainer').scrollTop(0);
        $('#dayinaweek').css('margin-top',$('#hourheader').height()+'px');
        
        if(pagevar.thetime !== false && $('.theday.thisday').length){
            if($('.theday.thisday').find('.tablecell').html().split('<br>')[1] != pagevar.getNow()){
                $('.theday.thisday').removeClass('thisday');
            }
        }
        pagevar.scrollintocact();
    },
    init:function(){
        pageaction.loadingpage(false);
        pagevar.init();
        
        if(!ismobile)
        $('body').on('keydown',function(event){
            event.stopPropagation();
            
            if(!event.ctrlKey){
                switch(event.which){
                    case 27:
                        if($('#messagebox').attr('class').indexOf('active') !== -1){
                            if(typeof $('#messagebox').find('.regiformfoc').attr('class') !== 'undefined'){
                                $('#messagebox').find('.regiformfoc').blur();
                                return;
                            }
                            if(typeof $('#messagebox').find('.activdeta').attr('class') !== 'undefined' && $('#messagebox').find('.activdeta').attr('class').indexOf('focus')!==-1){
                                $('#messagebox').find('.activdeta').blur();
                                return;
                            }
                            
                            if(dialogbox.title.indexOf('Welcome ') !== -1){
                                welcomeaudio.pause();
                                $('#messagebox').removeClass('active');
                                $('.pagecontainer').css('opacity','1');
                                return;
                            }
                            else if(dialogbox.title == 'Activity Reminder'){
                                if(pagevar.activityinedit.type == 3){
                                    if(pagevar.activityinedit.name.toLowerCase() == 'shubuh' || pagevar.activityinedit.name.toLowerCase() == 'subuh'){
                                        fajralarm.pause();
                                    }
                                    else{
                                        prayalarm.pause();
                                    }
                                }
                                else{
                                    actalarm.pause();
                                }
                                $('#messagebox').removeClass('active');
                                $('.pagecontainer').css('opacity','1');
                                return;
                            }
                            else if(dialogbox.title == 'Save as Todolist Item'){
                                pageaction.detailsofact_();
                                return;
                            }
                            if(typeof $('#backdetailsofact').attr('id') !== 'undefined'){
                                if($('#backdetailsofact').attr('class').indexOf('revact') === -1){
                                    pageaction.detailsofact_();
                                    return;
                                }
                                pageaction.reviewactivity();
                                return;
                            }
                            if(typeof $('#backtorelative').attr('id') !=='undefined'){
                                pageaction.backtorelativefn();
                                return;
                            }
                            if(typeof $('#toanchor').attr('id') !=='undefined'){
                                pageaction.detailsofact_();
                                return;
                            }    
                            switch(dialogbox.title){
                                case 'Search Activities':
                                case 'Suggest an Activity':
                                case 'To Do List':
                                case 'Save Calendar':
                                case 'Budget Forecast':
                                case 'Go To Date':
                                case 'Presets':
                                case 'Activity Types':
                                case 'View Options':
                                case 'Time Calculator':
                                case 'Confirm Changes':
                                    dialogbox.close();
                                break;
                                case 'New Activity':
                                    dialogbox.close();
                                    if(typeof pagevar.newactiv.wasedited !== 'undefined' && pagevar.newactiv.wasedited !== false){
                                        pagevar.newactiv.confirmedited();
                                    }
                                    else{
                                        pagevar.newactiv.waseditedfn();
                                    }
                                break;
                                case 'Edit Activity':
                                    pagevar.activityinedit.beenthere();
                                    dialogbox.close();
                                    if(typeof pagevar.activityinedit.wasedited !== 'undefined' && pagevar.activityinedit.wasedited !== false){
                                        pagevar.activityinedit.confirmedited();
                                    }
                                    else{
                                        pagevar.activityinedit.waseditedfn();
                                    }
                                break;
                                case 'Delete Activity Type':
                                    atypebox.menubox();
                                break;
                                case 'Time Differences':
                                    timecalc.menubox();
                                break;
                                case 'Cost Details':
                                    rarecost.estimate();
                                break;
                                case 'To Do':
                                    todolist.editing.todolistitem = true;
                                    if(todolist.editing.checkwasedited() !== false){
                                        todolist.editing.waseditedfn_(function(){
                                            todolist.menubox();
                                        });
                                    }
                                    else{
                                        todolist.menubox();
                                    }
                                break;
                                case 'Edit Preset':
                                case 'New Preset':
                                    presetbox.menubox();
                                break;
                                case 'Add Activity Type':
                                case 'Edit Activity Type':
                                    atypebox.menubox();
                                break;
                                case 'Search Activities Result':
                                    actfinder.searchbox();
                                break;
                                case 'Activity Suggestions':
                                    activsuggestion.boundidx-=1;
                                    activsuggestion.dbox();
                                break;
                            }
                        }   
                    break;
                    case 13:
                        if($('#messagebox').attr('class').indexOf('active') === -1){
                            if(typeof $('.calitem.beenthere').attr('id') !== 'undefined'){
                                pageaction.detailsofact($('.calitem.beenthere'));
                            }
                            return;
                        }
                        if($('#messagebox').find('.beenthere').length == 1){
                            switch(dialogbox.title){
                                case 'Activity Suggestions':
                                    activsuggestion.clicksuggrow($('#messagebox').find('.beenthere').eq(0));
                                break;
                                case 'Search Activities Result':
                                    actfinder.clicksactres($('#messagebox').find('.beenthere').eq(0));
                                break;
                                case 'To Do List':
                                    todolist.detailbox($('#messagebox').find('.beenthere').eq(0).attr('id').split('_')[1]);
                                break;
                                case 'Cost Details':
                                    rarecost.actdet($('#messagebox').find('.beenthere').eq(0));
                                break;
                            }
                        }
                    break;
                    case 38:
                        if($('#messagebox').attr('class').indexOf('active') === -1){
                            return;
                        }
                        if($.inArray(dialogbox.title,['Activity Suggestions','Search Activities Result','To Do List','Cost Details']) !== -1){
                            if($('#messagebox').find('.beenthere').length == 1){
                                var temp = $('#messagebox').find('.beenthere').eq(0);
                                $(temp).removeClass('beenthere');
                                if(typeof $(temp).prev().attr('id') !== 'undefined'){
                                    $(temp).prev().addClass('beenthere');
                                }
                                else{
                                    switch(dialogbox.title){
                                        case 'Activity Suggestions':
                                            $('#messagebox').find('.row.suggrow').eq($('#messagebox').find('.row.suggrow').length-1).addClass('beenthere');
                                        break;
                                        case 'Search Activities Result':
                                            $('#messagebox').find('.row.sactres').eq($('#messagebox').find('.row.sactres').length-1).addClass('beenthere');
                                        break;
                                        case 'To Do List':
                                            $('#messagebox').find('.row.todolistitem').eq($('#messagebox').find('.row.todolistitem').length-1).addClass('beenthere');
                                        break;
                                        case 'Cost Details':
                                            $('#messagebox').find('.row.coact').eq($('#messagebox').find('.row.coact').length-1).addClass('beenthere');
                                        break;                                    
                                    }
                                }
                            }
                            else{
                                switch(dialogbox.title){
                                    case 'Activity Suggestions':
                                        $('#messagebox').find('.row.suggrow').eq($('#messagebox').find('.row.suggrow').length-1).addClass('beenthere')[0];
                                    break;
                                    case 'Search Activities Result':
                                        $('#messagebox').find('.row.sactres').eq($('#messagebox').find('.row.sactres').length-1).addClass('beenthere');
                                    break;
                                    case 'To Do List':
                                        $('#messagebox').find('.row.todolistitem').eq($('#messagebox').find('.row.todolistitem').length-1).addClass('beenthere');
                                    break;
                                    case 'Cost Details':
                                        $('#messagebox').find('.row.coact').eq($('#messagebox').find('.row.coact').length-1).addClass('beenthere');
                                    break;                                    
                                }
                            }
                            $('#messagebox').find('.beenthere').eq(0)[0].scrollIntoView();
                        }
                    break;
                    case 40:
                        if($('#messagebox').attr('class').indexOf('active') === -1){
                            return;
                        }
                        
                        if($.inArray(dialogbox.title,['Activity Suggestions','Search Activities Result','To Do List','Cost Details']) !== -1){
                            if($('#messagebox').find('.beenthere').length == 1){
                                var temp = $('#messagebox').find('.beenthere').eq(0);
                                $(temp).removeClass('beenthere');
                                if(typeof  $(temp).next().attr('id') !== 'undefined'){
                                    $(temp).next().addClass('beenthere');
                                }
                                else{
                                    switch(dialogbox.title){
                                        case 'Activity Suggestions':
                                            $('#messagebox').find('.row.suggrow').eq(0).addClass('beenthere');
                                        break;
                                        case 'Search Activities Result':
                                            $('#messagebox').find('.row.sactres').eq(0).addClass('beenthere');
                                        break;
                                        case 'To Do List':
                                            $('#messagebox').find('.row.todolistitem').eq(0).addClass('beenthere');
                                        break;
                                        case 'Cost Details':
                                            $('#messagebox').find('.row.coact').eq(0).addClass('beenthere');
                                        break;                                    
                                    }
                                }
                            }
                            else{
                                switch(dialogbox.title){
                                    case 'Activity Suggestions':
                                        $('#messagebox').find('.row.suggrow').eq(0).addClass('beenthere');
                                    break;
                                    case 'Search Activities Result':
                                        $('#messagebox').find('.row.sactres').eq(0).addClass('beenthere');
                                    break;
                                    case 'To Do List':
                                        $('#messagebox').find('.row.todolistitem').eq(0).addClass('beenthere');
                                    break;
                                    case 'Cost Details':
                                        $('#messagebox').find('.row.coact').eq(0).addClass('beenthere');
                                    break;                                    
                                }
                            }
                            $('#messagebox').find('.beenthere').eq(0)[0].scrollIntoView();
                        }
                    break;
                    case 37:
                        if($('#messagebox').attr('class').indexOf('active') !== -1){
                            if(dialogbox.title =='Edit Activity' || dialogbox.title == 'Review Activity'){
                                if(typeof $('#messagebox').find('.regiformfoc').attr('class') !== 'undefined'){
                                    return;
                                }
                                if(typeof $('#messagebox').find('.activdeta').attr('class') !== 'undefined' && $('#messagebox').find('.activdeta').attr('class').indexOf('focus')!==-1){
                                    return;
                                }
                                if(dialogbox.title=='Edit Activity'){
                                    if(pagevar.activityinedit.checkwasedited() !== false){
                                        pagevar.activityinedit.waseditedfn_(function(){
                                            pageaction.prevact(true);
                                        });
                                    }
                                    else{
                                        pageaction.prevact(true);
                                    }
                                }
                                else{
                                    pageaction.prevact(true);
                                }
                            }
                            return;
                        }
                        
                        if(typeof $('.calitem.beenthere').attr('id') !== 'undefined'){
                            pageaction.prevact(false);
                        }
                        else{
                            $('#scrollcontainer').find('.calitem').eq($('#scrollcontainer').find('.calitem').length-1).addClass('beenthere');
                            pagevar.getactivity($('.calitem.beenthere').attr('id').split('_')[1]);
                            pagevar.activityinedit.searchresult = false;
                        }
                    break;
                    case 39:
                        if($('#messagebox').attr('class').indexOf('active') !== -1){
                            if(dialogbox.title =='Edit Activity' || dialogbox.title == 'Review Activity'){
                                if(typeof $('#messagebox').find('.regiformfoc').attr('class') !== 'undefined'){
                                    return;
                                }
                                if(typeof $('#messagebox').find('.activdeta').attr('class') !== 'undefined' && $('#messagebox').find('.activdeta').attr('class').indexOf('focus')!==-1){
                                    return;
                                }
                                
                                if(dialogbox.title=='Edit Activity'){
                                    if(pagevar.activityinedit.checkwasedited() !== false){
                                        pagevar.activityinedit.waseditedfn_(function(){
                                            pageaction.nextact(true);
                                        });
                                    }
                                    else{
                                        pageaction.nextact(true);
                                    }
                                }
                                else{
                                    pageaction.nextact(true);
                                }
                            }
                            return;
                        }
                        
                        if(typeof $('.calitem.beenthere').attr('id') !== 'undefined'){
                            pageaction.nextact(false);
                        }
                        else{
                            $('#scrollcontainer').find('.calitem').eq(0).addClass('beenthere');
                            pagevar.getactivity($('.calitem.beenthere').attr('id').split('_')[1]);
                            pagevar.activityinedit.searchresult = false;
                        }
                    break;
                }
                    
                return;
            }

            switch(event.which){
                case 16:
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(dialogbox.title == 'Review Activity'){    
                            pageaction.detailsofrevactcountdown();
                        }
                        else if(dialogbox.title == 'Edit Activity'){
                            pageaction.detailsofactcountdown();
                        }
                        return;
                    }
                break;
                case 88:/*X*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(dialogbox.title == 'Review Activity'){             
                            pagevar.activityinedit = pagevar.reviewedactivity;
                            pageaction.detailsofact_();
                        }
                    }
                    else{
                        if(typeof $('.calitem.beenthere').attr('id') !== 'undefined'){
                            pageaction.detailsofact($('.calitem.beenthere'));
                        }
                        else{
                            if(typeof $('.startrareity').attr('id') !== 'undefined'){
                                pageaction.detailsofact($('.startrareity'));
                                pageaction.nextact(true);
                            }
                            else{
                                pageaction.detailsofact($('#scrollcontainer').find('.calitem').eq(0));
                            }   
                        }
                    }
                break;
                case 37:/*LEFT ARROW*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(dialogbox.title =='Edit Activity' || dialogbox.title == 'Review Activity'){
                            if(typeof $('#messagebox').find('.regiformfoc').attr('class') !== 'undefined'){
                                return;
                            }
                            if(typeof $('#messagebox').find('.activdeta').attr('class') !== 'undefined' && $('#messagebox').find('.activdeta').attr('class').indexOf('focus')!==-1){
                                return;
                            }
                                if(dialogbox.title=='Edit Activity'){
                                    if(pagevar.activityinedit.checkwasedited() !== false){
                                        pagevar.activityinedit.waseditedfn_(function(){
                                            pageaction.prevact(true);
                                        });
                                    }
                                    else{
                                        pageaction.prevact(true);
                                    }
                                }
                                else{
                                    pageaction.prevact(true);
                                }
                                
                            
                        }
                    }
                break;
                case 39:/* RIGHT ARROW*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(dialogbox.title =='Edit Activity' || dialogbox.title == 'Review Activity'){
                            if(typeof $('#messagebox').find('.regiformfoc').attr('class') !== 'undefined'){
                                return;
                            }
                            if(typeof $('#messagebox').find('.activdeta').attr('class') !== 'undefined' && $('#messagebox').find('.activdeta').attr('class').indexOf('focus')!==-1){
                                return;
                            }
                            
                                if(dialogbox.title=='Edit Activity'){
                                    if(pagevar.activityinedit.checkwasedited() !== false){
                                        pagevar.activityinedit.waseditedfn_(function(){
                                            pageaction.nextact(true);
                                        });
                                    }
                                    else{
                                        pageaction.nextact(true);
                                    }
                                }
                                else{
                                    pageaction.nextact(true);
                                }
                        }
                    }
                break;
                case 86:
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(typeof $('#messagebox').find('.regiformfoc').attr('class') !== 'undefined'){
                            return;
                        }
                        if(typeof $('#messagebox').find('.activdeta').attr('class') !== 'undefined' && $('#messagebox').find('.activdeta').attr('class').indexOf('focus')!==-1){
                            return;
                        }
                        if(dialogbox.title == 'Save Calendar'){
                            return;
                        }
                    }
                    rareity_menu('saveview');
                break;
                case 80:
                    rareity_menu('exportactivity');
                break;
                case 188:/*,*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(dialogbox.title == 'To Do' || dialogbox.title =='Edit Activity' || dialogbox.title == 'New Activity'){
                            return;
                        }
                    }
                    rareity_menu('bweek');
                break;
                case 190:/*.*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(dialogbox.title == 'To Do' || dialogbox.title =='Edit Activity' || dialogbox.title == 'New Activity'){
                            return;
                        }
                    }
                    rareity_menu('fweek');
                break;
                case 71:/*G*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(dialogbox.title == 'Go To Date'){
                            dialogbox.close();
                            return;
                        }
                    }
                    rareity_menu('goto');
                break;
                case 78:/*N*/
                    rareity_menu('gotonow');
                break;
                case 70:/*F*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(dialogbox.title == 'Search Activities'){
                            dialogbox.close();
                            return;
                        }
                    }
                    rareity_menu('searchactivity');
                break;
                case 67:/*C*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(typeof $('#messagebox').find('.regiformfoc').attr('class') !== 'undefined'){
                            return;
                        }
                        if(typeof $('#messagebox').find('.activdeta').attr('class') !== 'undefined' && $('#messagebox').find('.activdeta').attr('class').indexOf('focus')!==-1){
                            return;
                        }
                        if(dialogbox.title == 'Budget Forecast'){
                            dialogbox.close();
                            return;
                        }
                    }
                    rareity_menu('coverview');
                break;
                case 83:/*S*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(dialogbox.title == 'Suggest an Activity'){
                            dialogbox.close();
                            return;
                        }
                    }
                    rareity_menu('suggestact');
                break;
                case 84:/*T*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(dialogbox.title == 'To Do List'){
                            dialogbox.close();
                            return;
                        }
                    }
                    rareity_menu('todo');
                break;
                case 90:/*Z*/
                    if($('#messagebox').attr('class').indexOf('active') !== -1){
                        if(typeof $('#messagebox').find('.regiformfoc').attr('class') !== 'undefined'){
                            return;
                        }
                        if(typeof $('#messagebox').find('.activdeta').attr('class') !== 'undefined' && $('#messagebox').find('.activdeta').attr('class').indexOf('focus')!==-1){
                            return;
                        }
                        if(dialogbox.title == 'Saved Calendar'){
                            dialogbox.close();
                            return;
                        }
                        else{
                            return;
                        }
                    }
                    if($('#savedview').attr('class').indexOf('disabled') ===-1)
                    rareity_menu('savedview');
                break;
            }
        });
        
        $('body').delegate('.theday','click',function(event){
            event.stopPropagation();
            
            if($('#dayinaweek').attr('class').indexOf('focusing')===-1){
                $('#dayinaweek').addClass('focusing');
                $(this).parent().addClass('focusing');
                return;
            }
            if($(this).parent().attr('class').indexOf('focusing')===-1){
                $('#dayinaweek').removeClass('focusing');
                $('.aday.focusing').removeClass('focusing');
                return;
            }
            $('#dayinaweek').removeClass('focusing');
            $(this).parent().removeClass('focusing');
        });
        $('body').delegate('.addadeactiv','click',function(event){
            event.stopPropagation();
            
            if($(this).parent().parent().parent().attr('class').indexOf('alldayevent')!==-1){
                pageaction.detailsofact($(this).parent().parent().parent());
                return;
            }
            pageaction.newalldayactivity($(this).parent().parent().parent());
        });
        $('body').delegate('#menu','click',function(event){
            event.stopPropagation();
            
            if($(this).children('#menuitems').attr('class').indexOf('active')===-1){
                pagevar.setthetime();
                $(this).children('#menuitems').addClass('active');
            }
            else{
                $(this).children('#menuitems').removeClass('active');
            }
        });
        
        $('body').delegate('.menuitem','click',function(event){
            event.stopPropagation();
            
            pageaction.handlemenu(this);
            $('#menuitems').removeClass('active');
        });
        
        registaforminput('body','input[type="number"],input[type="text"],textarea,select');
        $('body').delegate('.anhour','mousedown',function(event){
            event.stopPropagation();
            
            if($(this).attr('class').indexOf('header') !==-1)
                return;
                
            pageaction.newactivity(this,false);
        });
        $('body').delegate('.nextday','click',function(event){
            event.stopPropagation();
            
            pageaction.detailsofact(this);
        });        
        $('body').delegate('.calitem','mousedown',function(event){
            event.stopPropagation();
            
            pageaction.boxmove(this,event);
        });
        $('body').delegate('.duinwhat','mousedown',function(event){
            event.stopPropagation();
            $(this).val('duration in hours');
            $(this).addClass('underpress');
            
            var inminu = $(this).next().val()/60;
            $(this).next().val(inminu);
        });
        
        $('body').delegate('.duinwhat','mouseup',function(event){
            event.stopPropagation();
            $(this).removeClass('underpress');
            $(this).val('duration in minutes');
            
            var inhou = $(this).next().val();
            $(this).next().val(Math.round(inhou*60));
        });
    },
    detailsofact:function(elem){
        pagevar.getactivity($(elem).attr('id').split('_')[1]);
        pagevar.activityinedit.searchresult = false;
        if(pagevar.activityinedit.type=='startrareity'){
            pageaction.newactivity($(elem).parent(),pagevar.activityinedit);
            return;
        }
        this.detailsofact_();
    },
    reviewactivity:function(){
        if(pagevar.reviewedactivity.id == pagevar.activityinedit.id){
            this.detailsofact_();
            return;
        }
        var title = 'Review Activity';
        var content = '<div class="row multiinput double"><input type="text" disabled="true" name="date" value="date" class="date first"><input type="text" disabled="true" name="time" value="time" class="time"></div>';
        content += '<div class="row"><input type="text" disabled="true" name="name" value="name" class="name"></div>';
        content += '<div class="row"><select name="type" disabled="true" class="type">'+atypebox.activitytypeoption(pagevar.activityinedit.duration)+'</select></div>';
        content += '<div class="row"><select name="recurring type" disabled="true" class="recurring">'+pagevar.recurringtypestr()+'</select></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="duration in minutes" class="disabled first borderless duinwhat"><input type="number" disabled="true" value="30" name="duration" class="duration"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="priority" class="disabled first borderless ten"><input type="number" name="priorityinput" disabled="true" value="10" class="priority" min=1 max=10></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="alarm" class="disabled first borderless ten"><input type="number" disabled="true" name="alarminput" value="0" class="alarm" min=0></div>';
        content += '<div class="row"><div class="activdeta description disabled">description</div></div>';
        
        var action = '<span class="left" id="toanchor">&larr; Back</span><span class="navact" id="nextact">&rarr;</span><span class="navact" id="prevact">&larr;</span><span class="editreview" id="editreview">Edit</span><span id="countdownacti" class="extras left"></span>';

        mbox(title,content,action,'');
        $('#editreview').on('click',function(event){
            event.stopPropagation();
            
            pagevar.activityinedit = pagevar.reviewedactivity;
            pageaction.detailsofact_();
        });
        
        pagevar.reviewedactivity.editform();
        
        this.mboxactionmenu();
    },
    recentbeenthere:false,
    detailsofact_:function(){
        pagevar.reviewedactivity = false;
        
        $('.calitem.beenthere').removeClass('beenthere');
        $('.nextday.beenthere').removeClass('beenthere');
        
        var title = 'Edit Activity';
        var content = '<div class="row multiinput double"><input type="text" name="date" value="date" class="date first"><input type="text" name="time" value="time" class="time"></div>';
        content += '<div class="row"><input type="text" name="name" value="name" class="name"></div>';
        content += '<div class="row"><input type="hidden" value="type" id="acttypeexclusive" class="type acttypeexclusive"><input type="text" name="type" value="type" class="acttype exclusive" id="acttypeadder"></div>';
        content += '<div class="row"><select name="recurring type" class="recurring">'+pagevar.recurringtypestr()+'</select></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="duration in minutes" class="disabled first borderless duinwhat"><input type="number" value="30" name="duration" class="duration"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="priority" class="disabled first borderless ten"><input type="number" name="priorityinput" value="10" class="priority" min=1 max=10></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="alarm" class="disabled first borderless ten"><input type="number" name="alarminput" value="0" class="alarm" min=0></div>';
        content += '<div class="row"><textarea name="description" id="activdeta" class="description"></textarea></div>';
        
        var backtorel = false;
        var action = '<span class="navact fullobtn" id="nextact">&rarr;</span><span class="navact fullobtn" id="prevact">&larr;</span><span id="confirmeditacti" class="fullobtn">Save</span><span id="deleteacti" class="dangerous fullobtn">Delete</span><span id="totodo" class="extras fullobtn left"></span><span id="countdownacti" class="extras fullobtn left"></span>';
        if(typeof pagevar.activityinedit.searchresult !=='undefined' && pagevar.activityinedit.searchresult !== false){
            action += '<span id="backtorelative" class="left fullobtn">&larr; Back</span>';
            backtorel = true;
        }
        mbox(title,content,action,'');
        var stopmenu = pagevar.activityinedit.stopmenu();
        if(!stopmenu){
            $('#messageboxaction').children().eq(0).before('<span class="cost fullobtn left extras" id="dcost"><input type="text" value="cost" id="dcostvalue" name="cost"></span>');
        }
        pagevar.activityinedit.editform();
        
        pageaction.texteditor();
        atypebox.acttypeadderaction();
        this.mboxactionmenu();
        $('#messagebox').removeClass('loading');
    },
    textcounter:0,
    texteditor:function(){
        this.textcounter++;
        var textcont = $('#activdeta').val();
        if(textcont == 'description' || textcont == '')
            $('#activdeta').replaceWith('<div id="activdeta_'+this.textcounter+'" class="activdeta description">description</div>');
        else
            $('#activdeta').replaceWith('<div id="activdeta_'+this.textcounter+'" class="activdeta description filled">'+textcont+'</div>');
            
        if(ismobile){
            $('#activdeta_'+this.textcounter).on('click',function(event){
                event.stopPropagation();
                
                $(this).replaceWith('<textarea name="description" id="activdeta" class="description">'+textcont+'</textarea>');
            });
            return;
        }
            
        tinythentinynow('activdeta_'+this.textcounter);
    },
    nextact:function(detbox){
        var anchor,cbox;
        if(pagevar.reviewedactivity === false){
            anchor = pagevar.activityinedit.id;
        }
        else{
            anchor = pagevar.reviewedactivity.id;
        }
        if(typeof $('#calitem_'+anchor).next().attr('class') !== 'undefined' && $('#calitem_'+anchor).next().attr('class').indexOf('calitem') !==-1){
            anchor = parseInt($('#calitem_'+anchor).next().attr('id').split('_')[1]);
        }
        else{
            cbox = $('#calitem_'+anchor).parent();
            anchor = this.nextnode(anchor,cbox);
        }
        
        if(anchor !== false){
            pagevar.getactivityforreview(anchor);
            pagevar.reviewedactivity.searchresult = false;
            if(pagevar.reviewedactivity.type=='startrareity'){
                this.nextact(detbox);
                return;
            }
            if(detbox)
                this.reviewactivity();   
            else{
                if(typeof $('.calitem.beenthere').attr('id') !== 'undefined'){
                    $('.calitem.beenthere').removeClass('beenthere');
                }
                pagevar.activityinedit = pagevar.reviewedactivity;
                pagevar.activityinedit.beenthere();
            }
            return;
        }
        $('#nextact').addClass('disabled');
    },
    nextnode:function(anchor,cbox){
        cbox = this.nextbox(cbox);
        if(cbox !== false){
            if($(cbox).children('.calitem').length){
                anchor = parseInt($(cbox).children('.calitem').eq(0).attr('id').split('_')[1]);
                return anchor;
            }
            else{
                return this.nextnode(anchor,cbox);
            }
        }
        return false;
    },
    nextbox:function(cbox){
        if(typeof $(cbox).next().attr('class') !== 'undefined' && $(cbox).next().attr('class').indexOf('anhour') !== -1){
            cbox = $(cbox).next();
            return cbox;
        }
        
        
        var dayrow = $(cbox).parent().parent();
        if(typeof $(dayrow).next().attr('class') !== 'undefined' && $(dayrow).next().attr('class').indexOf('aday') !==-1){
            cbox = $(dayrow).next().find('.anhour').eq(0);
            return cbox;
        }
        
        return false;
    },
    prevnode:function(anchor,cbox){
        cbox = this.prevbox(cbox);
        if(cbox !== false){
            if($(cbox).children('.calitem').length){
                anchor = parseInt($(cbox).children('.calitem').eq($(cbox).children('.calitem').length-1).attr('id').split('_')[1]);
                return anchor;
            }
            else{
                return this.prevnode(anchor,cbox);
            }
        }
        return false;
    },
    prevbox:function(cbox){
        if(typeof $(cbox).prev().attr('class') !== 'undefined' && $(cbox).prev().attr('class').indexOf('anhour') !== -1){
            cbox = $(cbox).prev();
            return cbox;
        }
        
        
        var dayrow = $(cbox).parent().parent();
        if(typeof $(dayrow).prev().attr('class') !== 'undefined' && $(dayrow).prev().attr('class').indexOf('aday') !==-1){
            cbox = $(dayrow).prev().find('.anhour').eq(23);
            return cbox;
        }
        
        return false;
    },
    prevact:function(detbox){
        var anchor,cbox;
        if(pagevar.reviewedactivity === false){
            anchor = pagevar.activityinedit.id;
        }
        else{
            anchor = pagevar.reviewedactivity.id;
        }
        if(typeof $('#calitem_'+anchor).prev().attr('class') !== 'undefined' && $('#calitem_'+anchor).prev().attr('class').indexOf('calitem') !==-1){
            anchor = parseInt($('#calitem_'+anchor).prev().attr('id').split('_')[1]);
        }
        else{
            cbox = $('#calitem_'+anchor).parent();
            anchor = this.prevnode(anchor,cbox);
        }
        
        if(anchor !== false){
            pagevar.getactivityforreview(anchor);
            pagevar.reviewedactivity.searchresult = false;
            if(pagevar.reviewedactivity.type=='startrareity'){
                this.prevact(detbox);
                return;
            }
            if(detbox)
                this.reviewactivity();   
            else{
                if(typeof $('.calitem.beenthere').attr('id') !== 'undefined'){
                    $('.calitem.beenthere').removeClass('beenthere');
                }
                pagevar.activityinedit = pagevar.reviewedactivity;
                pagevar.activityinedit.beenthere();
            }
            return;
        }
        $('#prevact').addClass('disabled');
    },
    dcost:function(){
        $('#messageboxaction').addClass('costing');
        $('#dcost').addClass('active');
        
        $('#dcostvalue').focus();
        $('#dcostvalue').on('blur',function(event){
            event.stopPropagation();
            pagevar.activityinedit.handlecosting();
        });
    },
    totodo:function(){
        var title = 'Save as Todolist Item';
        var content = '<div class="row">Convert '+pagevar.activityinedit.name+' as a todolist item?</div>';
        
        var action = '<span id="backtorelative" class="left fullobtn">&larr; Back</span><span id="converttotodo">Convert</span>';
        mbox(title,content,action,'narrow');
        
        $('#backtorelative').on('click',function(event){
            event.stopPropagation();
            
            pageaction.detailsofact_();
        });
        
        $('#converttotodo').on('click',function(event){
            event.stopPropagation();
            
            pageaction.totodo_();
        });
    },
    totodo_:function(){
        var postdata = pagevar.activityinedit.postdata();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'activityc',a:'totodo',d:postdata}
        }).done(function(msg){
            msg = JSON.parse(msg);
                
            if(msg.result){
                if(pagevar.activityinedit.duration == 1440 || pagevar.activityinedit.duration=='all day'){
                    if(typeof $('#ade_'+pagevar.activityinedit.id).attr('id') !== 'undefined'){
                        $('#ade_'+pagevar.activityinedit.id).next().removeClass('alldayevent');
                        $('#ade_'+pagevar.activityinedit.id).prop('class','theday');
                        $('#ade_'+pagevar.activityinedit.id).css('background','');
                        $('#ade_'+pagevar.activityinedit.id).find('.addadeactiv').css('display','');
                        $('#ade_'+pagevar.activityinedit.id).prop('id','');   
                    }
                }
                pagevar.deleteactivity(pagevar.activityinedit.id);
                if(pagevar.activityinedit.recurring!=0){
                    pagevar.rarifyrecurring(pagevar.activityinedit);
                }
                todolist.fetchlist();
            }
        });
    },
    mboxactionmenu:function(){
        if(dialogbox.title == 'Edit Activity')
        $('#closemessagebox').on('click',function(event){
            event.stopPropagation();
            pagevar.activityinedit.beenthere();
            
            if(typeof pagevar.activityinedit.wasedited !== 'undefined' && pagevar.activityinedit.wasedited !== false){
                pagevar.activityinedit.confirmedited();
            }
            else{
                pagevar.activityinedit.waseditedfn();
            }
        });
        else if(dialogbox.title == 'New Activity'){
            $('#closemessagebox').on('click',function(event){
                event.stopPropagation();
                
                if(typeof pagevar.newactiv.wasedited !== 'undefined' && pagevar.newactiv.wasedited !== false){
                    pagevar.newactiv.confirmedited();
                }
                else{
                    pagevar.newactiv.waseditedfn();
                }
            }); 
        }
        if(typeof $('#totodo').attr('id') !=='undefined')
            $('#totodo').on('click',function(event){
                event.stopPropagation();
                
                pageaction.totodo();
            });
        if(typeof $('#dcost').attr('id') !=='undefined')
            $('#dcost').on('click',function(event){
                event.stopPropagation();
                
                pageaction.dcost();
            });
        if(typeof $('#toanchor').attr('id') !=='undefined')
            $('#toanchor').on('click',function(event){
                event.stopPropagation();
                
                pageaction.detailsofact_();
            });
        if(typeof $('#nextact').attr('id') !=='undefined')
            $('#nextact').on('click',function(event){
                event.stopPropagation();
                
                if($(this).attr('class').indexOf('disabled') !== -1){
                    return;
                }
                if(dialogbox.title == 'Edit Activity'){
                    if(pagevar.activityinedit.checkwasedited() !== false){
                        pagevar.activityinedit.waseditedfn_(function(){
                            pageaction.nextact(true);
                        });
                    }
                    else{
                        pageaction.nextact(true);
                    }   
                }
                else{
                    pageaction.nextact(true);
                }
            });
        
        if(typeof $('#prevact').attr('id') !=='undefined')
            $('#prevact').on('click',function(event){
                event.stopPropagation();
                
                if($(this).attr('class').indexOf('disabled') !== -1){
                    return;
                }
                
                if(dialogbox.title == 'Edit Activity'){
                    if(pagevar.activityinedit.checkwasedited() !== false){
                        pagevar.activityinedit.waseditedfn_(function(){
                            pageaction.prevact(true);
                        });
                    }
                    else{
                        pageaction.prevact(true);
                    }
                }
                else{
                    pageaction.prevact(true);
                }
            });
        
        if(typeof $('.priority').attr('class') !=='undefined')
            $('.priority').on('change',function(event){
                event.stopPropagation();
                
                $(this).prev().css('opacity',($(this).val()/10));
            });
        if(typeof $('#backtorelative').attr('id') !=='undefined')
            $('#backtorelative').on('click',function(event){
                event.stopPropagation();
                
                pageaction.backtorelativefn();
            });
            
        if(typeof $('#countdownacti').attr('id') !=='undefined')
            $('#countdownacti').on('click',function(event){
                event.stopPropagation();
                
                pageaction.detailsofactcountdown();
            });
            
        if(typeof $('#confirmeditacti').attr('id') !=='undefined')
            $('#confirmeditacti').on('click',function(event){
                event.stopPropagation();
                
                pagevar.activityinedit.submitedited();
            });
            
        if(typeof $('#deleteacti').attr('id') !=='undefined')
            $('#deleteacti').on('click',function(event){
                event.stopPropagation();
                
                var title = 'Delete Activity';
                var content = '<div class="row">Delete <b>'+pagevar.activityinedit.name+'</b>?</div>';
                var action = '<span id="backtorelative" class="left">&larr; Cancel</span><span id="confirmdeleteacti" class="dangerous">Delete</span>';
                mbox(title,content,action,'narrow');
                
                $('#backtorelative').on('click',function(event){
                    event.stopPropagation();
                    
                    pageaction.detailsofact_();
                });
                
                $('#confirmdeleteacti').on('click',function(event){
                    event.stopPropagation();
                    
                    pagevar.activityinedit.delete();
                });
            });
            
        if(typeof $('#messagebox').find('.name').attr('class') !== 'undefined'){
            $('#messagebox').find('.name').on('keyup',function(event){
                event.stopPropagation();
                
                switch(event.which){
                    case 13:
                        if(dialogbox.title == 'Edit Activity')
                            pagevar.activityinedit.submitedited();
                        else
                            pagevar.newactiv.submitedited();
                    break;
                    case 27:
                        if(typeof $('#backtorelative').attr('id') !=='undefined'){
                            pageaction.backtorelativefn();
                        }
                        else{
                            dialogbox.close();
                        }
                    break;
                    default:
                    
                }
            });
        }
        
        if(typeof $('#messagebox').find('.duration').attr('class') !== 'undefined'){
            $('#messagebox').find('.duration').on('keyup',function(event){
                event.stopPropagation();
                
                switch(event.which){
                    case 13:
                        if(dialogbox.title == 'Edit Activity')
                            pagevar.activityinedit.submitedited();
                        else
                            pagevar.newactiv.submitedited();
                    break;
                    case 27:
                        if(typeof $('#backtorelative').attr('id') !=='undefined'){
                            pageaction.backtorelativefn();
                        }
                        else{
                            dialogbox.close();
                        }
                    break;
                    default:
                    
                }
            });
        }
        
        if(typeof $('#messagebox').find('.priority').attr('class') !== 'undefined'){
            $('#messagebox').find('.priority').on('keyup',function(event){
                event.stopPropagation();
                
               switch(event.which){
                    case 13:
                        if(dialogbox.title == 'Edit Activity')
                            pagevar.activityinedit.submitedited();
                        else
                            pagevar.newactiv.submitedited();
                    break;
                    case 27:
                        if(typeof $('#backtorelative').attr('id') !=='undefined'){
                            pageaction.backtorelativefn();
                        }
                        else{
                            dialogbox.close();
                        }
                    break;
                    default:
                    
                }
            });
        }
        
        if(typeof $('#messagebox').find('.alarm').attr('class') !== 'undefined'){
            $('#messagebox').find('.alarm').on('keyup',function(event){
                event.stopPropagation();
                
               switch(event.which){
                    case 13:
                        if(dialogbox.title == 'Edit Activity')
                            pagevar.activityinedit.submitedited();
                        else
                            pagevar.newactiv.submitedited();
                    break;
                    case 27:
                        if(typeof $('#backtorelative').attr('id') !=='undefined'){
                            pageaction.backtorelativefn();
                        }
                        else{
                            dialogbox.close();
                        }
                    break;
                    default:
                    
                }
            });
        }
        if(typeof $('#messagebox').find('.date').attr('class') !== 'undefined'){
            $('#messagebox').find('.date').on('keyup',function(event){
                event.stopPropagation();
                
               switch(event.which){
                    case 13:
                        if(dialogbox.title == 'Edit Activity')
                            pagevar.activityinedit.submitedited();
                        else
                            pagevar.newactiv.submitedited();
                    break;
                    case 27:
                        if(typeof $('#backtorelative').attr('id') !=='undefined'){
                            pageaction.backtorelativefn();
                        }
                        else{
                            dialogbox.close();
                        }
                    break;
                    default:
                    
                }
            });
        }
        if(typeof $('#messagebox').find('.time').attr('class') !== 'undefined'){
            $('#messagebox').find('.time').on('keyup',function(event){
                event.stopPropagation();
                
               switch(event.which){
                    case 13:
                        if(dialogbox.title == 'Edit Activity')
                            pagevar.activityinedit.submitedited();
                        else
                            pagevar.newactiv.submitedited();
                    break;
                    case 27:
                        if(typeof $('#backtorelative').attr('id') !=='undefined'){
                            pageaction.backtorelativefn();
                        }
                        else{
                            dialogbox.close();
                        }
                    break;
                    default:
                    
                }
            });
        }
    },
    backtorelativefn:function(){
        if(pagevar.activityinedit.searchresult == 'suggestions'){
            activsuggestion.sresults.displayresult();
            $('#suggrow_'+pagevar.activityinedit.id)[0].scrollIntoView();
            $('#suggrow_'+pagevar.activityinedit.id).addClass('beenthere');
        }
        else if(pagevar.activityinedit.searchresult == 'costoverview'){
            rarecost.sortdet(false);
            $('#dcoact_'+pagevar.activityinedit.id)[0].scrollIntoView();
            $('#dcoact_'+pagevar.activityinedit.id).addClass('beenthere');
        }
        else{
            actfinder.displaysearchresult();
            $('#sactres_'+pagevar.activityinedit.id).children('.sacttitle').html(pagevar.activityinedit.name);
            $('#sactres_'+pagevar.activityinedit.id).children('.sacttype').html(atypebox.atname(pagevar.activityinedit.type));
            $('#sactres_'+pagevar.activityinedit.id).children('.sactdesc').html(pagevar.activityinedit.description);
            $('#sactres_'+pagevar.activityinedit.id).children('.sacttime').html(pagevar.activityinedit.time);
            
            $('#sactres_'+pagevar.activityinedit.id)[0].scrollIntoView();
            $('#sactres_'+pagevar.activityinedit.id).addClass('beenthere');
        }
    },
    countdowntimer:false,
    countdowncompo:[],
    detailsofrevactcountdown:function(){
        var ddate = pagevar.reviewedactivity.date.split('-');
        var dtime = pagevar.reviewedactivity.time.split(':');
        ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
        var countdown = (ddate - pagevar.thetime)/1000;
        
        var cday = countdown/86400;
        var chour = (((cday%1)*86400)/3600);
        cday = cday-(cday%1);
        var cmin = (((chour%1)*3600)/60);
        chour = chour-(chour%1);
        var csec = (cmin%1)*60;
        cmin = cmin-(cmin%1);
        csec = csec-(csec%1);
        
        pageaction.countdowncompo = [];
        pageaction.countdowncompo[0] = cday;
        pageaction.countdowncompo[1] = chour;
        pageaction.countdowncompo[2] = cmin;
        pageaction.countdowncompo[3] = csec;
        if(countdown<0){
            pageaction.countdowncompo[4] = true;
        }
        
        var title = 'Countdown to '+pagevar.reviewedactivity.name;
        var content = '<span id="daycount">'+cday+'</span> days,<span id="hourcount">'+chour+'</span> hours,<span id="mincount">'+cmin+'</span> minutes,<span id="seccount">'+csec+'</span> seconds';
        var action = '<span id="backdetailsofact" class="left revact">&larr; Back</span>';
        mbox(title,content,action,'narrow');
        
        pageaction.countdownanime();
        
        $('#backdetailsofact').on('click',function(event){
            event.stopPropagation();
            
            pageaction.reviewactivity();
        });
    },
    detailsofactcountdown:function(){
        if(pagevar.reviewedactivity !== false){
            this.detailsofrevactcountdown();
            return;
        }
        var ddate = pagevar.activityinedit.date.split('-');
        var dtime = pagevar.activityinedit.time.split(':');
        ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
        var countdown = (ddate - pagevar.thetime)/1000;
        
        var cday = countdown/86400;
        var chour = (((cday%1)*86400)/3600);
        cday = cday-(cday%1);
        var cmin = (((chour%1)*3600)/60);
        chour = chour-(chour%1);
        var csec = (cmin%1)*60;
        cmin = cmin-(cmin%1);
        csec = csec-(csec%1);
        
        pageaction.countdowncompo = [];
        pageaction.countdowncompo[0] = cday;
        pageaction.countdowncompo[1] = chour;
        pageaction.countdowncompo[2] = cmin;
        pageaction.countdowncompo[3] = csec;
        if(countdown<0){
            pageaction.countdowncompo[4] = true;
        }
        
        var title = 'Countdown to '+pagevar.activityinedit.name;
        var content = '<span id="daycount">'+cday+'</span> days,<span id="hourcount">'+chour+'</span> hours,<span id="mincount">'+cmin+'</span> minutes,<span id="seccount">'+csec+'</span> seconds';
        var action = '<span id="backdetailsofact" class="left">&larr; Back</span>';
        mbox(title,content,action,'narrow');
        
        if(pageaction.recentbeenthere !==false && pageaction.recentbeenthere.id != pagevar.activityinedit.id){
            $('#messageboxaction').append('<span id="beentherecount" class="">Distance from '+pageaction.recentbeenthere.name+'</span>');
            $('#beentherecount').on('click',function(event){
                event.stopPropagation();
                
                pageaction.beentherecountdown();
            });
        }
        
        pageaction.countdownanime();
        
        $('#backdetailsofact').on('click',function(event){
            event.stopPropagation();
            
            pageaction.detailsofact_();
        });
        $('#closemessagebox').on('click',function(event){
            event.stopPropagation();
            
            pagevar.activityinedit.beenthere();
        });
    },
    beentherecountdown:function(){
        clearInterval(pageaction.countdowntimer);
        
        var actdata = [];
        actdata.date = pageaction.recentbeenthere.time.split(' ')[0];
        actdata.time = pageaction.recentbeenthere.time.split(' ')[1];
        
        var ddate_ = actdata.date.split('-');
        var dtime_ = actdata.time.split(':');
        
        ddate_ = new Date(parseInt(ddate_[0]),(parseInt(ddate_[1])-1),parseInt(ddate_[2]),dtime_[0],dtime_[1],dtime_[2]);
        
        var ddate = pagevar.activityinedit.date.split('-');
        var dtime = pagevar.activityinedit.time.split(':');
        ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
        var countdown = Math.abs(ddate - ddate_)/1000;
        
        var cday = countdown/86400;
        var chour = (((cday%1)*86400)/3600);
        cday = cday-(cday%1);
        var cmin = (((chour%1)*3600)/60);
        chour = chour-(chour%1);
        var csec = (cmin%1)*60;
        cmin = cmin-(cmin%1);
        csec = csec-(csec%1);
        
        pageaction.countdowncompo = [];
        pageaction.countdowncompo[0] = cday;
        pageaction.countdowncompo[1] = chour;
        pageaction.countdowncompo[2] = cmin;
        pageaction.countdowncompo[3] = csec;
        if(countdown<0){
            pageaction.countdowncompo[4] = true;
        }
        
        var title = 'Distance from '+pageaction.recentbeenthere.name;
        var content = '<span id="daycount">'+cday+'</span> days,<span id="hourcount">'+chour+'</span> hours,<span id="mincount">'+cmin+'</span> minutes,<span id="seccount">'+csec+'</span> seconds';
        var action = '<span id="backdetailsofact" class="left">&larr; Back</span>';
        mbox(title,content,action,'narrow');
        
        $('#backdetailsofact').on('click',function(event){
            event.stopPropagation();
            
            pageaction.detailsofactcountdown();
        });
        
        $('#closemessagebox').on('click',function(event){
            event.stopPropagation();
            
            pagevar.activityinedit.beenthere();
        });
    },
    countdownanime:function(){
        pageaction.countdowntimer = setInterval(function(){
            if(pageaction.countdowncompo.length == 5){
                pageaction.countdowncompo[3]--;
                if(pageaction.countdowncompo[3] ==-60){
                    pageaction.countdowncompo[3]=0;
                    pageaction.countdowncompo[2]--;
                    if(pageaction.countdowncompo[2]==-60){
                        pageaction.countdowncompo[2] = -59;
                        pageaction.countdowncompo[1]--;
                    }
                }
            }
            else{
                pageaction.countdowncompo[3]--;
                if(pageaction.countdowncompo[3] <0){
                    pageaction.countdowncompo[3]=59;
                    pageaction.countdowncompo[2]--;
                    if(pageaction.countdowncompo[2]<0){
                        pageaction.countdowncompo[2] = 59;
                        pageaction.countdowncompo[1]--;
                    }
                }
            }
            
            if(typeof $('#hourcount').attr('id')==='undefined'){
                clearInterval(pageaction.countdowntimer);
                return;
            }
            
            $('#daycount').html(pageaction.countdowncompo[0]);
            $('#hourcount').html(pageaction.countdowncompo[1]);
            $('#mincount').html(pageaction.countdowncompo[2]);
            $('#seccount').html(pageaction.countdowncompo[3]);
        },1000);
    },
    handlemenu:function(elem){
        rareity_menu($(elem).attr('id'));
    },
    gotodatendays:function(time,ndayscount){
        var range = ndayscount+'_days';
        var exi = pagevar.viewgoto(time,range);
        if(exi===false){
            dialogbox.close();
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'activityc',a:'gotodatendays',d:{time:time,range:range}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                $('#scrollcontainer').html(msg.pagecontent);
                pageaction.pageprep();
                pagevar.addgotopage(msg);
                
                
                pageaction.pageloaded();
            });
        }
        else{
            pageaction.pageloaded();
        }
    },
    gotodate:function(time,range){
        var exi = pagevar.viewgoto(time,range);
        if(exi===false){
            dialogbox.close();
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'activityc',a:'gotodate',d:{time:time,range:range}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                $('#scrollcontainer').html(msg.pagecontent);
                pageaction.pageprep();
                pagevar.addgotopage(msg);
                
                pageaction.pageloaded();
            });
        }
    },
    newalldayactivity:function(elem){
        var time = '00:00:00';
        var tdate = $(elem).find('.tablecell').html().split('<br>')[1];
        
        pagevar.newactiv = new activity({id:false,name:"name",description:"description",type:"type",date:tdate,time:time,duration:1440,priority:5});
        
        var title = 'New Activity';
        var content = '<div class="row multiinput double"><input type="text" name="date" value="date" class="date first"><input type="text" name="time" value="time" class="time"></div>';
        content+='<div class="row"><input type="text" name="name" value="name" class="name"></div>';
        content+='<div class="row"><input type="hidden" value="type" id="acttypeexclusive" class="type acttypeexclusive"><input type="text" name="type" value="type" class="acttype exclusive 1440" id="acttypeadder"></div>';
        content+='<div class="row"><div class="row"><select name="recurring type" class="recurring">'+pagevar.recurringtypestr()+'</select></div>';
        content+='<div class="row"><input type="text" disabled="true" value="all day" class="borderless duration disabled"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="priority:" class="disabled first borderless ten"><input type="number" name="priorityinput" value="10" class="priority" min=1 max=10></div>';
        content+='<div class="row"><textarea name="description" id="activdeta" class="description"></textarea></div>';
        var action = '<span id="confirmacti">Confirm</span>';
        mbox(title,content,action);
        pagevar.newactiv.newactivform();
        pageaction.texteditor();
        
        atypebox.acttypeadderaction();
        
        this.mboxactionmenu();
        
        $('#confirmacti').on('click',function(event){
            event.stopPropagation();
            
            pagevar.newactiv.submitedited();
        });
    },
    newactivity:function(elem,rareitystart){
        if(rareitystart===false){
            var time = $(elem).attr('class').split(' ')[1].split('_')[1]+':00:00';
            var tdate = $(elem).parent().prev().find('.tablecell').html().split('<br>')[1];
            
            pagevar.newactiv = new activity({id:false,name:"name",description:"description",type:"type",date:tdate,time:time,duration:30,priority:5});            
        }
        else{
            pagevar.newactiv = new activity({id:false,name:"name",description:"description",type:"type",date:rareitystart.date,time:rareitystart.time,duration:30,priority:5});            
        }
        var title = 'New Activity';
        var content = '<div class="row multiinput double"><input type="text" name="date" value="date" class="date first"><input type="text" name="time" value="time" class="time"></div>';
        content+='<div class="row"><input type="text" name="name" value="name" class="name"></div>';
        content+='<div class="row"><input type="hidden" value="type" id="acttypeexclusive" class="type acttypeexclusive"><input type="text" name="type" value="type" class="acttype exclusive" id="acttypeadder"></div>';
        content+='<div class="row"><select name="recurring type" class="recurring">'+pagevar.recurringtypestr()+'</select></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="duration in minutes" class="disabled first borderless duinwhat"><input type="number" value="30" name="duration" class="duration"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="priority" class="disabled first borderless ten"><input type="number" name="priorityinput" value="10" class="priority" min=1 max=10></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="alarm" class="disabled first borderless ten"><input type="number" name="alarminput" value="0" class="alarm" min=0></div>';
        content+='<div class="row"><textarea name="description" id="activdeta" class="description"></textarea></div>';
        var action = '<span id="suggestnewact">Suggestions</span><span id="confirmacti">Confirm</span>';
        mbox(title,content,action);
        pagevar.newactiv.newactivform();
        pageaction.texteditor();
        
        atypebox.acttypeadderaction();
        
        
       this.mboxactionmenu(); 
       
        $('#confirmacti').on('click',function(event){
            event.stopPropagation();
            
            pagevar.newactiv.submitedited();
        });
        
        $('#suggestnewact').on('click',function(event){
            event.stopPropagation();
            
            activsuggestion.definebound({date:pagevar.newactiv.date,time:pagevar.newactiv.time,duration:pagevar.newactiv.duration,type:$('#messagebox').find('.type').val()});
            activsuggestion.dbox();
        });
    }
};

var suggestionsinstance = function(bound){
    this.bounds = bound;
};
suggestionsinstance.prototype.displayresult = function(){
    var title   = 'Activity Suggestions';
    var content = this.cachedcontent;
    var action  = '<span id="loadmoresuggest" class="">Load More</span><span id="suggestactagain" class="left">&larr; Back</span>';
    
    mbox(title,content,action,'xxl');
    
    if(activsuggestion.sresults.bounds.loadmore === false){
        $('#loadmoresuggest').addClass('disabled');
    }
    
    $('#suggestactagain').on('click',function(event){
        event.stopPropagation();
        
        activsuggestion.boundidx-=1;
        activsuggestion.dbox();
    });
    
    $('#loadmoresuggest').on('click',function(event){
        event.stopPropagation();
        
        if($(this).attr('class').indexOf('disabled') !== -1){
            return;
        }
        
        activsuggestion.sresults.loadmore();
    });        
    
    $('#messageboxcontent').delegate('.suggrow','click',function(event){
        event.stopPropagation();
            
        if(pagevar.activityinedit===false){
            pagevar.activityinedit = [];
        }
        pagevar.activityinedit.id = $(this).attr('id').split('_')[1];
        $('#messagebox').addClass('loading');
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'searchactivity',a:'getactivity',d:{id:pagevar.activityinedit.id}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            msg.result.date = msg.result.time.split(' ')[0];
            msg.result.time = msg.result.time.split(' ')[1];
            
            pagevar.activityinedit = new activity(msg.result);
            pagevar.activityinedit.searchresult = 'suggestions';
            pageaction.detailsofact_(); 
        });
    });
};
suggestionsinstance.prototype.calchour = function(acttime){
    acttime = acttime.split(' ')[1];
    acttime = parseInt(acttime.split(':')[0])+(parseInt(acttime.split(':')[1])/60);
    acttime = Math.abs(this.thehour-acttime);
    
    if(acttime > 4.5){
        return 'fardistant';
    }
    return 'neardistant';
};
suggestionsinstance.prototype.sendreq = function(){
    this.thehour = parseInt(this.bounds.time.split(':')[0])+(parseInt(this.bounds.time.split(':')[1])/60);
    var thissuggestion = this;
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'searchactivity',a:'suggestactivity',d:this.bounds}    
    }).done(function(msg){
        msg = JSON.parse(msg);
        
        var title = 'Activity Suggestions';
        var content='';
        var restype = '';
        var zoning = '';
        var anhour = false;
        var distance = false;
        if(msg.results.length)
        for(var i=0;i<msg.results.length;i++){
            restype = atypebox.atname(msg.results[i].type);
            anhour = parseInt(msg.results[i].time.split(' ')[1].split(':')[0]);
            if(anhour>=3 && anhour <=10){
                zoning = ' morning';
            }
            else if(anhour>=11 && anhour <=17){
                zoning = ' noonandafter';
            }
            else{
                zoning = ' night';
            }
            content += '<div class="row suggrow'+zoning+' '+thissuggestion.calchour(msg.results[i].time)+'" id="suggrow_'+msg.results[i].id+'"><span class="suggtitle">'+msg.results[i].name+'</span><span class="suggdur">'+msg.results[i].duration+'</span><span class="suggtype">'+restype+'</span><span class="suggdesc">'+msg.results[i].descriptiontext+'</span><span class="suggtime">'+msg.results[i].time+'</span></div>';
            activsuggestion.sresults.cachedcontent = content;
        }
        else{
            content='no suggestions with the given criteria is available at the time';
            activsuggestion.sresults.cachedcontent = content;
        }
        var action = '<span id="loadmoresuggest" class="">Load More</span><span id="suggestactagain" class="left">&larr; Back</span>';
        mbox(title,content,action,'xxl');
        $('#messagebox').removeClass('loading');
        
        $('#suggestactagain').on('click',function(event){
            event.stopPropagation();
            
            activsuggestion.boundidx-=1;
            activsuggestion.dbox();
        });
        
        $('#loadmoresuggest').on('click',function(event){
            event.stopPropagation();
            
            if($(this).attr('class').indexOf('disabled') !== -1){
                return;
            }
            activsuggestion.sresults.loadmore();
        });        
        
        $('#messageboxcontent').delegate('.suggrow','click',function(event){
            event.stopPropagation();
            activsuggestion.clicksuggrow(this);
        });
    });
};
suggestionsinstance.prototype.loadmore = function(){
    if(typeof this.bounds.loadmore !=='undefined'){
        if(this.bounds.loadmore!==false)
            this.bounds.loadmore+=20;
    }
    else{
        this.bounds.loadmore = 20;
    }
    var thissuggestion = this;
    $('#messagebox').addClass('loading');
    var anhour,zoning;
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'searchactivity',a:'suggestactivity',d:this.bounds}    
    }).done(function(msg){
        msg = JSON.parse(msg);
        var content='';
        var restype = '';
        if(msg.results.length){
            for(var i=0;i<msg.results.length;i++){
                restype = atypebox.atname(msg.results[i].type);
                anhour = parseInt(msg.results[i].time.split(' ')[1].split(':')[0]);
                if(anhour>=3 && anhour <=10){
                    zoning = ' morning';
                }
                else if(anhour>=11 && anhour <=17){
                    zoning = ' noonandafter';
                }
                else{
                    zoning = ' night';
                }
                content += '<div class="row suggrow'+zoning+' '+thissuggestion.calchour(msg.results[i].time)+'" id="suggrow_'+msg.results[i].id+'"><span class="suggtitle">'+msg.results[i].name+'</span><span class="suggdur">'+msg.results[i].duration+'</span><span class="suggtype">'+restype+'</span><span class="suggdesc">'+msg.results[i].descriptiontext+'</span><span class="suggtime">'+msg.results[i].time+'</span></div>';
            }
            activsuggestion.sresults.cachedcontent += content;
            $('#messageboxcontent').find('.tablecell').html(activsuggestion.sresults.cachedcontent);
            $('#messagebox').removeClass('loading');
        }
        else{
            dialogbox.dispmsg('no more suggestions available',true);
            $('#messageboxaction').find('#loadmoresuggest').addClass('disabled');
            activsuggestion.sresults.bounds.loadmore = false;
            $('#messagebox').removeClass('loading');
        }      
    });
};
var activsuggestion = {
    sbound:[],
    boundidx:0,
    sresults:false,
    clicksuggrow:function(elem){
        if(pagevar.activityinedit===false){
            pagevar.activityinedit = [];
        }
        pagevar.activityinedit.id = $(elem).attr('id').split('_')[1];
        $('#messagebox').addClass('loading');
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'searchactivity',a:'getactivity',d:{id:pagevar.activityinedit.id}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            msg.result.date = msg.result.time.split(' ')[0];
            msg.result.time = msg.result.time.split(' ')[1];
            
            pagevar.activityinedit = new activity(msg.result);
            pagevar.activityinedit.searchresult = 'suggestions';
            pageaction.detailsofact_(); 
        });
    },
    definebound:function(bound){
        this.sbound[this.sbound.length] = bound;
    },
    refinebound:function(){
        this.sbound[this.boundidx-1].date = $('#messagebox').find('.date').val();
        this.sbound[this.boundidx-1].time = $('#messagebox').find('.time').val();
        this.sbound[this.boundidx-1].duration = $('#messagebox').find('.duration').val();
        this.sbound[this.boundidx-1].type = $('#messagebox').find('.type').val();
    },
    bounddata:function(){
        return {date:this.sbound[this.boundidx-1].date,time:this.sbound[this.boundidx-1].time,duration:this.sbound[this.boundidx-1].duration,type:this.sbound[this.boundidx-1].type};
    },
    dbox:function(){
        var title = 'Suggest an Activity';
        var content = '<div class="row multiinput double"><input type="text" name="date" value="date" class="date first"><input type="text" name="time" value="time" class="time"></div>';
         content+='<div class="row"><select name="type" class="type">'+atypebox.activitytypeoption(false)+'</select></div>';
         content+='<div class="row multiinput double"><input type="text" disabled="true" value="duration in minutes" class="disabled first borderless duinwhat"><input type="number" value="30" name="duration" class="duration"></div>';
        var action = '<span id="suggestactnow">Confirm</span>';
        mbox(title,content,action,'extrawide');
        
        this.dboxinit();
        
        $('#suggestactnow').on('click',function(event){
            event.stopPropagation();
            
            activsuggestion.refinebound();
            activsuggestion.sresults = new suggestionsinstance(activsuggestion.bounddata());
            
            $('#messagebox').addClass('loading');
            activsuggestion.sresults.sendreq();
        });
        
        $('#messagebox').find('.date').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                activsuggestion.refinebound();
                activsuggestion.sresults = new suggestionsinstance(activsuggestion.bounddata());
                
                $('#messagebox').addClass('loading');
                activsuggestion.sresults.sendreq();   
            }
        });
        
        $('#messagebox').find('.time').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                activsuggestion.refinebound();
                activsuggestion.sresults = new suggestionsinstance(activsuggestion.bounddata());
                
                $('#messagebox').addClass('loading');
                activsuggestion.sresults.sendreq();   
            }
        });
        
        $('#messagebox').find('.duration').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                activsuggestion.refinebound();
                activsuggestion.sresults = new suggestionsinstance(activsuggestion.bounddata());
                
                $('#messagebox').addClass('loading');
                activsuggestion.sresults.sendreq();   
            }
        });
    },
    dboxinit:function(){
        if(this.sbound.length-1 != this.boundidx){
            this.definebound({date:pagevar.cact.date,time:pagevar.cact.time,duration:30,type:'type'});
        }
        $('#messagebox').find('.date').val(this.sbound[this.boundidx].date).addClass('filled');
        $('#messagebox').find('.time').val(this.sbound[this.boundidx].time).addClass('filled');
        $('#messagebox').find('.type').val(this.sbound[this.boundidx].type).addClass('filled');
        $('#messagebox').find('.duration').val(this.sbound[this.boundidx].duration).addClass('filled');
        
        this.boundidx++;
    }
};

var activity = function(activ){
    this.id=activ.id;
    this.name=activ.name;
    this.description=activ.description;
    this.type=activ.type;
    this.date=typeof activ.date !== 'undefined' ? activ.date : false;
    this.time=typeof activ.time !== 'undefined' ? activ.time : false;
    this.parentactivity=typeof activ.parentactivity !== 'undefined' ? activ.parentactivity : 0;
    this.duration=typeof activ.duration !== 'undefined' ? activ.duration : 'duration in minutes';
    this.priority=typeof activ.priority !== 'undefined' ? parseInt(activ.priority) : 5;
    this.alarm=typeof activ.alarm !== 'undefined' ? parseInt(activ.alarm) : 0;
    this.recurring=typeof activ.recurring !== 'undefined' ? activ.recurring : (typeof activ.recurringtype !=='undefined' ? activ.recurringtype :"recurring type");
    this.durationlineonly = typeof activ.durationlineonly !== 'undefined' ? true : false;
    this.cost = typeof activ.cost !== 'undefined' ? activ.cost : 0;
    
    if(this.time===false)
        return;
    
    var ctime = this.time.split(':');
    if(ctime[0].length == 1){
        ctime[0]='0'+ctime[0];
        this.time = ctime.join(':');
    }
};
activity.prototype.drawday = function(){
    var tdate;
    var tisact = this;
    $.each($('.theday'),function(ti,te){
        tdate = $(te).find('.tablecell');
        
        if($(tdate).html().split('<br>')[1]==tisact.date){
            $(te).addClass('alldayevent');
            $(te).next().addClass('alldayevent');
            var dayid;
            dayid = 'ade_'+tisact.id;
            $(te).prop('id',dayid);
            $(te).addClass(pagevar.activtypename(tisact.type).split(' ').join(''));
            return false;
        }
    });
    
    if(typeof $('#ade_'+tisact.id).attr('class') !== 'undefined' && $('#ade_'+tisact.id).attr('class').indexOf(' false') !==-1){
        if($('#ade_'+tisact.id).attr('class').indexOf('thisday')===-1)
            atypebox.coloring(tisact);
    }
};
activity.prototype.drawdurationlineonly = function(){
    var boxtime = parseInt(this.time.split(':')[0]);
    var box = $('#scrollcontainer').find('.aday').eq(0).find('.anhour_0').eq(0);
    $(box).append(this.calitem());
    var calitemwid = $('#calitem_'+this.id).width();
    var boxheight = $('#calitem_'+this.id).parent().height();
    var boxwidth = $('#calitem_'+this.id).parent().width();
    $('#calitem_'+this.id).remove();
    
    var boxtimeoffset = (parseInt(this.time.split(':')[1])/60)*boxwidth;
    var aminutewidth = ($(box).width()/60);
    var durationwidth = aminutewidth*this.duration;
    var boxwidthleft = ((24-boxtime)*boxwidth)-boxtimeoffset;
    roundrtopoffset = (boxheight-$('#calitem_'+this.id).height())/2;
    durationnextday = (boxwidthleft-durationwidth);
    
    durationnextday=(durationnextday-(durationnextday*2));
    $('#dayinaweek').find('.aday').eq(0).children('.hourinaday').append(this.durationline(durationnextday,roundrtopoffset));
    if($('#calitemnextday_'+this.id).attr('class').indexOf('false') !== -1){
        atypebox.coloring(this);
    }
};
activity.prototype.previewdrawing = function(contentdiv){
    var tisact = this;
    var boxtime = 16;
    $(contentdiv).html(tisact.calitem());
    $('#calitemtitletester').html(tisact.name);
    $('#calitem_'+tisact.id).children('.calitemtitle').css('width',Math.min(205,$('#calitemtitletester').width())+'px');
    
    var calitemwid = $('#calitem_'+tisact.id).width();
    var boxheight = $('#calitem_'+tisact.id).parent().height();
    var boxwidth = $('#calitem_'+tisact.id).parent().width();
    var boxtimeoffset = (parseInt(tisact.time.split(':')[1])/60)*boxwidth;
    var aminutewidth = ($(contentdiv).width()/60);
    var durationwidth = aminutewidth*tisact.duration;
    var boxwidthleft = ((24-boxtime)*boxwidth)-boxtimeoffset;
    roundrtopoffset = (boxheight-$('#calitem_'+tisact.id).height())/2;
    
    $('#calitem_'+tisact.id).children('.calitemdur').css('width',durationwidth+'px');
    $('#calitem_'+tisact.id).children('.calitemdur').css('margin-left',(0-(calitemwid/2))+'px');
    
    $('#calitem_'+tisact.id).css('left',boxtimeoffset+'px');
    $('#calitem_'+tisact.id).css('top',roundrtopoffset+'px');
    
    if(Math.max(calitemwid,$('#calitem_'+tisact.id).children('.calitemtitle').width()) != calitemwid){
        var margleft = 0-(($('#calitem_'+tisact.id).children('.calitemtitle').width()-calitemwid)/2);
        $('#calitem_'+tisact.id).children('.calitemtitle').css('margin-left',margleft+'px');
    }
    atypebox.coloring(tisact);
};
activity.prototype.drawstartrareity = function(){
    var tisact = this;
    var durationnextday=0;
    var appendedtopage=false;
    var roundrtopoffset=0;
    var boxtime,box,calitemwid,boxheight,boxwidth,boxtimeoffset,aminutewidth,durationwidth,boxwidthleft,margleft,tdate;
    $.each($('.theday'),function(ti,te){
        tdate = $(te).find('.tablecell');
        
        if($(tdate).html().split('<br>')[1]==tisact.date){
            boxtime = parseInt(tisact.time.split(':')[0]);
            box = $(te).next().children('.anhour_'+boxtime);
            $(box).append('<span class="calitem startrareity" id="calitem_'+tisact.id+'">'+tisact.getend()+'<span class="calitemtitle">'+tisact.name+'</span><span class="roundr"></span></span>');
            $('#calitemtitletester').html(tisact.name);
            $('#calitem_'+tisact.id).children('.calitemtitle').css('width',Math.min(205,$('#calitemtitletester').width())+'px');
            
            calitemwid = $('#calitem_'+tisact.id).width();
            boxheight = $('#calitem_'+tisact.id).parent().height();
            boxwidth = $('#calitem_'+tisact.id).parent().width();
            boxtimeoffset = (parseInt(tisact.time.split(':')[1])/60)*boxwidth;
            aminutewidth = ($(box).width()/60);
            durationwidth = aminutewidth*tisact.duration;
            boxwidthleft = ((24-boxtime)*boxwidth)-boxtimeoffset;
            roundrtopoffset = (boxheight-$('#calitem_'+tisact.id).height())/2;
            
            durationnextday = (boxwidthleft-durationwidth);
            

            $('#calitem_'+tisact.id).find('.calitemdurtext').css('right','-98px');
            
            $('#calitem_'+tisact.id).children('.calitemdur').css('width',durationwidth+'px');
            $('#calitem_'+tisact.id).children('.calitemdur').css('margin-left',(0-(calitemwid/2))+'px');
            
            $('#calitem_'+tisact.id).css('left',boxtimeoffset+'px');
            $('#calitem_'+tisact.id).css('top',roundrtopoffset+'px');
            
            $('#calitem_'+tisact.id).children('.calitemtitle').css('min-width','10px');
            
            if(Math.max(calitemwid,$('#calitem_'+tisact.id).children('.calitemtitle').width()) != calitemwid){
                margleft = 0-(($('#calitem_'+tisact.id).children('.calitemtitle').width()-calitemwid)/2);
                $('#calitem_'+tisact.id).children('.calitemtitle').css('margin-left',margleft+'px');
            }
            else{
                margleft = (calitemwid-$('#calitem_'+tisact.id).children('.calitemtitle').width())/2;
                $('#calitem_'+tisact.id).children('.calitemtitle').css('margin-left',margleft+'px');
            }
            appendedtopage=true;
            
            clearTimeout(pagevar.cacttimer);
            pagevar.cacttimer = setTimeout(pagevar.updatecact,60000);
            
            return false;
        }
    });
    return appendedtopage;
};
activity.prototype.drawcalendar = function(){
    if(this.type=='startrareity'){
        this.drawstartrareity();
        return;
    }
    if(this.durationlineonly){
        this.drawdurationlineonly();
        return;
    }
    if(this.duration == 1440 || this.duration == 'all day'){
        this.drawday();
        return;
    }
    
    var tisact = this;
    var durationnextday=0;
    var appendedtopage=false;
    var roundrtopoffset=0;
    var tdate,boxtime,box,tispriosize,calitemwid,boxheight,boxwidth,boxtimeoffset,aminutewidth,durationwidth,boxwidthleft,righttext,margleft,drawn;
    $.each($('.theday'),function(ti,te){
        tdate = $(te).find('.tablecell');
        
        if($(tdate).html().split('<br>')[1]==tisact.date){
            boxtime = parseInt(tisact.time.split(':')[0]);
            box = $(te).next().children('.anhour_'+boxtime);
            if($(box).children('.calitem').length){
                drawn = false;
                $.each($(box).children('.calitem'),function(ci,ce){
                    if(parseInt($(ce).find('.watch').html().split(':')[1]) >= parseInt(tisact.time.split(':')[1])){
                        $(ce).before(tisact.calitem());
                        drawn = true;
                        return false;
                    }
                });
                if(drawn === false){
                    $(box).append(tisact.calitem());
                }
            }
            else
                $(box).append(tisact.calitem());
            
            
            tispriosize = tisact.priosize();
            $('#calitem_'+tisact.id).css('width',tispriosize+'px');
            $('#calitem_'+tisact.id).css('height',tispriosize+'px');
            $('#calitem_'+tisact.id).find('span').css('line-height',tispriosize+'px');
            $('#calitemtitletester').html(tisact.name);
            $('#calitem_'+tisact.id).children('.calitemtitle').css('width',Math.min(205,$('#calitemtitletester').width())+'px');
            
            calitemwid = $('#calitem_'+tisact.id).width();
            boxheight = $('#calitem_'+tisact.id).parent().height();
            boxwidth = $('#calitem_'+tisact.id).parent().width();
            boxtimeoffset = (parseInt(tisact.time.split(':')[1])/60)*boxwidth;
            aminutewidth = ($(box).width()/60);
            durationwidth = aminutewidth*tisact.duration;
            boxwidthleft = ((24-boxtime)*boxwidth)-boxtimeoffset;
            roundrtopoffset = (boxheight-$('#calitem_'+tisact.id).height())/2;
            
            durationnextday = (boxwidthleft-durationwidth);
            if(durationnextday<0){
                durationwidth = boxwidthleft+boxtimeoffset+(24-boxtime);
                $('#calitem_'+tisact.id).find('.calitemdurtext').css('display','none');
            }
            else{
                durationwidth += Math.ceil(tisact.duration/60);
                if(durationwidth <= (tispriosize/2)){
                     righttext = durationwidth+tispriosize+Math.ceil(tisact.duration/60);
                }
                else{
                    righttext = durationwidth+Math.ceil(tisact.duration/60);
                }
                $('#calitem_'+tisact.id).find('.calitemdurtext').css('left',righttext+'px');
                $('#calitemtitletester').html($('#calitem_'+tisact.id).find('.calitemdurtext').html());
                $('#calitem_'+tisact.id).find('.calitemdurtext').css('width',$('#calitemtitletester').width()+'px');
            }
            
            $('#calitem_'+tisact.id).children('.calitemdur').css('width',durationwidth+'px');
            $('#calitem_'+tisact.id).children('.calitemdur').css('margin-left',(0-(calitemwid/2))+'px');
            
            $('#calitem_'+tisact.id).css('left',boxtimeoffset+'px');
            $('#calitem_'+tisact.id).css('top',roundrtopoffset+'px');
            
            if(boxtime!=0){
                if(Math.max(calitemwid,$('#calitem_'+tisact.id).children('.calitemtitle').width()) != calitemwid){
                    margleft = 0-(($('#calitem_'+tisact.id).children('.calitemtitle').width()-calitemwid)/2);
                    $('#calitem_'+tisact.id).children('.calitemtitle').css('margin-left',margleft+'px');
                }
            }
            else{
                $('#calitem_'+tisact.id).children().css('text-align','left');
            }
            appendedtopage=true;
            
            return false;
        }
    });
    
    if(durationnextday<0){
        durationnextday=(durationnextday-(durationnextday*2));
        this.drawthenextdays(boxwidth,tdate,durationnextday,roundrtopoffset,boxwidthleft);
    }
    else{
        var durationlineonlyact = pagevar.existdurationlineonly(tisact.id);
        if(durationlineonlyact!==false){
            pagevar.deletedurationlineonly(tisact);
        }
    }
    if(typeof $('#calitem_'+tisact.id).attr('class') !== 'undefined' && $('#calitem_'+tisact.id).attr('class').indexOf(' false') !==-1){
        atypebox.coloring(tisact);
    }
    
    return appendedtopage;
};
activity.prototype.drawthenextdays = function(boxwidthx,tdate,durationnextday,roundrtopoffset,boxwidthleftx){
    var tdatex = tdate;
    var durtext = true;
    if(typeof $(tdatex).parent().parent().parent().next().attr('class') !=='undefined' && $(tdatex).parent().parent().parent().next().attr('class').indexOf('aday') !==-1){
        var linewidth=0;
        if(durationnextday >= (24*boxwidthx)){
            durtext = false;
            linewidth += (24*boxwidthx);
            
            durationnextday = (durationnextday-linewidth);
            linewidth += 24;
            this.drawthenextdays(boxwidthx,$(tdatex).parent().parent().parent().next().find('.theday').find('.tablecell').eq(0),durationnextday,roundrtopoffset,0);
        }
        else{
           linewidth += durationnextday;
           linewidth += Math.ceil(linewidth/boxwidthx);
        }   
        
        $(tdatex).parent().parent().parent().next().find('.hourinaday').eq(0).append(this.durationline(linewidth,roundrtopoffset));
        if(!durtext){
            $(tdatex).parent().parent().parent().next().find('.hourinaday').find('#calitemnextday_'+this.id).find('.calitemdurtext').css('display','none');
        }
        else{
            var ddate = this.date.split('-');
            var dtime = this.time.split(':');
            ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
            
            ddate.setMinutes(ddate.getMinutes()+this.duration);
            $(tdatex).parent().parent().parent().next().find('.hourinaday').find('#calitemnextday_'+this.id).find('.endtime').html(((ddate.getHours()+'').length==1? ('0'+ddate.getHours()) : ddate.getHours()) +':'+ ((ddate.getMinutes()+'').length==1 ? '0'+ddate.getMinutes() : ddate.getMinutes()));
        }
    }
    else{
        var durationlineonlyact = pagevar.existdurationlineonly(this.id);
        if(durationlineonlyact===false){
            durationlineonlyact = new activity(this);
            durationlineonlyact.durationlineonly = true;
            pagevar.adddurationlineonlyact(durationlineonlyact);
        }
        else{
            pagevar.editdurationlineonlyact(this);
        }   
    }
}
activity.prototype.durationline = function(widthvar,roundrtopoffset){
    return '<span id="calitemnextday_'+this.id+'" class="'+pagevar.activtypename(this.type)+' calitemdur nextday calitemnextday_'+this.id+'" style="left:'+pagevar.thedaywidth+'px;width:'+widthvar+'px;bottom:'+roundrtopoffset+'px">'+this.getend()+'<span class="calitemtitle">'+this.name+'</span></span>';
},
activity.prototype.delete = function(){
    if(this.id==0){
        pagevar.deleteactivity(this.id);
        dialogbox.close();
        return;
    }
    var thisact = this;
    var postdata = this.postdata();
        if(typeof thisact.todolistitem !== 'undefined'){
            postdata.todolistitem = true;
        }
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'activityc',a:'deleteact',d:postdata}
    }).done(function(msg){
        msg = JSON.parse(msg);
            
            if(typeof thisact.todolistitem !== 'undefined'){
                todolist.postdelete(msg);
                return;
            }
            
        if(msg.result){
            if(thisact.duration == 1440 || thisact.duration=='all day'){
                if(typeof $('#ade_'+thisact.id).attr('id') !== 'undefined'){
                    $('#ade_'+thisact.id).next().removeClass('alldayevent');
                    $('#ade_'+thisact.id).prop('class','theday');
                    $('#ade_'+thisact.id).css('background','');
                    $('#ade_'+thisact.id).find('.addadeactiv').css('display','');
                    $('#ade_'+thisact.id).prop('id','');   
                }
            }
            var title = 'Delete Activity';
            var content = '<div class="row">Deletion Was Successful</div>';
            var action = '';
            mbox(title,content,action,'narrow');
            pagevar.deleteactivity(thisact.id);
            if(thisact.recurring!=0){
                pagevar.rarifyrecurring(thisact);
            }
        }
    });
};
activity.prototype.getend = function(){
    var watchtext;
    var timed = this.time+'';
    var timex = timed.split(':');
    var costifany = this.cost == 0 ? '' : '<span class="costifany">['+rarecost.format(this.cost)+']</span>';
    for(var i=0;i<timex.length;i++){
        timex[i]+='';
        if(timex[i].length==1){
            timex[i]='0'+timex[i];
        }
    }
    watchtext = timex[0]+':'+timex[1];
    if(this.time !== false && this.duration != 'duration in minutes' && this.duration != 0){
        timex.splice(2,1);
        timex[0] = parseInt(timex[0]);
        timex[1] = parseInt(timex[1]);
        var min = timex[1]+parseInt(this.duration);
        if(min>59){
            timex[0]+=Math.floor(min/60);
            min=min%60;
            if(timex[0]>23){
                timex[0] -= 24; 
            }
        }
        timex[1] = min;
        for(var i=0;i<timex.length;i++){
            timex[i]+='';
            if(timex[i].length==1){
                timex[i]='0'+timex[i];
            }
        }
        return '<span class="calitemdur"><span class="calitemdurtext"><span>'+this.duration+'(</span><span class="watch">'+watchtext+'</span><span> - </span><span class="endtime">'+timex.join(':')+'</span><span>)</span>'+costifany+'</span></span>';
    }
    return '<span class="calitemdur"><span class="calitemdurtext"><span class="watch">('+watchtext+')</span>'+costifany+'</span></span>';
};
activity.prototype.priosize = function(){
    return viewopts.anodesize(this.priority,this.duration);
};
activity.prototype.priostyle = function(){
    return pagevar.priostyle[this.priority-1];
};
activity.prototype.calitem = function(){
    return '<span class="calitem '+pagevar.activtypename(this.type)+' '+this.priostyle()+'" id="calitem_'+this.id+'">'+this.getend()+'<span class="calitemtitle">'+this.name+'</span><span class="whiteroundr"></span><span class="roundr"></span></span>';
};
activity.prototype.stopacting = function(){
    var ddate = this.date.split('-');
    var dtime = this.time.split(':');
    ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
    var countdown = Math.round(((pagevar.thetime - ddate)/1000)/60);
    
    this.duration = countdown;
    
    $('#messagebox').find('.duration').val(this.duration);
    this.submitedited();
    $('#stopacting').remove();
};
activity.prototype.stopmenu = function(){
    var ddate = this.date.split('-');
    var dtime = this.time.split(':');
    ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
    var countdown = (((pagevar.thetime - ddate)/1000)/60);
    if(countdown<0){
        if(typeof $('#messagebox').find('#stopacting').attr('class') !== 'undefined'){
            $('#stopacting').remove();
        }
        return false;
    }
    if(countdown < this.duration){
        if(typeof $('#messageboxaction').find('#stopacting').attr('class') === 'undefined'){
            $('#messageboxaction').append('<span class="left" id="stopacting">Stop</span>');
            $('#stopacting').on('click',function(event){
                event.stopPropagation();
                
                pagevar.activityinedit.stopacting();
            });
        }
            
        return true;
    }
    else{
        if(typeof $('#messagebox').find('#stopacting').attr('class') !== 'undefined'){
            $('#stopacting').remove();
        }
        return false;
    }
};
activity.prototype.edittodoform = function(){
    if(this.name !='name'){
        $('#messagebox').find('.name').val(this.name).addClass('filled');
    }
        if(this.description == 'description')
            $('#messagebox').find('.description').val(this.description);
        else
            $('#messagebox').find('.description').val(this.description).addClass('filled');  
        
    var restype = '';
    restype = atypebox.atname(this.type);
    $('#messagebox').find('.acttype').val(restype).addClass('filled');
    $('#messagebox').find('#acttypeexclusive').val(this.type);
        
    $('#messagebox').find('.duration').val(this.duration).addClass('filled');
        
    
    $('#messagebox').find('.priority').val(this.priority).addClass('filled');
    $('#messagebox').find('.priority').prev().css('opacity',(this.priority/10));
};
activity.prototype.editform = function(){
    if(this.name !='name'){
        $('#messagebox').find('.name').val(this.name).addClass('filled');
    }
    
        if(this.description == 'description' || this.description == ''){
            if($('#messagebox').find('.description').attr('class').indexOf('activdeta') !== -1)
                $('#messagebox').find('.description').html(this.description);
            else
                $('#messagebox').find('.description').val(this.description);
        }
        else{
            if($('#messagebox').find('.description').attr('class').indexOf('activdeta') !== -1)
                $('#messagebox').find('.description').html(this.description).addClass('filled'); 
            else
                $('#messagebox').find('.description').val(this.description).addClass('filled'); 
        }
        
    if(this.type !='type' && this.type !='startrareity'){
        $('#messagebox').find('.type').val(this.type).addClass('filled');
        $('#messagebox').find('.acttype').val(atypebox.atname(this.type)).addClass('filled');
        
        if(this.duration == 1440){
            $('#messagebox').find('.acttype').addClass('1440');
        }
        else{
            $('#messagebox').find('.acttype').removeClass('1440');
        }
    }
    else{
        $('#messagebox').find('.type').val(this.type);
        $('#messagebox').find('.acttype').val(atypebox.atname(this.type));
    }
        
    $('#messagebox').find('.duration').val(this.duration).addClass('filled');
        
    if(this.recurring !='recurring type' && this.recurring !=0)
        $('#messagebox').find('.recurring').val(this.recurring).addClass('filled');
    else
        $('#messagebox').find('.recurring').val(this.recurring);
        
    if(this.time!='false' && this.time !='time'){
        $('#messagebox').find('.time').val(this.time).addClass('filled');
    }
    if(this.date != 'false' && this.date!='date'){
        $('#messagebox').find('.date').val(this.date).addClass('filled');
    }
    
    if(this.cost == 0)
        $('#messagebox').find('#dcostvalue').val(this.cost);
    else
        $('#messagebox').find('#dcostvalue').val(this.cost).addClass('filled');
    
    $('#messagebox').find('.alarm').val(this.alarm).addClass('filled');
    
    $('#messagebox').find('.priority').val(this.priority).addClass('filled');
    $('#messagebox').find('.priority').prev().css('opacity',(this.priority/10));
};
activity.prototype.newactivform = function(){
    if(this.duration !='all day')
        $('#messagebox').find('.duration').val(this.duration);
    else{
        $('#messagebox').find('.duration').val(this.duration).addClass('filled');
    }
    
    if(this.time!==false){
        $('#messagebox').find('.time').val(this.time).addClass('filled');
        $('#messagebox').find('.date').val(this.date).addClass('filled');   
    }
    
    if(typeof $('#messagebox').find('.priority').attr('class') !== 'undefined'){
        $('#messagebox').find('.priority').val(this.priority);
    }
};
activity.prototype.postdata = function(){
    if(this.recurring=='recurring type'){
        this.recurring=0;
    }
    return {id:this.id,name:this.name,description:this.description,type:this.type,time:this.date+' '+this.time,alarm:this.alarm,duration:this.duration,recurringtype:this.recurring,parentactivity:this.parentactivity,priority:this.priority,cost:this.cost};
};
activity.prototype.gettdlformval = function(){
    this.name           = $('#messagebox').find('.name').val();
    if(ismobile)
        this.description    = $('#messagebox').find('.description').val();
    else
        this.description    = $('#messagebox').find('.activdeta').html();
        
    this.type           = $('#messagebox').find('.acttypeexclusive').val();
    this.duration       = $('#messagebox').find('.duration').val();
    this.priority       = $('#messagebox').find('.priority').val();
};
activity.prototype.start_tdl_item = function(){
    var tisact = this;
    var postdata = tisact.postdata();
    postdata.todolistitem = true;
    postdata.startnow = true;
    $('#messagebox').addClass('loading');
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'activityc',a:'submitform',d:postdata}
    }).done(function(msg){
        msg = JSON.parse(msg);
        tisact.parentactivity = 0;
        tisact.time = msg.time.split(' ')[1];
        tisact.date = msg.time.split(' ')[0];
        
        pagevar.addactivity(tisact);
        
        tisact.renewcact(msg);
        pagevar.checkactpos(tisact);
        tisact.drawcalendar();
        
        todolist.untodo();
        
        $('#messagebox').removeClass('loading');
        dialogbox.close();
    });
};
activity.prototype.checkalarm = function(){
    var ddate = this.date.split('-');
    var dtime = this.time.split(':');
    ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
    var countdown = (((ddate - pagevar.thetime)/1000)/60);
    if(countdown  <= 2880){
        this.alarming = true;
    }
    else{
        this.alarming = false;
    }
    
    if(this.alarming){
        this.alarming = false;
        setTimeout(function(){
            alarming.instalalarmreport = [];
            alarming.setalarm();
        },300);
    }
};
activity.prototype.confirmtiming = function(){
    if($('#messagebox').find('.time').val() == 'time' || $('#messagebox').find('.date').val()=='date'){
        dialogbox.dispmsg('please complete the form',true);
        return;
    }
    var tisdate = $('#messagebox').find('.date').val();
    tisdate = tisdate.split('-');
    if(tisdate.length <3){
        dialogbox.dispmsg('please complete the form',true);
        return;
    }
    for(var i=0;i<tisdate.length;i++){
        if(tisdate[i].length==1){
            tisdate[i]='0'+tisdate[i];
        }
    }
    this.date = tisdate.join('-');
    
    this.alarm          = $('#messagebox').find('.alarm').val();
    this.time           = $('#messagebox').find('.time').val(); 
    if(this.time.split(':').length == 2){
        this.time += ':00';
    }
    var tisact = this;
    var postdata = tisact.postdata();
    postdata.todolistitem = true;
    $('#messagebox').addClass('loading');
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'activityc',a:'submitform',d:postdata}
    }).done(function(msg){
        msg = JSON.parse(msg);
        tisact.parentactivity=0;
        tisact.renewcact(msg);
        var inpage = tisact.drawcalendar();
        if(inpage){
            pagevar.addactivity(tisact);
        }
        pagevar.checkactpos(tisact);
        tisact.checkalarm();
        
        var msgtext = 'Time For <b>'+todolist.editing.name+'</b> is Set to:'+tisact.date+' '+tisact.time;
        todolist.untodo();
 
        $('#messagebox').removeClass('loading');
        todolist.menubox();
        dialogbox.dispmsg(msgtext,true);
    });
};
activity.prototype.renewcact = function(msg){
    clearTimeout(pagevar.cacttimer);
    clearInterval(pagevar.clocktimer);
    pagevar.thetime = new Date(Date.parse(msg.currenttimejs));
    pagevar.clocktimer = setInterval(pagevar.setthetime,1000);
    if(typeof $('.calitem.startrareity').attr('class') !=='undefined'){
        $('.calitem.startrareity').remove();
    }
        
        pagevar.cact.time = pagevar.thetime.toTimeString().split(' ')[0];
        pagevar.cact.date = pagevar.getNow();
        pagevar.cact.drawcalendar();
};
activity.prototype.submittodolist = function(){
    this.gettdlformval();
    this.submittodolist_();
};
activity.prototype.submittodolist_ = function(){
    var tisact = this;
    $('#messagebox').addClass('loading');
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'todolist',a:'submitform',d:this.postdata()}
    }).done(function(msg){
        msg = JSON.parse(msg);
        
        if(tisact.id==false){
            todolist.postcreatemode = 0;
        }
        else{
            todolist.postcreatemode = 1;
        }
        todolist.postcreate(msg);
        $('#messagebox').removeClass('loading');
    });
};
activity.prototype.confirmedited = function(){
    if(this.name == 'name'){
        return;
    }
    dialogbox.close();
    
    
    if(typeof this.todolistitem !== 'undefined'){
        this.submittodolist_();
        return;
    }
    this.submitedited_();
};
activity.prototype.waseditedfn = function(){
    if(this.checkwasedited()!== false){
        this.waseditedfn_(false);
    }
};
activity.prototype.waseditedfn_ = function(calback){
    this.wasedited = false;
    pagevar.wasedited = this;
    
    var title   = 'Confirm Changes';
    var content = '<div class="row">Save changes?</div>';
    var action  = '<span id="discardediting" class="">Discard</span><span id="saveediting" class="">Save</span>';
    
    mbox(title,content,action,'narrow');
    $('#closemessagebox').addClass('hide');
    
    $('#discardediting').on('click',function(event){
        event.stopPropagation();
        
        pagevar.wasedited.recurring = pagevar.wasedited.oldvars.recurring;
        pagevar.wasedited.name = pagevar.wasedited.oldvars.name;
        pagevar.wasedited.description = pagevar.wasedited.oldvars.description;
        pagevar.wasedited.duration = pagevar.wasedited.oldvars.duration;
        pagevar.wasedited.priority = pagevar.wasedited.oldvars.priority;
        pagevar.wasedited.alarm = pagevar.wasedited.oldvars.alarm;
        pagevar.wasedited.time = pagevar.wasedited.oldvars.time;

        dialogbox.close();
        if(calback!==false){
            calback();
        }
    });
    
    $('#saveediting').on('click',function(event){
        event.stopPropagation();
        
        pagevar.wasedited.confirmedited();
        if(calback!==false){
            calback();
        }
    });
};
activity.prototype.checkwasedited = function(){
    this.oldvars = [];
    this.oldvars.recurring = typeof this.recurring !== 'undefined' ? (this.recurring == 0 ? 'recurring type' : this.recurring) : (typeof this.recurringtype !== 'undefined' ? this.recurringtype : 'recurring type');
    this.oldvars.name = this.name;
    this.oldvars.type = this.type;
    this.oldvars.description = this.description;
    this.oldvars.duration = this.duration;
    this.oldvars.priority = this.priority;
    this.oldvars.alarm = typeof this.alarm !== 'undefined' ? this.alarm : 0;
    this.oldvars.time = this.time;
    
    
    if(typeof this.todolistitem !== 'undefined'){
        this.gettdlformval();
    }
    else
        this.getformval();
    

    if(this.oldvars.name != this.name){
        this.wasedited = this.name;
        console.log('1'+this.wasedited+this.oldvars.name);
        return this.wasedited;
    }
    if(this.oldvars.type != this.type){
        console.log('2');
        this.wasedited = this.type;
        return this.wasedited;
    }
    if(this.oldvars.description != this.description && !(this.oldvars.description=='' && this.description =='description')){
        if($('#messagebox').find('.activdeta').attr('class').indexOf('dirty') !== -1){
            this.wasedited = this.oldvars.description+'<--->'+this.description;
            return this.wasedited;   
        }
    }
    if(this.oldvars.duration != this.duration){
        console.log('3');
        this.wasedited = this.duration;
        return this.wasedited;
    }
    if(this.oldvars.priority != this.priority){
        this.wasedited = this.priority;
        return this.wasedited;
    }
    
    if(typeof this.todolistitem === 'undefined' && this.oldvars.recurring != this.recurring){
        this.wasedited = this.recurring+'<>'+this.oldvars.recurring;
        return this.wasedited;
    }
    if(typeof this.todolistitem === 'undefined' && this.oldvars.alarm != this.alarm){
        this.wasedited = this.alarm;
        return this.wasedited;
    }
    if(typeof this.todolistitem === 'undefined' && this.oldvars.time != this.time){
        this.wasedited = this.time;
        return this.wasedited;
    }
    
    this.wasedited = false;
    return this.wasedited;
}
activity.prototype.getformval = function(){
    this.prevrecurring  = this.recurring;
    this.name           = $('#messagebox').find('.name').val();
    if(ismobile)
        this.description = $('#messagebox').find('.description').val();
    else{
        this.description = $('#messagebox').find('.activdeta').html()
        this.description = this.description == '<p>description</p>' ? 'description' : this.description;
    }
    this.type           = $('#messagebox').find('.type').val();
    this.duration       = $('#messagebox').find('.duration').val();
    this.priority       = $('#messagebox').find('.priority').val();
    this.alarm          = $('#messagebox').find('.alarm').val();
    
    if(typeof $('#messagebox').find('.time').attr('class') !== 'undefined'){
        this.time           = $('#messagebox').find('.time').val();   
    }
    if(this.time.split(':').length == 2){
        this.time += ':00';
    }
    if(typeof $('#messagebox').find('.date').attr('class') !== 'undefined'){
        this.date = $('#messagebox').find('.date').val();
        
        var ddate = this.date.split('-');
        var dtime = this.time.split(':');
        ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
        var countdown = (((ddate - pagevar.thetime)/1000)/60);
        if(countdown  <= 2880){
            this.alarming = true;
        }
        else{
            this.alarming = false;
        }
    }
    else{
        if(this.date !==false){
            var ddate = this.date.split('-');
            var dtime = this.time.split(':');
            ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
            var countdown = (((ddate - pagevar.thetime)/1000)/60);
            if(countdown  <= 2880){
                this.alarming = true;
            }
            else{
                this.alarming = false;
            }
        }
        else{
            this.alarming = false;
        }
    }
    this.recurring      = $('#messagebox').find('.recurring').val();
};
activity.prototype.handlecosting = function(){
    $('#messageboxaction').removeClass('costing');
    var cv = $('#messagebox').find('#dcostvalue').val();
    if(cv == '' || cv == 'cost'){
        cv = 0;
    }
    if(this.cost == cv){
        return;
    }
    this.cost = parseInt(cv);
    this.getformval();
    $('#messagebox').addClass('loading');
    var tisact = this;
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'activityc',a:'submitform',d:this.postdata()}
    }).done(function(msg){
        msg = JSON.parse(msg);
         if(tisact.duration=='all day' && typeof $('#ade_'+tisact.id).attr('class') !== 'undefined'){
            $('#ade_'+tisact.id).prop('class','theday');
            $('#ade_'+tisact.id).prop('id','');
            tisact.duration = 1440;
        }
        else if(typeof $('#calitem_'+tisact.id).attr('class') !=='undefined'){
            $('#calitem_'+tisact.id).remove();
            
            if(typeof $('#calitemnextday_'+tisact.id).attr('class') !== 'undefined'){
                $('#calitemnextday_'+tisact.id).remove();
            }
        }
        if(typeof $('#calitemnextday_'+tisact.id).attr('class') !== 'undefined'){
            $('#calitemnextday_'+tisact.id).remove();
        }
        if(tisact.id==false||tisact.id==0){
            tisact.id = msg.result;
            pagevar.addactivity(tisact);
        }
        pagevar.checkactpos(tisact);
        tisact.drawcalendar();
        if(typeof tisact.alarming !== 'undefined' && tisact.alarming){
            tisact.alarming = false;
            setTimeout(function(){
                alarming.instalalarmreport = [];
                alarming.setalarm();
            },300);
        }
        
        if(typeof msg.recurringedited !=='undefined' && msg.recurringedited && typeof msg.deleterecurring === 'undefined'){
            pagevar.resetforward();
        }
        if(typeof msg.weekly !=='undefined'){
            pagevar.updateactivity(msg.weekly);
        }
        else if(typeof msg.deleterecurring !== 'undefined'){
            pagevar.deleterecurring(tisact.id);
        }
         $('#messagebox').removeClass('loading');
         dialogbox.dispmsg('update saved',true);
    });
};
activity.prototype.beenthere = function(){
    if(typeof $('#calitem_'+this.id).attr('class') !=='undefined'){
        $('#calitem_'+this.id).addClass('beenthere');
    }
    if(typeof $('#calitemnextday_'+this.id).attr('class') !== 'undefined'){
        $('#calitemnextday_'+this.id).addClass('beenthere');
    }
    
    pageaction.recentbeenthere = this.postdata();
};
activity.prototype.submitedited_ = function(){
    var tisact = this;
    $('#messagebox').addClass('loading');
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'activityc',a:'submitform',d:this.postdata()}
    }).done(function(msg){
        msg = JSON.parse(msg);
        if(tisact.duration=='all day' && typeof $('#ade_'+tisact.id).attr('class') !== 'undefined'){
            $('#ade_'+tisact.id).prop('class','theday');
            $('#ade_'+tisact.id).prop('id','');
            tisact.duration = 1440;
        }
        else if(typeof $('#calitem_'+tisact.id).attr('class') !=='undefined'){
            $('#calitem_'+tisact.id).remove();
            
            if(typeof $('#calitemnextday_'+tisact.id).attr('class') !== 'undefined'){
                $('#calitemnextday_'+tisact.id).remove();
            }
        }
        if(typeof $('#calitemnextday_'+tisact.id).attr('class') !== 'undefined'){
            $('#calitemnextday_'+tisact.id).remove();
        }
        if(tisact.id==false||tisact.id==0){
            tisact.id = msg.result;
            pagevar.addactivity(tisact);
        }
        pagevar.checkactpos(tisact);
        tisact.drawcalendar();
        if(typeof tisact.alarming !== 'undefined' && tisact.alarming){
            tisact.alarming = false;
            setTimeout(function(){
                alarming.instalalarmreport = [];
                alarming.setalarm();
            },300);
        }
        
        if(typeof msg.recurringedited !=='undefined' && msg.recurringedited && typeof msg.deleterecurring === 'undefined'){
            pagevar.resetforward();
        }
        if(typeof msg.weekly !=='undefined'){
            pagevar.updateactivity(msg.weekly);
        }
        else if(typeof msg.deleterecurring !== 'undefined'){
            pagevar.deleterecurring(tisact.id);
        }
        $('#messagebox').removeClass('loading');
        
        if(dialogbox.title == 'New Activity'){
            pagevar.activityinedit = tisact;
            pageaction.detailsofact_();
        }
        tisact.stopmenu();
        if($('#messagebox').attr('class').indexOf('active') !== -1){
            dialogbox.dispmsg('Saved',true);    
        }
        else{
            $('.calitem.beenthere').removeClass('beenthere');
            tisact.beenthere();
        }
        
    });
};
activity.prototype.submitedited = function(){
    this.getformval();
    this.submitedited_();
};

var searchinstance = function(){
    this.keyword = 'keyword';
    this.category = [];
    this.submittedcat = 'category';
    this.results = [];
    this.submited = false;
    
            if(pagevar.gotomode){
                this.startdate = pagevar.gotocalendar[pagevar.gotocalendaridx].time[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage];
                this.enddate = pagevar.gotocalendar[pagevar.gotocalendaridx].timeend[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage];
            }
            else{
                this.startdate = pagevar.startdates[pagevar.calendaridx];
                this.enddate = pagevar.enddates[pagevar.calendaridx];
            }
};
searchinstance.prototype.setcrit = function(searchcrit){
    this.results = [];
    
    this.keyword = searchcrit.searchkey;
    this.category = searchcrit.scats;
    if(!this.category.length){
        this.submittedcat = 'category';
    }
    else{
        this.submittedcat = this.category.join('~');
    }
    this.startdate = searchcrit.sdate;
    this.enddate = searchcrit.edate;
};
searchinstance.prototype.getdata = function(){
    var postdata = {keyword:this.keyword,startdate:this.startdate,enddate:this.enddate,category:this.submittedcat,cost:this.cost};
    return postdata;
};
searchinstance.prototype.submitsearch = function(){
    if(this.startdate == 'start date' && this.enddate=='end date' && this.keyword == 'keyword' && this.category.length==0){
        dialogbox.dispmsg('please set the criteria',true);
        $('#messagebox').removeClass('loading');
        return;
    }
    
    var postdata = {keyword:this.keyword,startdate:this.startdate,enddate:this.enddate,category:this.submittedcat};
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'searchactivity',a:'submitsearch',d:postdata}
    }).done(function(msg){
        msg = JSON.parse(msg);
        
        for(var i=0;i<msg.results.length;i++){
            actfinder.searchobj.results[actfinder.searchobj.results.length] = msg.results[i];
        }
        if(!actfinder.searchobj.results.length){
            dialogbox.dispmsg('no activity with the given criteria was found');
            $('#messagebox').removeClass('loading');
            return;
        }
        actfinder.displaysearchresult();
    });
};
searchinstance.prototype.formfilling = function(){
    if(this.keyword=='keyword'){
        $('#messagebox').find('.keyword').val(this.keyword).removeClass('filled');
    }
    else{
        $('#messagebox').find('.keyword').val(this.keyword).addClass('filled');
    }
    if(this.startdate=='start date'){
        $('#messagebox').find('.sdate').val(this.startdate).removeClass('filled');
    }
    else{
        $('#messagebox').find('.sdate').val(this.startdate).addClass('filled');
    }
    if(this.enddate == 'end date'){
        $('#messagebox').find('.edate').val(this.enddate).removeClass('filled');
    }
    else{
        $('#messagebox').find('.edate').val(this.enddate).addClass('filled');
    }
    if(this.category.length){
        var restype;
        for(var c=0;c<this.category.length;c++){
            restype = atypebox.atname(this.category[c]);
            $('#searchcats').append('<span class="scats '+this.category[c]+'">'+restype+'<span class="deleteacttypeoptadded">X</span></span>');
        }
    }
};
var actfinder = {
    searchobj:false,
    acttypeoptinit:false,
    displaysearchresult:function(){
        var title   = 'Search Activities Result';
        var content = '';
        var restype = '';
        for(var i=0;i<this.searchobj.results.length;i++){
            restype = atypebox.atname(this.searchobj.results[i].type);
            content+='<div class="row sactres" id="sactres_'+this.searchobj.results[i].id+'"><span class="sacttitle">'+this.searchobj.results[i].name+'</span><span class="sacttype">'+restype+'</span><span class="sactdesc">'+this.searchobj.results[i].description+'</span><span class="sacttime">'+this.searchobj.results[i].time+'</span></div>';
        }
        var action  = '<span id="backtorel" class="left fullobtn">&larr; Back</span><span id="pdfactsearch" class="fullobtn">Export to PDF</span><span id="resetactsearch" class="fullobtn">New Search</span>';
        mbox(title,content,action,'xxl');
        
        $('#messagebox').removeClass('loading');
        
        $('#pdfactsearch').on('click',function(event){
            event.stopPropagation();
            
            rarepdf.pdfsearched();
        });
        
        $('#backtorel').on('click',function(event){
            event.stopPropagation();
            
            actfinder.searchbox();
        });
        
        $('#resetactsearch').on('click',function(event){
            event.stopPropagation();
            
            actfinder.searchobj=false;
            actfinder.searchbox();
        });
        $('#messagebox .sactres').on('click',function(event){
            event.stopPropagation();
            actfinder.clicksactres(this);
        });
    },
    clicksactres:function(elem){
        var siid = $(elem).attr('id').split('_')[1];
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'searchactivity',a:'getactivity',d:{id:siid}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            msg.result.date = msg.result.time.split(' ')[0];
            msg.result.time = msg.result.time.split(' ')[1];
            
            pagevar.activityinedit = new activity(msg.result);
            pagevar.activityinedit.searchresult = true;
            pageaction.detailsofact_(); 
        });
    },
    searchbox:function(){
        var title   = 'Search Activities';
        var content = '<div class="row"><input type="text" name="keyword" value="keyword" class="keyword"></div>';
        content += '<div class="row multiinput double"><input type="text" name="start date" value="start date" class="first sdate"><input type="text" name="end date" value="end date" class="edate espright"></div>';
        content += '<div class="row"><input type="text" name="activities type:" value="activities type:" class="acttype allandade" id="acttypeadder"></div>';
        content += '<div class="row" id="searchcats"></div>';
        
        var action  = '<span id="confirmsearch">Search</span>';
        mbox(title,content,action,'xxl');
    
        if(this.searchobj===false){
            this.searchobj = new searchinstance();
        }    
        actfinder.searchobj.formfilling();
        
        $('#messagebox').find('.keyword').on('keyup',function(event){
            event.stopPropagation();
            
            switch(event.which){
                case 13:
                    actfinder.searchact();
                break;
                case 27:
                    dialogbox.close();
                break;
                default:
                
            }
        });
        $('#messagebox').find('.sdate').on('keyup',function(event){
            event.stopPropagation();
            
            switch(event.which){
                case 13:
                    actfinder.searchact();
                break;
                case 27:
                    dialogbox.close();
                break;
                default:
                
            }
        });
        $('#messagebox').find('.edate').on('keyup',function(event){
            event.stopPropagation();
            
            switch(event.which){
                case 13:
                    actfinder.searchact();
                break;
                case 27:
                    dialogbox.close();
                break;
                default:
                
            }
        });
        $('#acttypeadder').on('focus',function(){
            actfinder.acttypefilteropt(this);
        });
        $('#acttypeadder').on('blur',function(){
            setTimeout(function(){
                $('#acttypeopt').remove();
            },300);
            
        });
        $('#searchcats').delegate('.deleteacttypeoptadded','click',function(event){
            event.stopPropagation();
            
            $(this).parent().remove();
        });
        $('#acttypeadder').on('keyup',function(){
            switch(event.which){
                case 13:
                    if(typeof $(this).parent().next().children('.selected').attr('class') !== 'undefined'){
                        actfinder.selectacttypeopt($(this).parent().next().children('.selected'));   
                    }
                break;
                case 38:
                    actfinder.acttypenavup(this);
                break;
                case 40:
                    actfinder.acttypenavdown(this);
                break;
                default:
                    actfinder.acttypefilteropt(this);
            }
            
        });
        
        $('#confirmsearch').on('click',function(event){
            event.stopPropagation();
            
            actfinder.searchact();
        });
    },
    provideautoco:function(elem){
        if(typeof $(elem).parent().next().attr('id') === 'undefined' || $(elem).parent().next().attr('id') != 'acttypeopt'){
            var acttypeadderstr = $(elem).attr('class').indexOf('1440') !== -1 ? '<ul id="acttypeopt">'+atypebox.acttypeadderpro(true)+'</ul>' : ($(elem).attr('class').indexOf('allandade') !== -1 ? '<ul id="acttypeopt">'+atypebox.acttypeadderpro(0)+'</ul>' : '<ul id="acttypeopt">'+atypebox.acttypeadderpro(false)+'</ul>');
            
            $(elem).parent().after(acttypeadderstr);
            $('#acttypeopt').css('top',($(elem).parent().height()+$(elem).parent()[0].offsetTop+1)+'px');
            if(actfinder.acttypeoptinit === false){
                actfinder.acttypeoptinit = true;
                $('#messagebox').delegate('#acttypeopt li','click',function(event){
                    event.stopPropagation();
                    
                    actfinder.selectacttypeopt($(this));
                });
            }
        }
    },
    selectacttypeopt:function(elem){
        var addedid = $(elem).attr('id').split('_');
        addedid.splice(0,1);
        addedid = addedid.join('_');
        
        if($('#acttypeadder').attr('class').indexOf('exclusive') !==-1){
            $('#acttypeexclusive').val(addedid);
            $('#acttypeadder').val($(elem).html()).addClass('filled');
            $('#acttypeopt').remove();
            return;
        }
        if(typeof $('#searchcats').find('.'+addedid).attr('class') === 'undefined')
            $('#searchcats').append('<span class="scats '+addedid+'">'+$(elem).html()+'<span class="deleteacttypeoptadded">X</span></span>');
            
        $('#acttypeopt').remove();
    },
    acttypefilteropt:function(elem){
        this.provideautoco(elem);
        var typed = $(elem).val();
        
        elem = $(elem).parent().next();
        $.each($(elem).children(),function(ei,ee){
            if($(ee).html().indexOf(typed)===-1){
                $(ee).addClass('hide');
            }
            else{
                $(ee).removeClass('hide');
            }
        });
    },
    acttypenavup:function(elem){
        this.provideautoco(elem);
        var selected = false;
        elem = $(elem).parent().next();
        var cy=0;
        if($(elem).children('.selected').length){
            selected = $(elem).children('.selected');
            $(selected).removeClass('selected');
        }
        else{
            selected = $(elem).children().eq($(elem).children().length-1);
            if($(selected).attr('class').indexOf('hide')===-1){
                cy++;
            }
        }
        while((cy==0 && typeof $(selected).prev().attr('class') !=='undefined') || (typeof $(selected).prev().attr('class') !=='undefined' && $(selected).attr('class').indexOf('hide')!==-1) ){
            cy++;
            selected = $(selected).prev();
        }
        if($(selected).attr('class').indexOf('hide') !== -1){
            $.each($(elem).children(),function(ei,ee){
                if($(ee).attr('class').indexOf('hide') ===-1){
                    selected = ee;
                    return false;
                }
            });
        }
        $(selected).addClass('selected');
        $(selected)[0].scrollIntoView();
    },
    acttypenavdown:function(elem){
        this.provideautoco(elem);
        var selected = false;
        elem = $(elem).parent().next();
        var cy=0;
        if($(elem).children('.selected').length){
            selected = $(elem).children('.selected');
            $(selected).removeClass('selected');
        }
        else{
            selected = $(elem).children().eq(0);
            if($(selected).attr('class').indexOf('hide')===-1){
                cy++;
            }
        }
        
        while( (cy==0 && typeof $(selected).next().attr('class') !=='undefined') || (typeof $(selected).next().attr('class') !=='undefined' &&  $(selected).attr('class').indexOf('hide')!==-1)){
            cy++;
            selected = $(selected).next();
        }
        if($(selected).attr('class').indexOf('hide') !== -1){
            $.each($(elem).children(),function(ei,ee){
                if($(ee).attr('class').indexOf('hide') ===-1){
                    selected = ee;
                }
            });
        }
        $(selected).addClass('selected');
        $(selected)[0].scrollIntoView();
    },
    searchact:function(){
        $('#messagebox').addClass('loading');
        var searchcrit = [];
        searchcrit.searchkey = $('#messagebox').find('.keyword').val();
        searchcrit.sdate = $('#messagebox').find('.sdate').val();
        searchcrit.edate = $('#messagebox').find('.edate').val();
        searchcrit.scats = [];
        $.each($('#messagebox').find('.scats'),function(i,e){
            searchcrit.scats[searchcrit.scats.length] = $(e).attr('class').split(' ')[1];
        });
    
        this.searchobj.setcrit(searchcrit);
        this.searchobj.submitsearch();
    }
};

var todolist = {
    thelist:false,
    newitem:false,
    editing:false,
    fetchlist:function(){
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'todolist',a:'fetchlist'}
        }).done(function(msg){
            msg = JSON.parse(msg);
            todolist.thelist = msg;
            todolist.menubox();
        });
    },
    untodo:function(){
        for(var i=0;i<this.thelist.length;i++){
            if(this.thelist[i].id == this.editing.id){
                this.thelist.splice(i,1);
                break;
            }
        }
        this.editing = false;
    },
    menubox:function(){
        if(this.thelist === false){
            this.fetchlist();
            return;
        }
        var title = 'To Do List';
        var content='';
        if(!this.thelist.length)
            content += '<div class="row">Nothing in Your List</div>';
        else{
            content+='<div class="row head"><span class="tdlnum">&nbsp;</span><span class="tdltitle">Name</span><span class="tdltype">Type</span><span class="tdltime">Time</span><span class="tdlprio">Priority</span></div>';
            var restype;
            for(var i=0;i<this.thelist.length;i++){
                restype = atypebox.atname(this.thelist[i].type);
                content+='<div class="row todolistitem" id="tdli_'+this.thelist[i].id+'"><span class="tdlnum">'+(i+1)+'</span><span class="tdltitle">'+this.thelist[i].name+'</span><span class="tdltype">'+restype+'</span><span class="tdltime">'+this.thelist[i].duration+'</span><span class="tdlprio">'+this.thelist[i].priority+'</span></div>';
            }
        }
        var action = '<span id="addtodolist">Create New</span><span id="pdftodolist">PDF</span>';
        mbox(title,content,action,'extrawide');
        
        if(todolist.editing !== false){
            $('#tdli_'+todolist.editing.id)[0].scrollIntoView();
            $('#tdli_'+todolist.editing.id).addClass('beenthere');
        }
        
        $('.row.todolistitem').on('click',function(event){
            event.stopPropagation();
            
            todolist.detailbox($(this).attr('id').split('_')[1]);
        });
        
        $('#addtodolist').on('click',function(event){
            event.stopPropagation();
            
            todolist.createnewbox();
        });
        $('#pdftodolist').on('click',function(event){
            event.stopPropagation();
            
            todolist.pdflist();
        });
    },
    cancelpdf:false,
    pdflist:function(){
        todolist.cancelpdf = false;
        var title   = 'Exporting to PDF';
        var content = '<div class="row">Please wait while the file is being generated...</div>';
        var action  = '<span id="cancelpdf">Cancel</span>';
        
        mbox(title,content,action,'extrawide');
        $('#closemessagebox').addClass('hide');
        
        $('#cancelpdf').on('click',function(){
            todolist.cancelpdf = true;
        });
        
        
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'pdfcal',a:'pdflist',d:{localcat:atypebox.postcat()}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            if(todolist.cancelpdf){
                return;
            }
            dialogbox.close();
            window.open('./?app='+appname+'&p=pdfcal&a=downloadpdf&d[pdfid]='+msg.pdfid);
        });
    },
    createnewbox:function(){
        todolist.newitem = new activity({id:false,name:"name",description:"description",type:"type",date:false,time:false,duration:30,priority:5,todolistitem:true}); 
            
        var title = 'To Do';
        var content = '<div class="row"><input type="text" name="name" value="name" class="name"></div>';
        content += '<div class="row"><input type="hidden" value="" id="acttypeexclusive" class="acttypeexclusive"><input type="text" name="type" value="type" class="acttype exclusive allandade" id="acttypeadder"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="duration in minutes" class="disabled first borderless duinwhat"><input type="number" value="30" name="duration" class="duration"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="priority" class="disabled first borderless ten"><input type="number" name="priorityinput" value="10" class="priority" min=1 max=10></div>';
        content+='<div class="row"><textarea id="activdeta" name="description" class="description">description</textarea></div>';
        var action = '<span id="confirmtdlitem">Confirm</span><span id="backtorel" class="left">&larr; Back</span>';
        mbox(title,content,action,'xxl');
        todolist.newitem.newactivform();
        pageaction.texteditor();
        
        atypebox.acttypeadderaction();
        
        $('.priority').on('change',function(event){
            event.stopPropagation();
            
            $(this).prev().css('opacity',($(this).val()/10));
        });
        $('#backtorel').on('click',function(event){
            event.stopPropagation();
            
            todolist.menubox();
        });
        $('#messagebox').find('.name').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                todolist.newitem.submittodolist();
            }
        });
        $('#messagebox').find('.duration').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                todolist.newitem.submittodolist();
            }
        });
        $('#messagebox').find('.priority').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                todolist.newitem.submittodolist();
            }
        });
        $('#confirmtdlitem').on('click',function(event){
            event.stopPropagation();
            
            todolist.newitem.submittodolist();
        });
    },
    postcreatemode:0,
    postcreate:function(msg){
        if(msg.result==false){
            dialogbox.dispmsg('server error',true);
        }
        else{
            if(this.postcreatemode==0){
                todolist.newitem.id = msg.result;
                this.thelist[this.thelist.length] = todolist.newitem.postdata();
                this.detailbox(todolist.newitem.id);
                dialogbox.dispmsg('added successfully',true);      
            }
            else{
                for(var i=0;i<this.thelist.length;i++){
                    if(this.thelist[i].id == todolist.editing.id){
                        this.thelist[i] = todolist.editing.postdata();
                        break;
                    }
                }
                dialogbox.dispmsg('saved',true);
            }
                this.thelist.sort(function(a,v){
                    return v.priority - a.priority;
                });
        }
    },
    settimebox:function(){
        var title = 'Set Time - '+todolist.editing.name;
        var content = '<div class="row multiinput double"><input type="text" name="date" value="date" class="date first"><input type="text" name="time" value="time" class="time"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="alarm" class="disabled first borderless ten"><input type="number" name="alarminput" value="0" class="alarm" min=0></div>';
        var action = '<span id="confirmtdlitem">Save</span><span id="backtorel" class="left">&larr; Back</span>';
        mbox(title,content,action,'extrawide');
        
        
        $('#confirmtdlitem').on('click',function(event){
            event.stopPropagation();
            
            todolist.editing.confirmtiming();
        });
        $('#backtorel').on('click',function(event){
            event.stopPropagation();
            
            todolist.detailbox(false);
        });
    },
    deletetdlitem:function(){
        var title = 'Confirm Delete';
        var content = '<div class="row">Delete To Do Item - '+todolist.editing.name+'?</div>';
        var action = '<span id="deletetdlitem" class="dangerous">Delete</span><span id="backtorel" class="left">&larr; Cancel</span>';
        
        mbox(title,content,action,'narrow');
        
        $('#deletetdlitem').on('click',function(event){
            event.stopPropagation();
            
            todolist.conf_deletetdlitem();
        });   
        $('#backtorel').on('click',function(event){
            event.stopPropagation();
            
            todolist.detailbox(false);
        });  
    },
    conf_deletetdlitem:function(){
        todolist.editing.todolistitem = true;
        todolist.editing.delete();
    },
    postdelete:function(msg){
        if(msg.result!=false){
            var boxmsg = 'Successfully deleted '+this.editing.name;
            this.untodo();
            this.menubox();
            dialogbox.dispmsg(boxmsg,true);   
        }
        else{
            dialogbox.dispmsg('server error',true);   
        }
    },
    detailbox:function(id){
        if(!(id===false && this.editing !== false)){
            for(var i=0;i<this.thelist.length;i++){
                if(this.thelist[i].id == id){
                    todolist.editing = new activity(this.thelist[i]);
                    break;
                }
            }   
        }
        var title = 'To Do';
        var content = '<div class="row"><input type="text" name="name" value="name" class="name"></div>';
        content += '<div class="row"><input type="hidden" value="'+todolist.editing.type+'" id="acttypeexclusive" class="acttypeexclusive"><input type="text" name="type" value="type" class="acttype exclusive allandade" id="acttypeadder"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="duration in minutes" class="disabled first borderless duinwhat"><input type="number" value="30" name="duration" class="duration"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="priority" class="disabled first borderless ten"><input type="number" name="priorityinput" value="10" class="priority" min=1 max=10></div>';
        content+='<div class="row"><textarea id="activdeta" name="description" class="description">description</textarea></div>';
        var action = '<span id="confirmtdlitem" class="fullobtn">Save</span><span id="deletetdlitem" class="dangerous fullobtn">Delete</span><span id="settdlitem" class="extras fullobtn">Set Time</span><span id="starttdlitem" class="extras fullobtn">Start</span><span id="backtorel" class="left fullobtn">&larr; Back</span>';
        
        mbox(title,content,action,'xxl');
        todolist.editing.edittodoform();
        pageaction.texteditor();
        
        $('#deletetdlitem').on('click',function(event){
            event.stopPropagation();
            
            todolist.deletetdlitem();
        });        
        $('#settdlitem').on('click',function(event){
            event.stopPropagation();
            
            todolist.editing.todolistitem = true;
            if(todolist.editing.checkwasedited() !== false){
                todolist.editing.waseditedfn_(function(){
                    todolist.settimebox();
                });
            }
            else{
                todolist.settimebox();
            }
        });        
        $('#starttdlitem').on('click',function(event){
            event.stopPropagation();
            
            todolist.editing.start_tdl_item();
        });
        $('.priority').on('change',function(event){
            event.stopPropagation();
            
            $(this).prev().css('opacity',($(this).val()/10));
        });
        $('#backtorel').on('click',function(event){
            event.stopPropagation();
            
            todolist.editing.todolistitem = true;
            var a = todolist.editing.checkwasedited();
            console.log(a);
            if(a !== false){
                todolist.editing.waseditedfn_(function(){
                    todolist.menubox();
                });
            }
            else{
                todolist.menubox();
            }
        });
        $('#acttypeadder').on('focus',function(){
            actfinder.acttypefilteropt(this);
        });
        $('#acttypeadder').on('blur',function(){
            setTimeout(function(){
                $('#acttypeopt').remove();
            },300);
        });
        $('#acttypeadder').on('keyup',function(){
            switch(event.which){
                case 13:
                    if(typeof $(this).parent().next().children('.selected').attr('class') !== 'undefined'){
                        actfinder.selectacttypeopt($(this).parent().next().children('.selected'));   
                    }
                break;
                case 38:
                    actfinder.acttypenavup(this);
                break;
                case 40:
                    actfinder.acttypenavdown(this);
                break;
                default:
                    actfinder.acttypefilteropt(this);
            }
        });
        $('#messagebox').find('.name').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                todolist.editing.submittodolist();
            }
        });
        $('#messagebox').find('.duration').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                todolist.editing.submittodolist();
            }
        });
        $('#messagebox').find('.priority').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                todolist.editing.submittodolist();
            }
        });
        $('#confirmtdlitem').on('click',function(event){
            event.stopPropagation();
            
            todolist.editing.submittodolist();
        });
    }
};

var rarecost = {
    format:function(amount){
        amount = amount.toString();
        var amountmoney = '';
        for(var i=amount.length-1;i>=0;i--){
            amountmoney = amount[i]+amountmoney;
            if(((amount.length-i) % 3) == 0 && i != 0){
                amountmoney = ','+amountmoney;
            }
        }
        return amountmoney;
    },
    overall:0,
    estimate:function(){
        rarecost.overall = 0;
        if(pagevar.gotomode){
            for(var p=0;p<pagevar.gotocalendar[pagevar.gotocalendaridx].activities[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage].length;p++){
                rarecost.overall += parseInt(pagevar.gotocalendar[pagevar.gotocalendaridx].activities[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage][p].cost);
            }
            
            rarecost.displayestimation();
            return;
        }
        
        for(var i=0;i<pagevar.activities[pagevar.calendaridx].length;i++){
            rarecost.overall += parseInt(pagevar.activities[pagevar.calendaridx][i].cost);
        }
        rarecost.displayestimation();
    },
    displayestimation_:function(spendlybudget){
        var title = 'Budget Forecast';
        var content = '<div class="row normalisfifteen" style="border-bottom: 1px dotted #283848;"><span class="label">Total</span><span class="tcostval">'+rarecost.format(rarecost.overall)+'</span></div>';
        content += '<div class="row normaliseleven" style="border-bottom: 1px dotted #283848;"><span class="label">Spendly says you have</span><span class="tcostval">'+rarecost.format(spendlybudget)+'</span></div>';
        content += '<div class="row normaliseleven" style="border-bottom: 1px dotted #283848;"><span class="label">Remaining budget would be</span><span class="tcostval">'+rarecost.format((spendlybudget-rarecost.overall))+'</span></div>';
        var action = '<span id="costdetails">Details</span>';
        mbox(title,content,action,'narrow');
        
        $('#costdetails').on('click',function(event){
            event.stopPropagation();
            
            rarecost.costdetails();
        });
    },
    displayestimation:function(){
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'spendly',a:'budgetinfo'}
        }).done(function(msg){
            msg = JSON.parse(msg);
            rarecost.displayestimation_(msg.result);
        });
    },
    costdetailvars:[],
    costdetails:function(){
        rarecost.costdetailvars=[];
        var icost = 0;
        var coactnum=0;
        if(pagevar.gotomode){
            for(var p=0;p<pagevar.gotocalendar[pagevar.gotocalendaridx].activities[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage].length;p++){
                icost = parseInt(pagevar.gotocalendar[pagevar.gotocalendaridx].activities[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage][p].cost);
                if(icost >0){
                    coactnum++;
                    rarecost.costdetailvars[rarecost.costdetailvars.length] = pagevar.gotocalendar[pagevar.gotocalendaridx].activities[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage][p];
                }
            }
            rarecost.sortdet(false);
            return;
        }
        
        for(var i=0;i<pagevar.activities[pagevar.calendaridx].length;i++){
            icost = parseInt(pagevar.activities[pagevar.calendaridx][i].cost);
                if(icost >0){
                    coactnum++;
                    rarecost.costdetailvars[rarecost.costdetailvars.length] = pagevar.activities[pagevar.calendaridx][i];
                }
        }
        rarecost.sortdet(false);
    },
    backfunc:function(){
        var cdetails='';
        for(var i=0;i<rarecost.costdetailvars.length;i++){
            cdetails+='<div class="row coact" id="dcoact_'+rarecost.costdetailvars[i].id+'"><span class="coact_num">'+(i+1)+'</span><span class="coact_name">'+rarecost.costdetailvars[i].name+'</span><span class="coact_time">'+rarecost.costdetailvars[i].date+' '+rarecost.costdetailvars[i].time+'</span><span class="coact_type">'+atypebox.atname(rarecost.costdetailvars[i].type)+'</span><span class="coact_priority">'+rarecost.costdetailvars[i].priority+'</span><span class="coact_cost">'+rarecost.format(rarecost.costdetailvars[i].cost)+'</span><span class="coact_desc">'+rarecost.costdetailvars[i].description+'</span></div>';
        }
        
        rarecost.displaydetails(cdetails);
    },
    displaydetails:function(cdetails){
        this.cached = cdetails;
        
        cdetails = '<div class="row head"><span class="coact_num">&nbsp;</span><span class="coact_name sortfact">name</span><span class="coact_time sortfact">time</span><span class="coact_type sortfact">type</span><span class="coact_priority sortfact">prio</span><span class="coact_cost sortfact">cost</span><span class="coact_desc">description</span></div>'+cdetails;
        
        var title = 'Cost Details';
        var action = '<span id="backtodet" class="left">&larr; Back</div>';
        mbox(title,cdetails,action,'xxl');
        
        $('#backtodet').on('click',function(event){
            event.stopPropagation();
            
            rarecost.estimate();
        });
        
        $('.sortfact').on('click',function(event){
            event.stopPropagation();
            
            rarecost.sortdet($(this).html());
        });
        
        $('.coact').on('click',function(event){
            event.stopPropagation();
            
            rarecost.actdet(this);
        });
    },
    thesort:[],
    alfasortval:['0','1','2','3','4','5','6','7','8','9','_','/','.','-','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'],
    sortdet:function(sortfact){
        if(sortfact === false){
            if(!this.thesort.length){
                this.thesort[0] = 'time';
                this.thesort[1] = false;
            }
        }
        else{
            if(this.thesort.length){
                if(this.thesort[0] == sortfact){
                    this.thesort[1] = !this.thesort[1];
                }
                else{
                    this.thesort[0] = sortfact;
                    this.thesort[1] = true;
                }
            }
            else{
                this.thesort[0] = sortfact;
                this.thesort[1] = true;
            }
        }
        var maxle;
        var sortres;
        switch(this.thesort[0]){
            case 'name':
                if(rarecost.thesort[1])
                    rarecost.costdetailvars.sort(function(a,v){
                        maxle = Math.min(v.name.length,a.name.length);
                        
                        for(var i=0;i<maxle;i++){
                            sortres = rarecost.alfasortval.indexOf(a.name.substr(i,1)) - rarecost.alfasortval.indexOf(v.name.substr(i,1));
                            
                            if(sortres !== 0 || v.name.length === i+1 || a.name.length == i+1)
                                break;
                        }
                        return sortres;
                    });
                else
                    rarecost.costdetailvars.sort(function(a,v){
                        maxle = Math.min(v.name.length,a.name.length);
                        
                        for(var i=0;i<maxle;i++){
                            sortres = rarecost.alfasortval.indexOf(v.name.substr(i,1)) - rarecost.alfasortval.indexOf(a.name.substr(i,1));
                            
                            if(sortres !== 0 || v.name.length === i+1 || a.name.length == i+1)
                                break;
                        }
                        return sortres;
                    });
            break;
            case 'type':
                if(rarecost.thesort[1])
                    rarecost.costdetailvars.sort(function(a,v){
                        maxle = Math.min(v.type.length,a.type.length);
                        
                        for(var i=0;i<maxle;i++){
                            sortres = rarecost.alfasortval.indexOf(v.type.substr(i,1)) - rarecost.alfasortval.indexOf(a.type.substr(i,1));
                            
                            if(sortres !== 0 || v.type.length === i+1 || a.type.length == i+1)
                                break;
                        }
                        return sortres;
                    });
                else
                    rarecost.costdetailvars.sort(function(a,v){
                        maxle = Math.min(v.type.length,a.type.length);
                        
                        for(var i=0;i<maxle;i++){
                            sortres = arecost.alfasortval.indexOf(a.type.substr(i,1)) - rarecost.alfasortval.indexOf(v.type.substr(i,1));
                            
                            if(sortres !== 0 || v.type.length === i+1 || a.type.length == i+1)
                                break;
                        }
                        return sortres;
                    });
            break;
            case 'time':
                if(rarecost.thesort[1])
                    rarecost.costdetailvars.sort(function(a,v){
                        var ddate = a.date.split('-');
                        var dtime = a.time.split(':');
                        ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
                        
                        var ddate_ = v.date.split('-');
                        var dtime_ = v.time.split(':');
                        ddate_ = new Date(parseInt(ddate_[0]),(parseInt(ddate_[1])-1),parseInt(ddate_[2]),dtime_[0],dtime_[1],dtime_[2]);
                        
                        return ddate_ - ddate;
                    });
                else
                    rarecost.costdetailvars.sort(function(a,v){
                        var ddate = a.date.split('-');
                        var dtime = a.time.split(':');
                        ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
                        
                        var ddate_ = v.date.split('-');
                        var dtime_ = v.time.split(':');
                        ddate_ = new Date(parseInt(ddate_[0]),(parseInt(ddate_[1])-1),parseInt(ddate_[2]),dtime_[0],dtime_[1],dtime_[2]);
                        
                        return ddate - ddate_;
                    });
            break;
            case 'prio':
                if(rarecost.thesort[1])
                    rarecost.costdetailvars.sort(function(a,v){
                        return v.priority - a.priority;
                    });
                else
                    rarecost.costdetailvars.sort(function(a,v){
                        return a.priority - v.priority;
                    });
            break;
            case 'cost':
                if(rarecost.thesort[1])
                    rarecost.costdetailvars.sort(function(a,v){
                        return v.cost - a.cost;
                    });
                else
                    rarecost.costdetailvars.sort(function(a,v){
                        return a.cost - v.cost;
                    });
            break;
        }
        rarecost.backfunc();
    },
    actdet:function(elem){
        var id = parseInt($(elem).attr('id').split('_')[1]);
        pagevar.getactivity(id);
        pagevar.activityinedit.searchresult = 'costoverview';
        if(pagevar.activityinedit.type=='startrareity'){
            pageaction.newactivity($(elem).parent(),pagevar.activityinedit);
            return;
        }
        pageaction.detailsofact_();
    }
};

function rareity_menu(menuname){
    switch(menuname){
        case 'reloadty':
            if(isanelectronapp)
            ipcRenderer.send('asynchronous-message', 'resetbro<edsep>');
        break;
        case 'coverview':
            rarecost.estimate();
        break;
        case 'todo':
            todolist.menubox();
        break;
        case 'suggestact':
            activsuggestion.dbox();
        break;
        case 'searchactivity':
            actfinder.searchbox();
        break;
        case 'quitbro':
            if(isanelectronapp)
                ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
        break;
        case 'fweek':
            pageaction.loadingpage(false);
            pagevar.cscrolled=$('#scrollcontainer')[0].scrollLeft;
            
            if(pagevar.gotomode){
                pagevar.gotoforward();
                return;
            }
            
            if(pageaction.forwardaweek()){
                pageaction.pageloaded();
                return;
            }
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'activityc',a:'forwardaweek',d:{startdate:pagevar.currentstartdate(),viewmode:pagevar.defaultviewmode}}
            }).done(function(msg){
                msg=JSON.parse(msg);
                $('#scrollcontainer').html(msg.pagecontent);
                
                pagevar.calendaridx = pagevar.activities.length;
                pagevar.fillactivities(msg.activities);
                
                pageaction.loadingpage(true);
                setTimeout(function(){
                    pagevar.drawcalendar();
                },10);
                
                pageaction.pageprep();
            });
        break;
        case 'bweek':
            pageaction.loadingpage(false);
            pagevar.cscrolled=$('#scrollcontainer')[0].scrollLeft;
            
            if(pagevar.gotomode){
                pagevar.gotobackward();
                return;
            }
            
            if(pageaction.backupaweek()){
                pageaction.pageloaded();
                return;
            }
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'activityc',a:'backupaweek',d:{startdate:pagevar.currentstartdate(),viewmode:pagevar.defaultviewmode}}
            }).done(function(msg){
                msg=JSON.parse(msg);
                $('#scrollcontainer').html(msg.pagecontent);
                
                pagevar.calendaridx = 0;
                pagevar.startdates.unshift('');
                pagevar.enddates.unshift('');
                pagevar.calendar.unshift('');
                pagevar.activities.unshift('');
                
                pagevar.fillactivities(msg.activities);
                
                pageaction.loadingpage(true);
                setTimeout(function(){
                    pagevar.drawcalendar();
                },10);
                
                pageaction.pageprep();
            });
        break;
        case 'goto':
            var title   = 'Go To Date';
            var content = '<div class="row"><input type="text" name="date" value="date" class="date"></div>';
            content+='<div class="row"><select name="view range" class="viewrange" id="gotoviewrange">'+pagevar.gotoviewrange()+'</select></div>';
            
            var action  = '<span id="confirmgoto">Confirm</span>';
            mbox(title,content,action,'extrawide');
            
            if(pagevar.gotomode){
                $('#messagebox').find('.date').val(pagevar.gotocalendar[pagevar.gotocalendaridx].time[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage]);
                
                if(pagevar.gotocalendar[pagevar.gotocalendaridx].range[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage].indexOf('_') !== -1){
                    $('#gotoviewrange').val(33);
                    $('#gotoviewrange').parent().after('<div class="row multiinput right double bottomed" style="width:40%;float:right"><span class="right">days</span><input style="width:30px;text-align:center;" type="number" name="ndays" value='+parseInt(pagevar.gotocalendar[pagevar.gotocalendaridx].range[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage].split('_')[0])+' class="ndayscount right first"></div>');
                }
                else
                    $('#gotoviewrange').val(pagevar.gotocalendar[pagevar.gotocalendaridx].range[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage]);
            }
            else{
                $('#messagebox').find('.date').val(pagevar.currentstartdate());
                $('#gotoviewrange').val(2);
            }
            
            $('#messagebox').find('.date').on('keydown',function(event){
                event.stopPropagation();
                
                if(event.which==13){
                    pageaction.loadingpage(false);
                    if(typeof $('#messagebox').find('.ndayscount').attr('class') !=='undefined'){
                        pageaction.gotodatendays($('#messagebox').find('.date').val(),$('#messagebox').find('.ndayscount').val());
                        return;
                    }
                    pageaction.gotodate($('#messagebox').find('.date').val(),$('#messagebox').find('.viewrange').val());
                }
            });
            $('#gotoviewrange').on('change',function(event){
                event.stopPropagation();
                
                registaforminputaction(this);
                
                if($(this).val() == 33){
                    $(this).parent().after('<div class="row multiinput right double bottomed" style="width:40%;float:right"><span class="right">days</span><input style="width:30px;text-align:center;" type="number" name="ndays" value=0 class="ndayscount right first"></div>');
                }
                else{
                    if($(this).parent().next()[0] && $(this).parent().next()[0].nodeName == 'DIV'){
                        $(this).parent().next().remove();
                    }
                }
            });
            
            $('#confirmgoto').on('click',function(event){
                event.stopPropagation();
                pageaction.loadingpage(false);
                if(typeof $('#messagebox').find('.ndayscount').attr('class') !=='undefined'){
                    pageaction.gotodatendays($('#messagebox').find('.date').val(),$('#messagebox').find('.ndayscount').val());
                    return;
                }
                pageaction.gotodate($('#messagebox').find('.date').val(),$('#messagebox').find('.viewrange').val());
            });
        break;
        case 'gotonow':
            if(!pagevar.calendar.length){
                pagevar.reloadpage(false);
                return;
            }
            pagevar.gotonow = true;
            pageaction.loadingpage(false);
            pagevar.gotomode=false;
            $('#currenttime').removeClass('gotomode');
            pagevar.calendaridx = $.inArray(pagevar.getNow(),pagevar.startdates);
            pageaction.displaypage();
            pageaction.pageloaded();
        break;
        case 'viewopts':
            viewopts.menubox();
        break;
        case 'atypes':
            atypebox.menubox();
        break;
        case 'atempl':
            presetbox.menubox();
        break;
        case 'timecalc':
            timecalc.menubox();
        break;
        case 'exportactivity':
            rarepdf.pdfcal();
        break;
        case 'saveview':
            pagesaving.savepagebox();
        break;
        case 'savedview':
            if($('#savedview').attr('class').indexOf('disabled') !== -1){
                return;
            }
            pagesaving.listbox();
        break;
        default:
    }
}
var pagesaving = {
    thelist:[],
    listbox:function(){
        if(!userpref.pref['rareity_pages'].length){
            return;
        }

        $.ajax({
            url:'',
            type:'POST',
            data:{app:appname,p:'searchactivity',a:'savedcal',d:{saved:JSON.stringify(userpref.pref['rareity_pages'])}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            pagesaving.thelist = msg.result;
            pagesaving.displaylist();
        });
    },
    displaylist:function(){
        var title   = 'Saved Calendar';
        var content = '<div class="row sacal head"><span class="cname">name</span><span class="startd">start</span><span class="scrange">range</span><span class="scactivitycount">activities</span><span class="scaldel">&nbsp;</span></div>';
        for(var i=0;i<userpref.pref['rareity_pages'].length;i++){
            content += '<div class="row sacal" id="sacal_'+i+'"><span class="cname">'+userpref.pref['rareity_pages'][i].calname+'</span><span class="startd">'+userpref.pref['rareity_pages'][i].startdate+'</span><span class="scrange">'+userpref.pref['rareity_pages'][i].viewmode+'</span><span class="scactivitycount">'+pagesaving.thelist[i]+'</span><span class="scaldel"></span></div>';
        }
        var action  = '';
        
        mbox(title,content,action,'extrawide');
        $('#messagebox').removeClass('loading');
        
        if(pagesaving.pendingmsg !== false){
            dialogbox.dispmsg(pagesaving.pendingmsg,true);
            pagesaving.pendingmsg = false;
        }
        
        $('#messageboxcontent .row.sacal').on('click',function(event){
            event.stopPropagation();
            
                pageaction.loadingpage(false);
                if($(this).children('.scrange').html().indexOf('_') !== -1){
                    pageaction.gotodatendays($(this).children('.startd').html(),parseInt($(this).children('.scrange').html().split('_')[0]));
                    return;
                }
                if($(this).children('.scrange').html() == 'weekly'){
                    pageaction.gotodate($(this).children('.startd').html(),2);
                }
                else{
                    pageaction.gotodate($(this).children('.startd').html(),1);
                }
        });
        
        $('#messageboxcontent .scaldel').on('click',function(event){
            event.stopPropagation();
            
            var sacalid = parseInt($(this).parent().attr('id').split('_')[1]);
            userpref.pref['rareity_pages'].splice(sacalid,1);
            userpref.savepages();
            
            $(this).parent().remove();
            if($('#messageboxcontent').find('.row.sacal').length==1){
                $('#messageboxcontent').find('.tablecell').html('');
                $('#savedview').addClass('disabled');
            }
        });
    },
    savepagebox:function(){
        var title   = 'Save Calendar';
        var content = '<div class="row"><input type="text" name="calendar name" value="calendar name" class="calnameis" id="calnameis"></div>';
        var action  = '<span id="savecal">Save</span>';
        
        mbox(title,content,action,'extrawide');
        
        $('#savecal').on('click',function(event){
            event.stopPropagation();
            
            var startdate,viewmode,calname;
            calname = $('#calnameis').val();
            
            if(calname=='' || calname == 'Calendar Name'){
                dialogbox.dispmsg('please set a name',true);
                return;
            }
            $('#messagebox').addClass('loading');
            if(pagevar.gotomode){
                startdate = pagevar.gotocalendar[pagevar.gotocalendaridx].time[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage];
                if(pagevar.gotocalendar[pagevar.gotocalendaridx].range[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage].indexOf('_') !== -1){
                    viewmode = pagevar.gotocalendar[pagevar.gotocalendaridx].range[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage];
                }
                else{
                    if(pagevar.gotocalendar[pagevar.gotocalendaridx].range[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage] == 1){
                        viewmode = 'monthly';
                    }
                    else{
                        viewmode = 'weekly';
                    }
                }
            }
            else{
                viewmode = 'weekly';
                startdate = pagevar.currentstartdate();
            }
            
            var uprpidx = userpref.pref['rareity_pages'].length;
            userpref.pref['rareity_pages'][uprpidx] = {viewmode:viewmode,startdate:startdate,calname:calname};
            userpref.savepages();
            
            pagesaving.pendingmsg = 'saved!';
            $('#savedview').removeClass('disabled');
            pagesaving.listbox();
        });
    },
    pendingmsg:false
};
var rarepdf = {
    canceldownload:false,
    cancel:function(){
        this.canceldownload=true;
        dialogbox.close();
    },
    pdfcal:function(){
        this.canceldownload=false;
        var title   = 'Exporting to PDF';
        var content = '<div class="row">Please wait while the file is being generated...</div>';
        var action  = '<span id="cancelpdf">Cancel</span>';
        
        mbox(title,content,action,'extrawide');
        $('#closemessagebox').addClass('hide');
        
        $('#cancelpdf').on('click',function(){
            rarepdf.cancel();
        });
        
        if(!pagevar.gotomode)
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'pdfcal',a:'pdfcalendar',d:{startdate:pagevar.currentstartdate(),viewmode:pagevar.defaultviewmode,localcat:atypebox.postcat()}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            if(rarepdf.canceldownload){
                return;
            }
            dialogbox.close();
            window.open('./?app='+appname+'&p=pdfcal&a=downloadpdf&d[pdfid]='+msg.pdfid);
        });
        else{
            var startdate = pagevar.gotocalendar[pagevar.gotocalendaridx].time[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage];
            var viewmode;
            if(pagevar.gotocalendar[pagevar.gotocalendaridx].range[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage].indexOf('_') !== -1){
                viewmode = pagevar.gotocalendar[pagevar.gotocalendaridx].range[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage];
            }
            else{
                if(pagevar.gotocalendar[pagevar.gotocalendaridx].range[pagevar.gotocalendar[pagevar.gotocalendaridx].cpage] == 1){
                    viewmode = 'monthly';
                }
                else{
                    viewmode = 'weekly';
                }
            }
                    
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'pdfcal',a:'pdfcalendar',d:{startdate:startdate,viewmode:viewmode,localcat:atypebox.postcat()}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                
                if(rarepdf.canceldownload){
                    return;
                }
                dialogbox.close();
                window.open('./?app='+appname+'&p=pdfcal&a=downloadpdf&d[pdfid]='+msg.pdfid);
            });
        }
    },
    pdfsearched:function(){
        this.canceldownload=false;
        var title   = 'Exporting Search Result to PDF';
        var content = '<div class="row">Please wait while the file is being generated...</div>';
        var action  = '<span id="cancelpdf">Cancel</span>';
        
        mbox(title,content,action,'extrawide');
        $('#closemessagebox').addClass('hide');
        
        $('#cancelpdf').on('click',function(){
            rarepdf.cancel();
        });
        
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'pdfcal',a:'pdfsearch',d:{searchdata:actfinder.searchobj.getdata(),localcat:atypebox.postcat()}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(rarepdf.canceldownload){
                return;
            }
            dialogbox.close();
            window.open('./?app='+appname+'&p=pdfcal&a=downloadpdf&d[pdfid]='+msg.pdfid);
        });
    }
};
var timecalc = {
    enddate:false,
    startdate:false,
    daysdistance:false,
    menubox:function(){
        var title   = 'Time Calculator';
        var content = '<div class="row multiinput double"><input type="text" name="start time" value="start time" class="startdate first"><input type="text" name="end time" value="end time" class="enddate"></div>';
        var action  = '<span id="calcviewopt" class="left plain"><span class="left"><input type="radio" name="calcviewopt" class="calcviewopt" value="timedif" checked="checked"></span><span class="radiolabel left">Differences</span><span class="left" style="margin-left:14px;"><input type="radio" id="cvotimedif" class="calcviewopt" name="calcviewopt" value="timeaddsub"></span><span class="radiolabel left">Addition/Subtraction</span></span><span class="" id="calcit">Calculate</span>';
        
        mbox(title,content,action,'extrawide');
        
        this.formfilling();
        
        
        $('#messageboxaction').find('.radiolabel').on('click',function(event){
            event.stopPropagation();
            
            if($(this).prev().children().prop('checked')){
                return;
            }
            timecalc.theotherbox();
        });
        $('#messageboxaction').find('#cvotimedif').on('change',function(event){
            event.stopPropagation();
           
            timecalc.theotherbox();
        });
        
        $('#messagebox').find('.startdate').on('keydown',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                timecalc.calcit();
            }
        });
        $('#messagebox').find('.enddate').on('keydown',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                timecalc.calcit();
            }
        });
        
        $('#calcit').on('click',function(event){
            event.stopPropagation();
            
            timecalc.calcit();
        });
    },
    theotherbox:function(){
        var title   = 'Time Calculator';
        var content = '<div class="row multiinput double"><input type="text" name="start time" value="start time" class="startdate first"><input type="text" name="days distance" value="days distance" class="daysdistance"></div>';
        var action  = '<span id="calcviewopt" class="left plain"><span class="left"><input type="radio" id="cvotimedif" class="calcviewopt" name="calcviewopt" value="timedif"></span><span class="radiolabel left">Differences</span><span class="left" style="margin-left:14px;"><input type="radio" class="calcviewopt" name="calcviewopt" value="timeaddsub" checked="checked"></span><span class="radiolabel left">Addition/Subtraction</span></span><span class="" id="calcit">Calculate</span>';
        
        mbox(title,content,action,'extrawide');
        
        this.theotherformfilling();
        
        $('#messageboxaction').find('#cvotimedif').on('change',function(event){
            event.stopPropagation();
            
            timecalc.menubox();
        });
        
        $('#messageboxaction').find('.radiolabel').on('click',function(event){
            event.stopPropagation();
            
            if($(this).prev().children().prop('checked')){
                return;
            }
            timecalc.menubox();
        });
        
        $('#messagebox').find('.startdate').on('keydown',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                timecalc.theothercalcit();
            }
        });
        $('#messagebox').find('.daysdistance').on('keydown',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                timecalc.theothercalcit();
            }
        });
        
        $('#calcit').on('click',function(event){
            event.stopPropagation();
            
            timecalc.theothercalcit();
        });
    },
    theotherformfilling:function(){
        if(this.daysdistance==false){
            return;
        }
        
        if($.isArray(this.startdate)){
            this.startdate = this.startdate.join(' ');
        }
        
        $('#messagebox').find('.startdate').val(this.startdate).addClass('filled');
        $('#messagebox').find('.daysdistance').val(this.daysdistance).addClass('filled');
    },
    theothercalcit:function(){
        this.startdate = $('#messagebox').find('.startdate').val();
        this.daysdistance = $('#messagebox').find('.daysdistance').val();
        
        if(this.startdate =='start time' || this.daysdistance == 'days distance'){
            return;
        }
        if(this.startdate.indexOf(':') === -1){
            this.startdate+=' 00:00:00';
        }
        this.startdate = this.startdate.split(' ');
        
            var ddate,dtime;
            
            ddate = this.startdate[0].split('-');
            dtime = this.startdate[1].split(':');
            if(dtime.length == 2){ dtime[2] = '00'; }
            var sdate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
        
        sdate.setHours(sdate.getHours()+(this.daysdistance*24));
        
        var title = 'Date Added';
        var content = '<div class="row">'+sdate.getFullYear()+'-'+(sdate.getMonth()+1)+'-'+sdate.getDate()+'</div>';
        var action = '<span id="backtorel" class="left">&larr; Back</span>';
        
        mbox(title,content,action,'narrow');
        $('#backtorel').on('click',function(event){
            event.stopPropagation();
            
            timecalc.theotherbox();
        });
    },
    formfilling:function(){
        if(this.enddate==false){
            return;
        }
        if($.isArray(this.enddate)){
            this.startdate = this.startdate.join(' ');
            this.enddate = this.enddate.join(' ');   
        }
        
        $('#messagebox').find('.startdate').val(this.startdate).addClass('filled');
        $('#messagebox').find('.enddate').val(this.enddate).addClass('filled');
    },
    calcit:function(){
        this.startdate = $('#messagebox').find('.startdate').val();
        this.enddate = $('#messagebox').find('.enddate').val();
        
        if(this.startdate =='start time' || this.enddate == 'end time'){
            return;
        }
        if(this.startdate.indexOf(':') === -1){
            this.startdate+=' 00:00:00';
        }
        if(this.enddate.indexOf(':') === -1){
            this.enddate+=' 00:00:00';
        }
        this.startdate = this.startdate.split(' ');
        this.enddate = this.enddate.split(' ');
        
            var ddate,dtime,calced;
            
            ddate = this.startdate[0].split('-');
            dtime = this.startdate[1].split(':');
            if(dtime.length == 2){ dtime[2] = '00'; }
            var sdate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
            
            
            ddate = this.enddate[0].split('-');
            dtime = this.enddate[1].split(':');
            if(dtime.length == 2){ dtime[2] = '00'; }
            var edate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
            
        calced = ((edate - sdate)/1000);
        var cday = calced/86400;
        var chour = (((cday%1)*86400)/3600);
        cday = cday-(cday%1);
        var cmin = (((chour%1)*3600)/60);
        chour = chour-(chour%1);
        var csec = (cmin%1)*60;
        cmin = cmin-(cmin%1);
        csec = csec-(csec%1);
        
        
        var title = 'Time Differences';
        var content = '<div class="row"><span id="daycount">'+cday+'</span> days,<span id="hourcount">'+chour+'</span> hours,<span id="mincount">'+cmin+'</span> minutes,<span id="seccount">'+csec+'</span> seconds</div>';
        var action = '<span id="backtorel" class="left">&larr; Back</span>';
        
        mbox(title,content,action,'narrow');
        $('#backtorel').on('click',function(event){
            event.stopPropagation();
            
            timecalc.menubox();
        });
        
    }
};
var presetbox={
    editing:false,
    menubox:function(){
        var title   = 'Presets';
        var content = activtytemplate.presetseditopt();
        var action  = '<span id="addnewpreset">+ Add New</span>';
        
        mbox(title,content,action,'xxl');
        
        $('#addnewpreset').on('click',function(event){
            event.stopPropagation();
            
            presetbox.newbox();
        });
        $('.editpreset').on('click',function(event){
            event.stopPropagation();
            
            var idx=$(this).siblings('.presetname').attr('id').split('_')[1];
            idx=parseInt(idx);
            presetbox.editbox(idx);
        });
        $('.delpreset').on('click',function(event){
            event.stopPropagation();
            
            var idx=$(this).siblings('.presetname').attr('id').split('_')[1];
            var name = $(this).siblings('.presetname').html();
            idx=parseInt(idx);
            
            presetbox.editing = activtytemplate.template[idx];
            presetbox.editing.idx = idx;
            
            presetbox.deletebox(idx,name);
        });
    },
    deletebox:function(idx,name){
        var title = 'Delete Preset';
        var content = '<div class="row">Delete '+name+'?</div>';
        var action = '<span id="backtorel" class="left">&larr; Back</span><span id="confirmdelpreset" class="dangerous">Delete</span>';
        mbox(title,content,action,'narrow');
        
        $('#backtorel').on('click',function(event){
            event.stopPropagation();
            
            presetbox.editbox();
        });
        $('#confirmdelpreset').on('click',function(event){
            event.stopPropagation();
            
            userpref.deletepreset(presetbox.editing);
            presetbox.menubox();
            dialogbox.dispmsg('Deleted',true);
        });
    },
    editbox:function(idx){
        var title = 'Edit Preset';
        var content = '<div class="row"><input type="text" name="time" value="time" class="time"></div>';
        content+='<div class="row"><input type="text" name="name" value="name" class="name"></div>';
        content+='<div class="row"><select name="type" class="type">'+atypebox.activitytypeoption('all')+'</select></div>';
        content+='<div class="row"><select name="recurring type" class="recurring">'+pagevar.recurringtypestr()+'</select></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="duration in minutes" class="disabled first borderless duinwhat"><input type="number" value="30" name="duration" class="duration"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="priority" class="disabled first borderless ten"><input type="number" name="priorityinput" value="10" class="priority" min=1 max=10></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="alarm" class="disabled first borderless ten"><input type="number" name="alarminput" value="0" class="alarm" min=0></div>';
        content+='<div class="row"><textarea name="description" id="activdeta" class="description">description</textarea></div>';
        
        var action = '<span id="saveeditedpreset">Save</span><span id="backpresetlist" class="left">&larr; Back</span>';
        mbox(title,content,action,'');
        pageaction.texteditor();
        
        presetbox.editing = activtytemplate.template[idx];
        presetbox.editing.editform();
        presetbox.editing.idx = idx;
        
        $('.priority').on('change',function(event){
            event.stopPropagation();
            
            $(this).prev().css('opacity',($(this).val()/10));
        });
       
        $('#backpresetlist').on('click',function(event){
            event.stopPropagation();
            
            presetbox.menubox();
        });
        
        $('#saveeditedpreset').on('click',function(event){
            event.stopPropagation();
            presetbox.saveeditedform();
        });
        
        $('#messagebox').find('.time').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                presetbox.saveeditedform();
            }
        });
        $('#messagebox').find('.name').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                presetbox.saveeditedform();
            }
        });
        $('#messagebox').find('.duration').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                presetbox.saveeditedform();
            }
        });
        $('#messagebox').find('.priority').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                presetbox.saveeditedform();
            }
        });
        $('#messagebox').find('.alarm').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                presetbox.saveeditedform();
            }
        });
    },
    saveeditedform:function(){
        presetbox.editing.getformval();
            
        var newp = {};
        newp.idx = presetbox.editing.idx;
        newp.presetdata = {id:presetbox.editing.id,name:presetbox.editing.name,description:presetbox.editing.description,type:presetbox.editing.type,date:presetbox.editing.date,time:presetbox.editing.time,duration:presetbox.editing.duration,priority:presetbox.editing.priority};
        userpref.savepreset(newp);
        dialogbox.dispmsg('Saved',true);
    },
    newbox:function(){
        var title = 'New Preset';
        var content = '<div class="row"><input type="text" name="time" value="time" class="time"></div>';
        content+='<div class="row"><input type="text" name="name" value="name" class="name"></div>';
        content+='<div class="row"><select name="type" class="type">'+atypebox.activitytypeoption('all')+'</select></div>';
        content+='<div class="row"><select name="recurring type" class="recurring">'+pagevar.recurringtypestr()+'</select></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="duration in minutes" class="disabled first borderless duinwhat"><input type="number" value="30" name="duration" class="duration"></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="priority" class="disabled first borderless ten"><input type="number" name="priorityinput" value="10" class="priority" min=1 max=10></div>';
        content+='<div class="row multiinput double"><input type="text" disabled="true" value="alarm" class="disabled first borderless ten"><input type="number" name="alarminput" value="0" class="alarm" min=0></div>';
        content+='<div class="row"><textarea name="description" id="activdeta" class="description">description</textarea></div>';
        
        var action = '<span id="savenewpreset">Save</span><span id="backpresetlist" class="left">&larr; Back</span>';
        mbox(title,content,action,'');
        pageaction.texteditor();
        
        $('.priority').on('change',function(event){
            event.stopPropagation();
            
            $(this).prev().css('opacity',($(this).val()/10));
        });
        
        presetbox.editing = new activity({id:false,name:"name",description:"description",type:"type",date:false,time:'time',duration:30,priority:5});
        presetbox.editing.editform();
        
        $('#messagebox').find('.time').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                presetbox.saveforminput();
            }
        });
        $('#messagebox').find('.name').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                presetbox.saveforminput();
            }
        });
        $('#messagebox').find('.duration').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                presetbox.saveforminput();
            }
        });
        $('#messagebox').find('.priority').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                presetbox.saveforminput();
            }
        });
        $('#messagebox').find('.alarm').on('keyup',function(event){
            event.stopPropagation();
            
            if(event.which == 13){
                presetbox.saveforminput();
            }
        });
        
        $('#backpresetlist').on('click',function(event){
            event.stopPropagation();
            
            presetbox.menubox();
        });
        $('#savenewpreset').on('click',function(event){
            event.stopPropagation();
            
            presetbox.saveforminput();
        });
    },
    saveforminput:function(){
        presetbox.editing.getformval();
        
        var newp = {};
        newp.idx = activtytemplate.template.length;
        newp.presetdata = {id:presetbox.editing.id,name:presetbox.editing.name,description:presetbox.editing.description,type:presetbox.editing.type,date:presetbox.editing.date,time:presetbox.editing.time,duration:presetbox.editing.duration};
        userpref.savepreset(newp);
        presetbox.editbox(newp.idx);
        dialogbox.dispmsg('New Preset Added',true);
    }
};

var atypeproto = function(atypedata){
    this.id=atypedata.id;
    this.name=atypedata.name;
    this.oldname=atypedata.name;
    this.color=atypedata.color;
    this.oldcolor=atypedata.color;
    this.ade=atypedata.ade;
};

atypeproto.prototype.fillform=function(){
    $('#messagebox').find('.actname').val(this.name).addClass('filled').prop('id',this.id);
    $('#messagebox').find('.color').val(this.color).addClass('filled');
};
atypeproto.prototype.submitedited=function(){
    var name =$('#messagebox').find('.actname').val();
    var color = $('#messagebox').find('.color').val();
    if(name !='name'){
        this.name=name;
        this.color=color;
        
        if(this.oldcolor==this.color && this.oldname==this.name){
            dialogbox.dispmsg('no changes have been made');
            return;
        }
        
        if(this.id==false){
            this.id='local_'+atypebox.storedatype.length;
            atypebox.saveedited(true);
            this.updatecalendar();
            dialogbox.dispmsg('saved!',true);
            return;
        }
        if(this.id.indexOf('local_')!==-1){
            atypebox.saveedited(false);
            this.updatecalendar();
            dialogbox.dispmsg('saved!',true);
            return;
        }
    }
};
atypeproto.prototype.updatecalendar=function(){
    var tisact = this;
    $.each($('.calitem.'+this.id),function(ci,ce){
        $(ce).find('.roundr').css('background',tisact.color);
        $(ce).find('.calitemdur').css('background',tisact.color).css('opacity',0.3);
    });
    $.each($('.theday.'+this.id),function(ci,ce){
        if($(ce).attr('class').indexOf('sundae') === -1){
            $(ce).css('background',tisact.color);
        }
        else{
            $(ce).find('.addadeactiv').css('background',tisact.color);
        }
    });
    
    
    this.oldname = this.name;
    this.oldcolor = this.color;
};
atypeproto.prototype.senddelete=function(){
    var thistype = this;
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'activityc',a:'deleteoftype',d:{type:atypebox.editing.id}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        if(thistype.id.indexOf('local_') !==-1){
            atypebox.deletedone();
            return;
        }
    });
};

var atypebox={
    atname:function(typeid){
        var restype = pagevar.activtypename(typeid);
        if(restype=='false'){
            for(var k=0;k<atypebox.storedatype.length;k++){
                if(atypebox.storedatype[k].id==typeid){
                    restype = atypebox.storedatype[k].name;
                    break;
                }
            }
        }
        return restype;
    },
    postcat:function(){
        var postdata = [];
            for(var k=0;k<atypebox.storedatype.length;k++){
                postdata[postdata.length] = {id:atypebox.storedatype[k].id,name:atypebox.storedatype[k].name};
                
            }
            return JSON.stringify(postdata);
    },
    storedatype:[],
    activitytypeoption:function(ade){
        var opt = pagevar.activitytypeoption(ade);
        if(ade !== 'all'){
            if(ade!=1440 && ade !='all day'){
                ade = false;
            }
            else{
                ade = true;
            }   
        }
        for(var i=0;i<this.storedatype.length;i++){
            if(this.storedatype[i].ade == ade || ade==='all'){
                opt+='<option value="'+this.storedatype[i].id+'">'+this.storedatype[i].name+'</option>';   
            }
        }
        return opt;
    },
    acttypeadderaction:function(){
        $('#acttypeadder').on('focus',function(){
            actfinder.acttypefilteropt(this);
        });
        $('#acttypeadder').on('blur',function(){
            setTimeout(function(){
                $('#acttypeopt').remove();
            },300);
        });
        $('#acttypeadder').on('keyup',function(){
            switch(event.which){
                case 13:
                    if(typeof $(this).parent().next().children('.selected').attr('class') !== 'undefined'){
                        actfinder.selectacttypeopt($(this).parent().next().children('.selected'));   
                    }
                break;
                case 38:
                    actfinder.acttypenavup(this);
                break;
                case 40:
                    actfinder.acttypenavdown(this);
                break;
                default:
                    actfinder.acttypefilteropt(this);
            }
        });
    },
    acttypeadderpro:function(ade){
        var opt = pagevar.acttypeadderpro(ade);
        if(!this.storedatype.length){
            return opt;
        }
            for(var i=0;i<this.storedatype.length;i++){
                if(ade===true && !this.storedatype[i].ade){
                    continue;
                }
                else if(ade === false && this.storedatype[i].ade){
                    continue
                }
                opt+='<li id="acttypeadderopt_'+this.storedatype[i].id+'" class="">'+this.storedatype[i].name+'</li>';
            }
            return opt;
    },
    acttypeeditopt:function(tes){
        var opt = pagevar.acttypeeditopt(tes);
        if(!this.storedatype.length){
            return opt;
        }
        if(tes===true){
            for(var i=0;i<this.storedatype.length;i++){
                if(!this.storedatype[i].ade){
                    opt+='<div class="row multiinput bottomed"><span id="atname_'+this.storedatype[i].id+'" class="atname">'+this.storedatype[i].name+'</span><span class="right delat"></span><span class="right editat"></span></div>';
                }
            }
            return opt;   
        }
        if(tes===false){
            for(var i=0;i<this.storedatype.length;i++){
                if(this.storedatype[i].ade){
                    opt+='<div class="row multiinput bottomed"><span id="atname_'+this.storedatype[i].id+'" class="atname">'+this.storedatype[i].name+'</span><span class="right delat"></span><span class="right editat"></span></div>';
                }
            }
            return opt;  
        }
        
        if(tes==='regularevent'){
            for(var i=0;i<this.storedatype.length;i++){
                if(!this.storedatype[i].ade){
                    opt+='<div class="row multiinput bottomed"><span id="atname_'+this.storedatype[i].id+'" class="atname">'+this.storedatype[i].name+'</span><span class="right delat"></span><span class="right editat"></span></div>';
                }
            }
            return opt;  
        }
        if(tes==='alldayevent'){
            for(var i=0;i<this.storedatype.length;i++){
                if(this.storedatype[i].ade){
                    opt+='<div class="row multiinput bottomed"><span id="atname_'+this.storedatype[i].id+'" class="atname">'+this.storedatype[i].name+'</span><span class="right delat"></span><span class="right editat"></span></div>';
                }
            }
            return opt;  
        }
        
        switch($(tes).attr('id')){
            case 'regularevent':
                this.menuboxcontenttype = 'regularevent';
                for(var i=0;i<this.storedatype.length;i++){
                    if(!this.storedatype[i].ade){
                        opt+='<div class="row multiinput bottomed"><span id="atname_'+this.storedatype[i].id+'" class="atname">'+this.storedatype[i].name+'</span><span class="right delat"></span><span class="right editat"></span></div>';
                    }
                }
            break;
            case 'alldayevent':
                this.menuboxcontenttype = 'alldayevent';
                for(var i=0;i<this.storedatype.length;i++){
                    if(this.storedatype[i].ade){
                        opt+='<div class="row multiinput bottomed"><span id="atname_'+this.storedatype[i].id+'" class="atname">'+this.storedatype[i].name+'</span><span class="right delat"></span><span class="right editat"></span></div>';
                    }
                }
            break;
        }
        return opt; 
    },
    adduserdata:function(data){
        this.storedatype[this.storedatype.length] = new atypeproto(data);
    },
    editing:false,
    saveedited:function(newsubmit){
        if(newsubmit){
            console.log(newsubmit);
            this.storedatype[this.storedatype.length] =this.editing;
            this.editing.newinsert=true;
            userpref.saveatype(this.editing);
            this.editing.newinsert=false;
            return;
        }
        console.log(newsubmit+'##');
        for(var i=0;i<this.storedatype.length;i++){
            if(this.storedatype[i].id==this.editing.id){
                this.storedatype[i] =this.editing;
                userpref.saveatype(this.editing);
                return;
            }
        }
        for(var i=0;i<pagevar.activtype.length;i++){
            if(pagevar.activtype[i].id==this.editing.id){
                pagevar.activtype[i] = this.editing
                return;
            }
        }
        for(var i=0;i<pagevar.adeactivtype.length;i++){
            if(pagevar.adeactivtype[i].id==this.editing.id){
                pagevar.adeactivtype[i] =this.editing;
                return;
            }
        }  
    },
    gettoedit:function(id){
        this.editing=false;
        for(var i=0;i<this.storedatype.length;i++){
            if(this.storedatype[i].id==id){
                this.editing=this.storedatype[i];
            }
        }
        if(this.editing!==false)
            return;
            
        for(var i=0;i<pagevar.activtype.length;i++){
            if(pagevar.activtype[i].id==id){
                this.editing=new atypeproto(pagevar.activtype[i]);
            }
        }    
        if(this.editing!==false)
            return;
            
        for(var i=0;i<pagevar.adeactivtype.length;i++){
            if(pagevar.adeactivtype[i].id==id){
                this.editing=new atypeproto(pagevar.adeactivtype[i]);
            }
        }    
    },
    editlink:function(){
        $('.editat').on('click',function(event){
            event.stopPropagation();
            
            var id=$(this).siblings('.atname').attr('id').split('_');
            id.splice(0,1)
            id = id.join('_');
            atypebox.gettoedit(id);
            atypebox.editbox();
        });
        
        $('.delat').on('click',function(event){
            event.stopPropagation();
            
            var id=$(this).siblings('.atname').attr('id').split('_');
            id.splice(0,1)
            id = id.join('_');
            atypebox.gettoedit(id);
            
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'activityc',a:'countactoftype',d:{type:atypebox.editing.id}}
            }).done(function(msg){
                msg = JSON.parse(msg);
               atypebox.deletebox(msg.nactivities); 
            });
        });
    },
    deletebox:function(nactivities){
        var title   = 'Delete Activity Type';
        var content = '<div class="row">Delete type <b>'+atypebox.editing.name+'</b> ? It has '+nactivities+' activities in it</div>';
        var action  = '<span id="confirmdelatype" class="dangerous">Delete</span><span id="backtoatypelist" class="left">&larr; Back</span>';
        
        mbox(title,content,action,'narrow');
        
        $('#backtoatypelist').on('click',function(event){
            event.stopPropagation();
            
            atypebox.menubox();
        });
        
        $('#confirmdelatype').on('click',function(event){
            event.stopPropagation();
            atypebox.editing.senddelete();
        });
    },
    deletedone:function(){
        for(var i=0;i<this.storedatype.length;i++){
            if(this.storedatype[i].id==this.editing.id){
                pagevar.deleteactivityoftype(this.editing.id);
                userpref.pref['rareity_atype'].splice(i,1);
                this.storedatype.splice(i,1)
                userpref.saveatypes();
                
                this.menubox();
                dialogbox.dispmsg('<b>'+atypebox.editing.name+'</b> deleted',true);
                return;
            }
        }
        for(var i=0;i<pagevar.activtype.length;i++){
            if(pagevar.activtype[i].id==this.editing.id){
                pagevar.activtype.splice(i,1);
                this.menubox();
                dialogbox.dispmsg('<b>'+atypebox.editing.name+'</b> deleted',true);
                return;
            }
        }
        for(var i=0;i<pagevar.adeactivtype.length;i++){
            if(pagevar.adeactivtype[i].id==this.editing.id){
                pagevar.adeactivtype.splice(i,1);
                this.menubox();
                dialogbox.dispmsg('<b>'+atypebox.editing.name+'</b> deleted',true);
                return;
            }
        }  
    },
    menuboxcontenttype:true,
    menuboxradioinit:function(){
        if(this.menuboxcontenttype == 'alldayevent'){
            $('#alldayevent').prop('checked','checked');
        }
    },
    menubox:function(){
        var title   = 'Activity Types';
        var content = '<div class="row thirties multiinput"><input type="radio" name="acttypestype" class="acttypestype" id="regularevent" checked="checked"><span class="radiolabel">Regular</span><span class="right radiolabel">All Day</span><input type="radio" name="acttypestype" class="acttypestype right" id="alldayevent"></div><div style="height:80%;overflow:auto">'+this.acttypeeditopt(this.menuboxcontenttype)+'</div>';
        var action  = '<span id="addnewacttype">+ Add New</span>';
        
        mbox(title,content,action,'xxl');
        atypebox.menuboxradioinit();
        atypebox.editlink();
        
        $('#addnewacttype').on('click',function(event){
            event.stopPropagation();
            
            atypebox.addnewbox($('#alldayevent').prop('checked'));
        });
        
        $('.acttypestype').on('change',function(event){
            event.stopPropagation();
            
            $(this).parent().next().replaceWith('<div style="height:80%;overflow:auto">'+atypebox.acttypeeditopt(this)+'</div>');
            atypebox.editlink();
        });
        
        $('.radiolabel').on('click',function(event){
            var radi;
            if($(this).attr('class').indexOf('right')!==-1){
                radi = $(this).next();
                $(radi).prop('checked','checked');
            }
            else{
                radi = $(this).prev();
                $(radi).prop('checked','checked');
            }
            
            $(this).parent().next().replaceWith('<div style="height:80%;overflow:auto">'+atypebox.acttypeeditopt(radi)+'</div>');
            atypebox.editlink();
        });
    },
    previewnode:false,
    editbox:function(){
        var title   = 'Edit Activity Type';
        var content = '<div class="row"><input type="text" value="name" class="actname" name="name"></div>';
        content+='<div class="row"><input type="text" value="color" class="color" name="color" disabled="true" style="border:none;padding: 3px;width:60%;float:left;text-shadow:0px 0px 2px #ebebeb;"><input type="color" value="'+this.editing.color+'" id="actcolor" style="float:left"></div>';
        content+='<div class="row" id="nodepreview"><div id="nodebox"></div></div>';
        var action  = '<span id="savenewactype">Save</span><span id="backtoatypelist" class="left">&larr; Back</span>';
        
        mbox(title,content,action,'xxl');
        
        this.editing.fillform();
        
        setTimeout(function(){
            var sprep = $('#messagebox').find('.sp-replacer');
            $(sprep).css('float','left');
            $(sprep).css('width','52px');
            $(sprep).find('.sp-preview-inner').css('height','100%');
            
            if(atypebox.previewnode===false){
                atypebox.previewnode = new activity({id:false,name:"activity",description:"activity description",type:3,date:false,time:'04:00',duration:30,priority:10});
            }
            atypebox.previewnode.type = atypebox.editing.id;
            
            var nodebox = $('#messagebox').find('#nodebox');
            $(nodebox).css('height',pagevar.theboxheight+'px');
            $(nodebox).css('width',pagevar.theboxwidth+'px');
            
            $(nodebox).css('margin','44px auto 0px');
            atypebox.previewnode.previewdrawing(nodebox);
        },300);
        
        $('#actcolor').spectrum({
            move: function(color) {
                $('#messagebox').find('.color').val(color.toHexString());
                atypebox.editing.color = color.toHexString();
                atypebox.previewnode.previewdrawing(nodebox);
            },
            hide: function(color) {
                $('#messagebox').find('.color').val(color.toHexString());
                atypebox.editing.color = color.toHexString();
                atypebox.previewnode.previewdrawing(nodebox);
            },
            clickoutFiresChange: false,
            showInput: true,
            preferredFormat: "hex"
        });
        $('#savenewactype').on('click',function(event){
            event.stopPropagation();
            
            atypebox.editing.submitedited();
        });
        
        $('#backtoatypelist').on('click',function(event){
            event.stopPropagation();
            
            atypebox.menubox();
        });  
    },
    coloring:function(activobj){
        for(var i=0;i<this.storedatype.length;i++){
            if(this.storedatype[i].id == activobj.type){
                if(activobj.duration ==1440){
                    var classes = $('#ade_'+activobj.id).attr('class').split(' ');
                    for(var hi=0;hi<classes.length;hi++){
                        if(classes[hi]=='false'){
                            classes[hi] = activobj.type;
                        }
                    }
                    $('#ade_'+activobj.id).prop('class',classes.join(' '));
                    $('#ade_'+activobj.id).find('.addadeactiv').css('display','block');
                    if($.inArray('sundae',classes) !==-1){
                        $('#ade_'+activobj.id).find('.addadeactiv').css('color',this.storedatype[i].color);
                    }
                    else{
                        $('#ade_'+activobj.id).css('background',this.storedatype[i].color);
                    }
                    return;
                }
                else{
                    if(typeof $('#calitemnextday_'+activobj.id).attr('class') !== 'undefined'){
                        var tisstoretype = this;
                        $.each($('.calitemnextday_'+activobj.id),function(ci,ce){
                            var classes = $(ce).attr('class').split(' ');
                            for(var hi=0;hi<classes.length;hi++){
                                if(classes[hi]=='false'){
                                    classes[hi] = activobj.type;
                                }
                            }
                            $(ce).prop('class',classes.join(' '));
                            $(ce).css('background',tisstoretype.storedatype[i].color); 
                        });
                    }
                    
                    if(typeof $('#calitem_'+activobj.id).attr('class') !== 'undefined'){
                        $('#calitem_'+activobj.id).find('.roundr').css('background',this.storedatype[i].color);
                        $('#calitem_'+activobj.id).find('.calitemdur').css('background',this.storedatype[i].color);
                        var classes = $('#calitem_'+activobj.id).attr('class').split(' ');
                        for(var i=0;i<classes.length;i++){
                            if(classes[i]=='false'){
                                classes[i] = activobj.type;
                            }
                        }
                        $('#calitem_'+activobj.id).prop('class',classes.join(' '));
                        return;      
                    }
                }
            }
        }
        $('#calitem_'+activobj.id).find('.roundr').css('background',this.editing.color);
        $('#calitem_'+activobj.id).find('.calitemdur').css('background',this.editing.color);
        
        if(typeof $('#calitemnextday_'+activobj.id).attr('class') !== 'undefined'){
            var tisstoretype = this;
            $.each($('.calitemnextday_'+activobj.id),function(ci,ce){
                var classes = $(ce).attr('class').split(' ');
                for(var hi=0;hi<classes.length;hi++){
                    if(classes[hi]=='false'){
                        classes[hi] = activobj.type;
                    }
                }
                $(ce).prop('class',classes.join(' '));
                $(ce).css('background',tisstoretype.editing.color); 
            });
        }
    },
    addnewbox:function(ade){
        this.editing=new atypeproto({id:false,name:'name',color:'#bdbdbd',ade:ade});
        
        var title   = 'Add Activity Type';
        var content = '<div class="row"><input type="text" value="name" class="actname" name="name"></div>';
        content+='<div class="row"><input type="text" value="color" class="color" name="color" disabled="true" style="border:none;padding: 3px;width:60%;float:left;text-shadow:0px 0px 2px #ebebeb;"><input type="color" value="'+this.editing.color+'" id="actcolor" style="float:left"></div>';
        content+='<div class="row" id="nodepreview"><div id="nodebox"></div></div>';
        var action  = '<span id="savenewactype">Save</span><span id="backtoatypelist" class="left">&larr; Back</span>';
        
        mbox(title,content,action,'xxl');
        
        setTimeout(function(){
            var sprep = $('#messagebox').find('.sp-replacer');
            $(sprep).css('float','left');
            $(sprep).css('width','52px');
            $(sprep).find('.sp-preview-inner').css('height','100%');
            
            if(atypebox.previewnode===false){
                atypebox.previewnode = new activity({id:false,name:"activity",description:"activity description",type:3,date:false,time:'04:00',duration:30,priority:5});
            }
            atypebox.previewnode.type = atypebox.editing.id;
            
            var nodebox = $('#messagebox').find('#nodebox');
            $(nodebox).css('height',pagevar.theboxheight+'px');
            $(nodebox).css('width',pagevar.theboxwidth+'px');
            
            $(nodebox).css('margin','44px auto 0px');
            atypebox.previewnode.previewdrawing(nodebox);
        },300);
        
        $('#actcolor').spectrum({
            move: function(color) {
                $('#messagebox').find('.color').val(color.toHexString());
                atypebox.editing.color = color.toHexString();
                atypebox.previewnode.previewdrawing(nodebox);
            },
            hide: function(color) {
                $('#messagebox').find('.color').val(color.toHexString());
                atypebox.editing.color = color.toHexString();
                atypebox.previewnode.previewdrawing(nodebox);
            },
            clickoutFiresChange: false,
            showInput: true,
            preferredFormat: "hex"
        });
        
                
        $('#backtoatypelist').on('click',function(event){
            event.stopPropagation();
            
            atypebox.menubox();
        });
        $('#savenewactype').on('click',function(event){
            event.stopPropagation();
            
            atypebox.editing.submitedited();
        });
    }
};

var alarming = {
    alarmloaded:[],
    waitalarmloaded:0,
    alarms:[],
    resetpage:function(){
        if(this.alarms.length){
            for(var o=0;o<this.alarms.length;o++){
                clearTimeout(this.alarms[o].timer);
            }
            this.alarms = [];
        }
    },
    audiotester:[],
    audiotested:false,
    setaudiotester:function(){     
        if(this.audiotested){
            setTimeout(function(){
                alarming.prepinstallalarm();
            },700);
            
            return;
        }
        this.waitalarmloaded = 0;
        this.audiotested = true;
        
        setTimeout(function(){
            alarming.prepinstallalarm();
        },700);
    },
    setalarm:function(){
        this.setaudiotester();
    },
    instalalarmreport:[],
    prepinstallalarm:function(){
        this.installalarm();
    },
    installalarm:function(){
        if(this.alarms.length){
            for(var i=0;i<this.alarms.length;i++){
                clearTimeout(this.alarms[i].timer);
            }
            this.alarms = [];
        }
        
        alarming.instalalarmreport[alarming.instalalarmreport.length] = true;
        this.resetpage();
                
        var cbox = $('.calitem.startrareity').parent();
        this.hourbox(cbox);
        if(typeof $('.calitem.startrareity').parent().parent().parent().next().attr('class') !=='undefined' &&  $('.calitem.startrareity').parent().parent().parent().next().attr('class').indexOf('aday') !== -1){
            cbox = $('.calitem.startrareity').parent().parent().parent().next().find('.anhour_0');
            this.hourbox(cbox);   
        }
        
        if(!this.greetuser)
            this.welcomeuser();
    },
    greetuser:false,
    welcomeuser:function(){
        this.greetuser=true;
        uncachealarm.resetalarm('welcome');
    },
    hourbox:function(cbox){
        while(typeof $(cbox).attr('class') !== 'undefined' && $(cbox).attr('class').indexOf('anhour') !== -1){
            $.each($(cbox).children('.calitem'),function(ci,ce){
                if($(ce).attr('class').indexOf('startrareity') === -1)
                    alarming.setalarm_($(ce).attr('id').split('_')[1]);
            });
            cbox = $(cbox).next();
        }
    },
    setalarm_:function(id){
        var actdata = pagevar.getactivitydata(id);
        if(actdata === false){
            return;
        }
        actdata.date = actdata.time.split(' ')[0];
        actdata.time = actdata.time.split(' ')[1];
        
        var ddate = actdata.date.split('-');
        var dtime = actdata.time.split(':');
        var alarmpref = actdata.alarm*60000;
        ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
        if((ddate - pagevar.thetime - alarmpref) > 0){
            this.alarms[this.alarms.length] = [];
            this.alarms[this.alarms.length-1].debug =((ddate-pagevar.thetime-alarmpref));
            this.alarms[this.alarms.length-1].debugs =alarmpref;
            this.alarms[this.alarms.length-1].timer = setTimeout(function(){
                alarming.alarmuser(id);
            },(ddate-pagevar.thetime-alarmpref));
        }
    },
    alarmuser:function(actid){
        if(!uncachealarm.requested){
            pagevar.getactivity(actid);
            uncachealarm.requested = true;
            if(pagevar.activityinedit.type == 3){
                if(pagevar.activityinedit.name.toLowerCase() == 'shubuh' || pagevar.activityinedit.name.toLowerCase() == 'subuh'){
                    uncachealarm.resetalarm('fajralarm');
                }
                else{
                    uncachealarm.resetalarm('prayalarm');
                }
            }
            else{
                uncachealarm.resetalarm('actalarm');
            }
            return;
        }
    },
    alarmuser_:function(){
        uncachealarm.requested = false;
        var title   = 'Activity Reminder';
        var content = '<div class="row">The time for scheduled activity <b>'+pagevar.activityinedit.name+'</b> has come</div>';
        var action  = '';
        
        if(pagevar.activityinedit.alarm > 0){
            content = '<div class="row">'+pagevar.activityinedit.alarm+' minutes to <b>'+pagevar.activityinedit.name+':</b></div>';
        }
        
        mbox(title,content,action,'narrow');
        if(pagevar.activityinedit.type == 3){
            if(pagevar.activityinedit.name.toLowerCase() == 'shubuh' || pagevar.activityinedit.name.toLowerCase() == 'subuh'){
                fajralarm.play();
                fajralarm.volume = (0.1 * pagevar.activityinedit.priority);
            }
            else{
                prayalarm.play();
                prayalarm.volume = (0.1 * pagevar.activityinedit.priority);
            }
        }
        else{
            actalarm.play();
            actalarm.volume = (0.1 * pagevar.activityinedit.priority);
        }
            
        $('#closemessagebox').on('click',function(event){
            event.stopPropagation();
            
            if(pagevar.activityinedit.type == 3){
                if(pagevar.activityinedit.name.toLowerCase() == 'shubuh' || pagevar.activityinedit.name.toLowerCase() == 'subuh'){
                    fajralarm.pause();
                }
                else{
                    prayalarm.pause();
                }
            }
            else{
                actalarm.pause();
            }
            $('#messagebox').removeClass('active');
            $('.pagecontainer').css('opacity','1');
        });
    }
};


var uncachealarm = {
    requested:false,
    uncache:function(alarmurl,type){
        $.ajax({
            url:'',
            type:'POST',
            data:{app:appname,p:'home',a:'uncachealarm',d:{alarmurl:alarmurl,type:type}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            switch(type){
                case 'welcome':
                    welcomeaudio = new Audio();
                    welcomeaudio.src = msg.alarmurl;
                    welcomeaudio.addEventListener('ended',function(){
                        uncachealarm.cleanalarm(welcomeaudio.src,'welcome');
                    });
                    welcomeaudio.addEventListener('pause',function(){
                        uncachealarm.cleanalarm(welcomeaudio.src,'welcome');
                    });
                    welcomeaudio.addEventListener('canplay',function(){
                        alarming.greetuser=true;
                        this.play();
                        
                        var cbox = $('.anhour.thisthetime');
                        var waitinglist = '';
                        var counteract = 0;
                        
                        $.each($(cbox).children(),function(ci,ce){
                            if($(ce).attr('class').indexOf('startrareity') !== -1){
                            }
                            else{
                                var actdata = pagevar.getactivitydata($(ce).attr('id').split('_')[1]);
                                actdata.date = actdata.time.split(' ')[0];
                                actdata.time = actdata.time.split(' ')[1];
                                
                                var ddate = actdata.date.split('-');
                                var dtime = actdata.time.split(':');
                                ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
                                if((ddate - pagevar.thetime) > 0){
                                    counteract++;
                                    if(waitinglist != ''){
                                        waitinglist+=', ';
                                    }
                                    waitinglist+='<span class="wail" id="wail_'+$(ce).attr('id').split('_')[1]+'">'+$(ce).find('.calitemtitle').html()+'<span class="wailtime">('+actdata.time.substr(0,5)+')</span></span>';
                                }
                            }
                        });
                        while($(cbox).attr('class').indexOf('anhour_23') === -1){
                            cbox = $(cbox).next();
                            counteract += $(cbox).children().length;
                            
                            $.each($(cbox).children(),function(ci,ce){
                                if(waitinglist != ''){
                                    waitinglist+=', ';
                                }
                                var actdata = pagevar.getactivitydata($(ce).attr('id').split('_')[1]);
                                waitinglist+='<span class="wail" id="wail_'+$(ce).attr('id').split('_')[1]+'">'+$(ce).find('.calitemtitle').html()+'<span class="wailtime">('+actdata.time.split(' ')[1].substr(0,5)+')</span></span>';
                            });
                        }
                    
                        var title       = 'Welcome to '+appname;
                        var plursingact = counteract > 1 ? 'Activities' : 'Activity';
                        var content     = counteract > 0 ? '<div class="row">You Have '+counteract+' '+plursingact+' for Today</div><div class="row" style="margin-top:19px;">'+waitinglist+'</div>' : '<div class="row">It Seems That You Have No Activity Waiting for You Today</div>';
                        var action      = '';
                        
                        mbox(title,content,action,'narrow');
                        pageaction.pageloaded();
                        
                        $('.wail').on('click',function(event){
                            event.stopPropagation();
                            
                            welcomeaudio.pause();
                            pageaction.detailsofact(this);
                        });
                        $('#closemessagebox').on('click',function(event){
                            event.stopPropagation();
                            
                            welcomeaudio.pause();
                            $('#messagebox').removeClass('active');
                            $('.pagecontainer').css('opacity','1');
                        });
                    });
                break;
                case 'fajralarm':
                    fajralarm = new Audio();
                    fajralarm.src = msg.alarmurl;
                    fajralarm.addEventListener('ended',function(){
                        uncachealarm.cleanalarm(fajralarm.src,'fajralarm');
                    });
                    fajralarm.addEventListener('pause',function(){
                        uncachealarm.cleanalarm(fajralarm.src,'fajralarm');
                    });
                    fajralarm.addEventListener('canplay',function(){
                        alarming.alarmuser_();
                    });
                break;
                case 'prayalarm':
                    prayalarm = new Audio();
                    prayalarm.src = msg.alarmurl;
                    prayalarm.addEventListener('ended',function(){
                        uncachealarm.cleanalarm(prayalarm.src,'prayalarm');
                    });
                    prayalarm.addEventListener('pause',function(){
                        uncachealarm.cleanalarm(prayalarm.src,'prayalarm');
                    });
                    prayalarm.addEventListener('canplay',function(){
                        alarming.alarmuser_();
                    });
                break;
                case 'actalarm':
                    actalarm = new Audio();
                    actalarm.src = msg.alarmurl;
                    actalarm.addEventListener('ended',function(){
                        uncachealarm.cleanalarm(actalarm.src,'actalarm');
                    });
                    actalarm.addEventListener('pause',function(){
                        uncachealarm.cleanalarm(actalarm.src,'actalarm');
                    });
                    actalarm.addEventListener('canplay',function(){
                        alarming.alarmuser_();
                    });
                break;
            }
        });
    },
    cleanalarm:function(url,type){
         $.ajax({
            url:'',
            type:'POST',
            data:{app:appname,p:'home',a:'cleanalarm',d:{url:url,type:type}}
        }).done(function(msg){
        });
    },
    resetalarm:function(type){
        switch(type){
            case 'welcome':
                uncachealarm.uncache(rareitywelcomealarmurl,type);
            break;
            case 'fajralarm':
                uncachealarm.uncache(fajralarm.src,type);
            break;
            case 'prayalarm':
                uncachealarm.uncache(prayalarm.src,type);
            break;
            case 'actalarm':
                uncachealarm.uncache(actalarm.src,type);
            break;
        }
    }
};

var viewopts = {
    boxheight:false,
    boxwidth:false,
    thenodesize:false,
    defaultviewmode:false,
    defaultsizes:[],
    tempnodesize:26,
    prionodesize:0,
    initialized:false,
    anodesize:function(priority,duration){
        if(this.thenodesize===false){
          this.prionodesize = this.tempnodesize-Math.max(0,(10-(duration/6)));
        }else{
           this.prionodesize = this.thenodesize-Math.max(0,(10-(duration/6)));
        }
        return this.prionodesize;
    },
    updatenodedrawing:function(node){
        console.log($(node).attr('class')+'--'+$(node).attr('id')+'--'+$(node).parent().attr('class'));
        var boxtime = $(node).parent().attr('class').split('_')[1].split(' ')[0];
        var box = $(node).parent();
        $('#calitemtitletester').html($(node).children('.calitemtitle').html());
        $(node).children('.calitemtitle').css('width',Math.min(205,$('#calitemtitletester').width())+'px');
        
        var calitemwid = $(node).width();
        var boxheight = $(node).parent().height();
        var boxwidth = $(node).parent().width();
        var boxtimeoffset = (parseInt($(node).find('.watch').html().split(':')[1])/60)*boxwidth;
        var aminutewidth = ($(box).width()/60);
        var durationwidth = aminutewidth*parseInt($(node).find('.calitemdurtext').html().split('(')[0]);
        var boxwidthleft = ((24-boxtime)*boxwidth)-boxtimeoffset;
        roundrtopoffset = (boxheight-viewopts.thenodesize)/2;
        
        durationnextday = (boxwidthleft-durationwidth);
        
        $(node).children().css('line-height',viewopts.thenodesize+'px');
        $(node).children('.calitemdur').css('width',durationwidth+'px');
        $(node).children('.calitemdur').css('margin-left',(0-(calitemwid/2))+'px');
        
        $(node).css('left',boxtimeoffset+'px');
        $(node).css('top',roundrtopoffset+'px');
        
        if(boxtime!=0){
            if(Math.max(calitemwid,$(node).children('.calitemtitle').width()) != calitemwid){
                var margleft = 0-(($(node).children('.calitemtitle').width()-calitemwid)/2);
                $(node).children('.calitemtitle').css('margin-left',margleft+'px');
            }
        }
        else{
            $(node).children().css('text-align','left');
        }
    },
    paction:function(){
        $('#messagebox').find('.boxwidth').on('change',function(event){
            event.stopPropagation();
            
            if($(this).val() - viewopts.boxwidth >4){
                $(this).val(viewopts.boxwidth);
                return;
            }
            $(this).blur();
            mboxloading.loading(this);
            
            
            viewopts.boxwidth = $(this).val();
            viewopts.updatequeue = new Array($('.anhour').length);
            viewopts.waitingforqueue('pagesetup');
            viewopts.updatelayout('boxwidth');
        });
        $('#messagebox').find('.boxheight').on('change',function(event){
            event.stopPropagation();
            
            $(this).blur();
            mboxloading.loading(this);
            
            viewopts.boxheight = $(this).val();
            viewopts.updatequeue = new Array($('.aday').length);
            viewopts.waitingforqueue('pagesetup');
            viewopts.updatelayout('boxheight');
        });
        $('#messagebox').find('.nodesize').on('change',function(event){
            event.stopPropagation();
            
            $(this).blur();
            mboxloading.loading(this);
            
            viewopts.thenodesize = $(this).val();
            viewopts.updatelayout('nodesize');
        });
         $('#messagebox').find('#viewmodeoptweek').next().on('click',function(event){
            event.stopPropagation();
            
            if(viewopts.defaultviewmode == 'weekly'){
                return;
            }
            mboxloading.loading(false);
            
            $('#messagebox').find('#viewmodeoptweek').prop('checked','checked');
            pagevar.defaultviewmode = viewopts.defaultviewmode = 'weekly';
            viewopts.updatelayout('defaultviewmode');
        });
        $('#messagebox').find('#viewmodeoptmonth').next().on('click',function(event){
            event.stopPropagation();
            
            if(viewopts.defaultviewmode == 'monthly'){
                return;
            }
            mboxloading.loading(false);
            
            $('#messagebox').find('#viewmodeoptmonth').prop('checked','checked');
            pagevar.defaultviewmode = viewopts.defaultviewmode = 'monthly';
            viewopts.updatelayout('defaultviewmode');
        });
        $('#messagebox').find('#viewmodeoptmonth').on('change',function(event){
            event.stopPropagation();
            
            mboxloading.loading(false);
            
            pagevar.defaultviewmode = viewopts.defaultviewmode = 'monthly';
            viewopts.updatelayout('defaultviewmode');
        });
        $('#messagebox').find('#viewmodeoptweek').on('change',function(event){
            event.stopPropagation();
            
            mboxloading.loading(false);
            
            pagevar.defaultviewmode = viewopts.defaultviewmode = 'weekly';
            viewopts.updatelayout('defaultviewmode');
        });
    },
    userslayout:false,
    updatelayout:function(wihe){
        switch(wihe){
            case 'boxwidth':
                viewopts.userslayout = true;
                $('.anhour').animate({'width':viewopts.boxwidth},'fast',function(){
                    viewopts.splicequeue(false);
                });
            break;
            case 'boxheight':
                viewopts.userslayout = true;
                $('.aday').animate({'height':viewopts.boxheight},'fast',function(){
                    viewopts.splicequeue(false);
                });
            break;
            case 'nodesize':
                viewopts.userslayout = true;
                viewopts.updatequeue[viewopts.updatequeue.length] = true;
                viewopts.waitingforqueue('pagesetup');
                viewopts.splicequeue(true);
                return;
                $('.calitem').animate({'height':viewopts.thenodesize},'fast',function(){
                    $(this).css('width',viewopts.thenodesize+'px');
                    viewopts.updatenodedrawing(this);
                });
            break;
            case 'defaultviewmode':
                dialogbox.dispmsg('reloading...',false);
                pagevar.reloadpage(true);
            break;
        }
        this.userreset = false;
    },
    init:function(){
        this.boxwidth = userpref.pref['rareity_boxwidth']   ==null || userpref.pref['rareity_boxwidth']== 'null' ? pagevar.theboxwidth : userpref.pref['rareity_boxwidth'];
        this.boxheight = userpref.pref['rareity_boxheight'] ==null || userpref.pref['rareity_boxheight'] =='null' ? pagevar.theboxheight : userpref.pref['rareity_boxheight'];
        this.thenodesize = userpref.pref['rareity_nodesize'] ==null || userpref.pref['rareity_nodesize'] == 'null' ? false : userpref.pref['rareity_nodesize'];
        this.defaultviewmode = userpref.pref['rareity_defaultviewmode'] ==null || userpref.pref['rareity_defaultviewmode'] =='null' ? 'weekly' : userpref.pref['rareity_defaultviewmode'];
    },
    initdefault:function(){
        viewopts.defaultsizes['defaultviewmode']    = pagevar.defaultviewmode;
        viewopts.defaultsizes['theboxwidth']        = pagevar.theboxwidth;
        viewopts.defaultsizes['theboxheight']       = pagevar.theboxheight;
        viewopts.defaultsizes['thenodesize']        = pagevar.thenodesize;
    },
    initdefaultviewmode:function(){
        this.defaultviewmode = userpref.pref['rareity_defaultviewmode'] ==null || userpref.pref['rareity_defaultviewmode'] =='null' ? 'weekly' : userpref.pref['rareity_defaultviewmode'];
    },
    userreset:false,
    resetview:function(){
        viewopts.userslayout = false;
        this.userreset = true;
        if(this.boxwidth !=viewopts.defaultsizes['theboxwidth'] && this.boxheight != viewopts.defaultsizes['theboxheight']){
            this.boxwidth = viewopts.defaultsizes['theboxwidth'];
            this.boxheight = viewopts.defaultsizes['theboxheight'];
            
            this.updatequeue = new Array($('.aday').length+$('.anhour').length);
            
            this.waitingforqueue('pagesetup');
            this.updatelayout('boxwidth');
            this.updatelayout('boxheight');
        }
        else{
            if(this.boxheight != viewopts.defaultsizes['theboxheight']){
                this.boxwidth = viewopts.defaultsizes['theboxheight'];
                this.updatequeue = new Array($('.aday').length);
                this.waitingforqueue('pagesetup');
                this.updatelayout('boxheight');
            }   
            if(this.boxwidth != viewopts.defaultsizes['theboxwidth']){
                this.boxwidth = viewopts.defaultsizes['theboxwidth'];
                this.updatequeue = new Array($('.anhour').length);
                this.waitingforqueue('pagesetup');
                this.updatelayout('boxwidth');
            }   
        }
        if(this.thenodesize != viewopts.defaultsizes['thenodesize']){
            this.thenodesize = viewopts.defaultsizes['thenodesize'];
            this.updatelayout('nodesize');
        }
        if(this.defaultviewmode != viewopts.defaultsizes['defaultviewmode']){
            this.defaultviewmode = viewopts.defaultsizes['defaultviewmode'];
            this.updatelayout('defaultviewmode');
        }
        this.menubox();
    },
    updatequeue:[],
    funcinqueue:[],
    onliner:false,
    splicequeue:function(checkqueue){
        this.updatequeue.splice(0,1);
        if(!this.updatequeue.length){
            this.executefuncinqueue();
        }
        else{
            if(checkqueue)
            viewopts.onliner = setInterval(function(){
                viewopts.checkqueue();
            },500);
        }
    },
    checkqueue:function(){
        if(!this.updatequeue.length){
            this.executefuncinqueue();
        }
    },
    executefuncinqueue:function(){
        if(this.updatequeue.length){
            return;
        }
        for(var i=0;i<this.funcinqueue.length;i++){
            switch(this.funcinqueue[i]){
                case 'pagesetup':
                    pageaction.pagesetup();
                break;
                case 'scrollintocact':
                    pagevar.scrollintocact();
                break;
                case 'extrapprep':
                    pageaction.extrapprep();
                break;
            }   
            this.funcinqueue.splice(i,1);
            i--;
        }
        clearInterval(viewopts.onliner);
    },
    waitingforqueue:function(func){
        if($.inArray(func,this.funcinqueue)===-1){
            this.funcinqueue[this.funcinqueue.length] = func;   
        }
    },
    updatenodesize:function(){
        if(!viewopts.initialized){
            viewopts.initialized = true;
            viewopts.initdefault();
            viewopts.init();
        }

        if(this.defaultviewmode != pagevar.defaultviewmode){
            pagevar.defaultviewmode = this.defaultviewmode;
            this.updatelayout('defaultviewmode');
        }
        if(this.boxwidth != pagevar.theboxwidth && this.boxheight != pagevar.theboxheight){
            pagevar.theboxwidth = this.boxwidth;
            pagevar.theboxheight = this.boxheight;
            
            this.updatequeue = new Array($('.aday').length+$('.anhour').length);
            
            this.waitingforqueue('pagesetup');
            this.updatelayout('boxwidth');
            this.updatelayout('boxheight');
        }
        else{
            if(this.boxheight != pagevar.theboxheight){
                pagevar.theboxheight = this.boxheight;
                this.updatequeue = new Array($('.aday').length);
                this.waitingforqueue('pagesetup');
                this.updatelayout('boxheight');
            }   
            if(this.boxwidth != pagevar.theboxwidth){
                pagevar.theboxwidth = this.boxwidth;
                this.updatequeue = new Array($('.anhour').length);
                this.waitingforqueue('pagesetup');
                this.updatelayout('boxwidth');
            }   
        }
        if(this.thenodesize===false){
            this.thenodesize = pagevar.thenodesize;
            this.updatelayout('nodesize');
        }
        else{
            if(this.thenodesize !=pagevar.thenodesize){
                pagevar.thenodesize = this.thenodesize;
                this.updatelayout('nodesize');
            }
        }
    },
    initform:function(){
        if(this.defaultviewmode=='monthly'){
            $('#messagebox').find('#viewmodeoptmonth').prop('checked','checked');
        }
        else{
            $('#messagebox').find('#viewmodeoptweek').prop('checked','checked');
        }
        $('#messagebox').find('.boxwidth').val(this.boxwidth);
        $('#messagebox').find('.boxheight').val(this.boxheight);
        $('#messagebox').find('.nodesize').val(this.thenodesize);
        
        this.paction();
    },
    confirmsettings:function(){
        if(this.userreset){
            userpref.pref['rareity_boxwidth']       = null;
            userpref.pref['rareity_boxheight']      = null;
            userpref.pref['rareity_nodesize']       = null;
            userpref.pref['rareity_defaultviewmode']= null;
        }
        else{
            userpref.pref['rareity_boxwidth']       = this.boxwidth;
            userpref.pref['rareity_boxheight']      = this.boxheight;
            userpref.pref['rareity_nodesize']       = this.thenodesize;
            userpref.pref['rareity_defaultviewmode']= this.defaultviewmode;
        }
        userpref.saveviewopts();
    },
    menubox:function(){
        var title   = 'View Options';
        var content = '<div class="row multiinput bottomed"><span>default view mode</span><span class="right"><input type="radio" class="defaultviewmode" name="defaultviewmode" id="viewmodeoptweek"><span class="radiolabel">weekly</span><input type="radio" name="defaultviewmode" id="viewmodeoptmonth" class="defaultviewmode"><span class="radiolabel">monthly</span></span></div>';
        content += '<div class="row multiinput bottomed"><span>box size</span><span class="right mostly"><span class="fifty"><span class="label">width:</span><input type="number" name="width" value="0" class="boxwidth eighty right"></span><span class="fifty"><span class="label">height:</span><input type="number" name="height" value="0" class="boxheight eighty right"></span></span></div>';
        content += '<div class="row multiinput bottomed"><span>activity node size</span><span class="right fifty"><span class="fifty right"><input type="number" name="nodesizewidth" value="0" class="nodesize fourseven right"></span></span></div>';
        
        var action  = '<span id="resetviewopts">Reset</span><span id="confirmviewopts">Save</span>';
        
        mbox(title,content,action,'xxl');
        this.initform();
        
        $('#resetviewopts').on('click',function(event){
            event.stopPropagation();
            
            viewopts.resetview();
        });
        $('#confirmviewopts').on('click',function(event){
            event.stopPropagation();
            
            viewopts.confirmsettings();
            dialogbox.close();
        });
    }
};

var userpref={
    pref:[],
    prefidx:['rareity_atype','rareity_boxwidth','rareity_boxheight','rareity_nodesize','rareity_defaultviewmode','rareity_presets','rareity_pages'],
    localstorage:false,
    getLocalStorage:function(){
        if (typeof localStorage == "object"){
            this.localstorage =  localStorage;
        } else if (typeof globalStorage == "object"){
            this.localstorage = globalStorage[location.host];
        } else {
            this.localstorage = false;
        }
    },
    saveviewopts:function(){
        this.localstorage.setItem('rareity_boxwidth',this.pref['rareity_boxwidth']);
        this.localstorage.setItem('rareity_boxheight',this.pref['rareity_boxheight']);
        this.localstorage.setItem('rareity_nodesize',this.pref['rareity_nodesize']);
        this.localstorage.setItem('rareity_defaultviewmode',this.pref['rareity_defaultviewmode']);
    },
    savepages:function(){
        this.localstorage.setItem('rareity_pages',JSON.stringify(this.pref['rareity_pages']));
    },
    init:function(){
        this.getLocalStorage();
        if(this.localstorage===false){
            return;
        }
        for(var i=0;i<this.prefidx.length;i++){
            this.pref[this.prefidx[i]] = this.localstorage.getItem(this.prefidx[i]);
        }
        if(this.pref['rareity_pages'] != null){
            this.pref['rareity_pages'] = JSON.parse(this.pref['rareity_pages']);
            if(!userpref.pref['rareity_pages'].length){
                $('#savedview').addClass('disabled');
            }
        }
        else{
            this.pref['rareity_pages'] = [];
            $('#savedview').addClass('disabled');
        }
        if(this.pref['rareity_atype'] !=null){
            this.pref['rareity_atype'] = JSON.parse(this.pref['rareity_atype']);
            for(var i=0;i<this.pref['rareity_atype'].length;i++){
                atypebox.adduserdata(this.pref['rareity_atype'][i]);
            }
        }
        if(this.pref['rareity_presets'] !=null){
            this.pref['rareity_presets'] = JSON.parse(this.pref['rareity_presets']);
            for(var i=0;i<this.pref['rareity_presets'].length;i++){
                activtytemplate.template[activtytemplate.template.length] = new activity(this.pref['rareity_presets'][i]);
            }
        }
        viewopts.initdefaultviewmode();
    },
    saveatype:function(atypeobj){
        if(this.pref['rareity_atype']==null){
            this.pref['rareity_atype'] = [];
        }
        
        if(typeof atypeobj.newinsert !=='undefined' && atypeobj.newinsert){
            this.pref['rareity_atype'][this.pref['rareity_atype'].length] = {id:atypeobj.id,name:atypeobj.name,color:atypeobj.color,ade:atypeobj.ade};
            this.saveatypes();
            return;
        }
        for(var i=0;i<this.pref['rareity_atype'].length;i++){
            if(this.pref['rareity_atype'][i].id==atypeobj.id){
                this.pref['rareity_atype'][i] ={id:atypeobj.id,name:atypeobj.name,color:atypeobj.color,ade:atypeobj.ade};
                this.saveatypes();
                return;
            }
        }
    },
    saveatypes:function(){
        this.localstorage.setItem('rareity_atype',JSON.stringify(this.pref['rareity_atype']));
    },
    deletepreset:function(data){
        activtytemplate.template.splice(data.idx,1);
        this.pref['rareity_presets'].splice(data.idx,1);
        this.savepresets();
        activtytemplate.prepautoco();
    },
    savepreset:function(data){
        activtytemplate.template[data.idx] = new activity(data.presetdata);
        this.pref['rareity_presets'][data.idx] = data.presetdata;
        this.savepresets();
        activtytemplate.prepautoco();
    },
    savepresets:function(){
        this.localstorage.setItem('rareity_presets',JSON.stringify(this.pref['rareity_presets']));
    },
    getpreset:function(){
        this.pref['rareity_presets']=[];
        for(var i=0;i<activtytemplate.template.length;i++){
            this.pref['rareity_presets'][i]={id:activtytemplate.template[i].id,name:activtytemplate.template[i].name,description:activtytemplate.template[i].description,type:activtytemplate.template[i].type,date:activtytemplate.template[i].date,time:activtytemplate.template[i].time,duration:activtytemplate.template[i].duration,priority:activtytemplate.template[i].priority}
        }
        this.savepresets();
    }
};
var activtytemplate={
    template:[],
    autocostr:'',
    init:function(){
        userpref.init();
        if(!this.template.length){
            this.template[this.template.length] = new activity({id:false,name:"subuh",description:"shalat subuh 5 menit",type:3,date:false,time:'04:00',duration:5,priority:5});
            this.template[this.template.length] = new activity({id:false,name:"dhuha",description:"shalat dhuha 30 menit",type:3,date:false,time:'08:00',duration:30,priority:5});
            this.template[this.template.length] = new activity({id:false,name:"zuhur",description:"shalat zuhur 5 menit",type:3,date:false,time:'12:00',duration:5,priority:5});
            this.template[this.template.length] = new activity({id:false,name:"ashar",description:"shalat ashar 5 menit",type:3,date:false,time:'15:00',duration:5,priority:5});
            this.template[this.template.length] = new activity({id:false,name:"maghrib",description:"shalat maghrib 5 menit",type:3,date:false,time:'18:00',duration:5,priority:5});
            this.template[this.template.length] = new activity({id:false,name:"isya",description:"shalat isya 5 menit",type:3,date:false,time:'19:00',duration:5,priority:5});
            this.template[this.template.length] = new activity({id:false,name:"istirahat",description:"istirahat bekerja",type:1,date:false,time:false,duration:60,priority:5});
            userpref.getpreset();
        }
        
        this.prepautoco();
        this.pageaction();
    },
    presetseditopt:function(){
        var opt='';
        for(var i=0;i<this.template.length;i++){
            opt+='<div class="row multiinput bottomed"><span id="presetname_'+i+'" class="presetname">'+this.template[i].name+'</span><span class="right delpreset"></span><span class="right editpreset"></span></div>';
        }
        return opt;
    },
    prepautoco:function(){
        this.autocostr='<ul id="templateopts">';
        for(var i=0;i<this.template.length;i++){
            this.autocostr+='<li class="templateopt" id="templateopt_'+i+'">'+this.template[i].name+'</li>';
        }
        this.autocostr+='</ul>';
    },
    filteropt:function(elem){
        this.provideautoco(elem);
        var typed = $(elem).val();
        
        elem = $(elem).parent().next();
        $.each($(elem).children(),function(ei,ee){
            if($(ee).html().indexOf(typed)===-1){
                $(ee).addClass('hide');
            }
            else{
                $(ee).removeClass('hide');
            }
        });
    },
    provideautoco:function(elem){
        if(typeof $(elem).parent().next().attr('id') ==='undefined' || $(elem).parent().next().attr('id')!='templateopts'){
            $(elem).parent().after(this.autocostr);
            $('#templateopts').css('top',($(elem).parent().height()+$(elem).parent()[0].offsetTop)+'px');
        }
    },
    navup:function(elem){
        this.provideautoco(elem);
        var selected = false;
        elem = $(elem).parent().next();
        var cy=0;
        if($(elem).children('.selected').length){
            selected = $(elem).children('.selected');
            $(selected).removeClass('selected');
        }
        else{
            selected = $(elem).children().eq($(elem).children().length-1);
            if($(selected).attr('class').indexOf('hide')===-1){
                cy++;
            }
        }
        while((cy==0 && typeof $(selected).prev().attr('class') !=='undefined') || (typeof $(selected).prev().attr('class') !=='undefined' && $(selected).attr('class').indexOf('hide')!==-1) ){
            cy++;
            selected = $(selected).prev();
        }
        if($(selected).attr('class').indexOf('hide') !== -1){
            $.each($(elem).children(),function(ei,ee){
                if($(ee).attr('class').indexOf('hide') ===-1){
                    selected = ee;
                    return false;
                }
            });
        }
        $(selected).addClass('selected');
        $(selected)[0].scrollIntoView();
    },
    navdown:function(elem){
        this.provideautoco(elem);
        var selected = false;
        elem = $(elem).parent().next();
        var cy=0;
        if($(elem).children('.selected').length){
            selected = $(elem).children('.selected');
            $(selected).removeClass('selected');
        }
        else{
            selected = $(elem).children().eq(0);
            if($(selected).attr('class').indexOf('hide')===-1){
                cy++;
            }
        }
        
        while( (cy==0 && typeof $(selected).next().attr('class') !=='undefined') || (typeof $(selected).next().attr('class') !=='undefined' &&  $(selected).attr('class').indexOf('hide')!==-1)){
            cy++;
            selected = $(selected).next();
        }
        if($(selected).attr('class').indexOf('hide') !== -1){
            $.each($(elem).children(),function(ei,ee){
                if($(ee).attr('class').indexOf('hide') ===-1){
                    selected = ee;
                }
            });
        }
        $(selected).addClass('selected');
        $(selected)[0].scrollIntoView();
    },
    selectopt:function(elem){
        elem = $(elem).parent().next();
            
        var selected;
        if($(elem).children('.selected').length){
            selected = $(elem).children('.selected');
            this.fillform($(selected).attr('id').split('_')[1]);
        }
        
        $(elem).remove();
    },
    currentselected:false,
    fillform:function(idx){
        var idxeddata = {id:false,name:this.template[idx].name,description:this.template[idx].description,type:this.template[idx].type,date:this.template[idx].date,time:this.template[idx].time,duration:this.template[idx].duration,priority:this.template[idx].priority};
        this.currentselected = new activity(idxeddata);
        this.currentselected.date = $('#messagebox').find('.date').val();
        if(this.currentselected.time == 'false'){
            this.currentselected.time = $('#messagebox').find('.time').val();
        }
        this.currentselected.editform();
    },
    bluring:false,
    pageaction:function(){
        $('body').delegate('#messagebox .name','click focus',function(event){
            event.stopPropagation();
            
            registaforminputaction(this);
            if(dialogbox.title == 'Edit Preset' || dialogbox.title =='New Preset' || dialogbox.title == 'To Do'){
                return;
            }
            activtytemplate.provideautoco(this);
            activtytemplate.filteropt(this);
        });
        $('body').delegate('#messagebox .name','blur',function(event){
            event.stopPropagation();
            
            registaforminputaction(this);
            if(dialogbox.title == 'Edit Preset' || dialogbox.title =='New Preset'){
                return;
            }
            activtytemplate.bluring=this;
            setTimeout(function() {
                if(typeof $(activtytemplate.bluring).parent().next().attr('id') !=='undefined' && $(activtytemplate.bluring).parent().next().attr('id') == 'templateopts'){
                    $(activtytemplate.bluring).parent().next().remove();
                }
            }, 300);
        });
        $('body').delegate('#messagebox .name','keyup',function(event){
            event.stopPropagation();
            
            registaforminputaction(this);
            if(dialogbox.title == 'Edit Preset' || dialogbox.title =='New Preset'){
                return;
            }
            switch(event.which){
                case 13:
                    activtytemplate.selectopt(this);
                break;
                case 38:
                    activtytemplate.navup(this);
                break;
                case 40:
                    activtytemplate.navdown(this);
                break;
                default:
                    activtytemplate.filteropt(this);
            }
        });
        $('body').delegate('.templateopt','click',function(event){
            event.stopPropagation();
            
            $(this).siblings().removeClass('selected');
            $(this).addClass('selected');
            activtytemplate.selectopt($(this).parent().prev().children('input'));
        });
    }
};

function registaforminputaction(elem){
    if(typeof($(elem).attr('class')) !== 'undefined' && $(elem).attr('class').indexOf('filled') !== -1){
        return;
    }
    if(typeof($(elem).attr('name')) !== 'undefined') {
        var formarray = $(elem).attr('name').indexOf('[');
        if(formarray == -1){
            formarray = ($(elem).attr('name').length);
        }
        if($(elem).val() != $(elem).attr('name')){
            $(elem).addClass('filled');
        }
    }
}
function registaforminput(containerid,inputtypes){
    if(containerid === 'body'){
        containerid = 'body';
    }
    else{
        containerid = '#'+containerid;
    }
    var findselect = inputtypes.split(',');
    if($.inArray('select',findselect) !==-1){
        $(containerid).delegate('select','change',function(event){
            event.stopPropagation();
            if(typeof($(this).attr('class')) !== 'undefined' && $(this).attr('class').indexOf('filled') !== -1){
                return;
            }
            if(typeof($(this).attr('name')) !== 'undefined') {
                var formarray = $(this).attr('name').indexOf('[');
                if(formarray == -1){
                    formarray = ($(this).attr('name').length);
                }
                if($(this).val() != $(this).attr('name')){
                    $(this).addClass('filled');
                }
            }
        });
    }
     $(containerid).delegate(inputtypes,'click focus',function(event){
        event.stopPropagation();
        $(this).addClass('regiformfoc');
        if(typeof($(this).attr('class')) !== 'undefined' && $(this).attr('class').indexOf('filled') !== -1){
            return;
        }
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            
            if($(this).attr('name').indexOf('password') !== -1 ){
               $(this).prop('type','password'); 
            }
            
            if ($(this).val() === $(this).attr('name').substr(0,formarray)) {
                $(this).val('');
            }
        }
    });
    $(containerid).delegate(inputtypes,'keyup',function(event){
        event.stopPropagation();
        if(typeof($(this).attr('class')) !== 'undefined' && $(this).attr('class').indexOf('filled') !== -1){
            return;
        }
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            if($(this).val() != $(this).attr('name')){
                $(this).addClass('filled');
            }
        }
    });
    $(containerid).delegate(inputtypes,'blur',function(event){
        if(typeof($(this).attr('name')) !== 'undefined') {
            $(this).removeClass('regiformfoc');
            
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            if ($(this).val() === '') {
                if($(this).attr('name').indexOf('password') !== -1 ){
                    $(this).prop('type','text'); 
                 }
                $(this).val($(this).attr('name').substr(0,formarray));
                $(this).removeClass('filled');
            }
            else{
                if($(this).val() != $(this).attr('name').substr(0,formarray))
                    $(this).addClass('filled');
                else{
                    $(this).removeClass('filled');
                }
            }   
        }
    });
}

function tinythentinynow(textid){
    var tinymcesetting = {
        theme: "modern",
        height:350,
		plugins: [
			"advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
			"searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
			"save table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker codesample"
		],
		toolbar1: "fontselect fontsizeselect bold italic underline strikethrough alignleft aligncenter alignright alignjustify insertimage charmap outdent indent removeformat",
		toolbar2: "link unlink forecolor backcolor table hr subscript superscript bullist numlist image preview code emoticons emoticons emoticons",
		inline:true,
		add_unload_trigger: false,
		menubar: false,
        toolbar_items_size: 'small',
		style_formats: [
			{title: 'Bold text', inline: 'b'},
			{title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
			{title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
			{title: 'Example 1', inline: 'span', classes: 'example1'},
			{title: 'Example 2', inline: 'span', classes: 'example2'},
			{title: 'Table styles'},
			{title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
		],
		setup: function(ed) {
		    ed.on('Focus', function(){
			    if(!tinymce.activeEditor.isDirty() && $('#activdeta_'+pageaction.textcounter).attr('class').indexOf('filled') ===-1){
			        tinymce.activeEditor.setContent('');
			        tinymce.activeEditor.isNotDirty = true;
			    }
			});
			ed.on('Change', function(){
			    if(tinymce.activeEditor.isDirty())
			        $('#activdeta_'+pageaction.textcounter).addClass('filled dirty');
			});
			ed.on('Blur', function(){
			    var xx = tinymce.get('activdeta_'+pageaction.textcounter).getContent({format:'raw'}).split('<body>')[1];
			    xx = xx.split('</body>')[0];
			    if( (xx.indexOf('<p><br data-mce-bogus="1"></p>') !==-1 && xx.length==32) || (xx.indexOf('<p><br></p>')!==-1 && xx.length==13) ){
			        tinymce.get('activdeta_'+pageaction.textcounter).setContent('description');
			        setTimeout(function(){
    			        tinymce.get('activdeta_'+pageaction.textcounter).isNotDirty = true;
    			        $('.activdeta').removeClass('filled');    
			        },100);
			    }
			});
		}
    };
    tinymcesetting.selector = 'div#'+textid;
    var testiny = tinymce.init(tinymcesetting);
    if(tinyready=== false){
        testiny.then(function(){
            tinyready = true;
        },function(error){
        });   
    }
}

var mboxloading={
    inputblured:false,
    loading:function(inblu){
        this.inputblured = inblu;
        $('#messagebox').addClass('loading');
    },
    unload:function(){
        if(this.inputblured !==false){
            $(this.inputblured).focus();
            this.inputblured = false;
        }
        $('#messagebox').removeClass('loading');
    }
};
function mbox(boxtitle,boxcontent,boxaction,classtype){
    dialogbox = new messagebox();
    dialogbox.displayfunc(boxtitle,boxcontent,boxaction);
    $('#messagebox').removeClass('narrow extrawide xxl');
    if(classtype!=''){
        $('#messagebox').addClass(classtype);
    }
}