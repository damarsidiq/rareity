</div>

</body>

<script type="text/javascript">
    var ismobile=<?php echo $pagevar['ismobile']; ?>;
</script>
<?php $velp->printfootsrc(); ?>
</html>