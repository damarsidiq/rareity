<!DOCTYPE html><html>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<head>
    <meta charset="UTF-8">
    <link rel="canonical" href="http://localhost/vinetc">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="robots" content="all">
    <?php $velp->printheadsrc(); ?>
    <title></title>
    <script type="text/javascript">
    <?php 
        
        foreach($pagevar['alarms'] as $ak=>$av){
            echo "var ".$ak."url = '".trim($av)."';";
        }
    
    ?>
    </script>
</head>
<body>
    <div id="calitemtitletester"></div>
<div id="messagebox" class="">
    <div id="mboxtray"></div>
    <div id="mboxloading"></div>
    <div id="messageboxtitle"></div>
    <div id="messageboxcontent">
        <div id="messageboxmsg"></div>
        <div class="table">
            <div class="tablecell">
                
            </div>
        </div>
    </div>
    <div id="messageboxaction">
    </div>
</div>
<div id="pageloading" class="active"></div>
    <div id="scrollcontainer">