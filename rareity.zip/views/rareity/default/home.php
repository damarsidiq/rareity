<div id="dayinaweek" class="">
    <div id="hourheader">
        <div id="menu"><span id="currenttime">menu</span>
            <ul id="menuitems" class="">
                <li class="menuitem" id="fweek">&gt;</li>
                <li class="menuitem" id="bweek">&lt;</li>
                <li class="menuitem" id="goto">go to<?php if(!App::isMobile()){ ?><span class="menulab">ctrl+g</span><?php } ?></li>
                <li class="menuitem" id="gotonow">go to now<?php if(!App::isMobile()){ ?><span class="menulab">ctrl+n</span><?php } ?></li>
                <li class="menuitem" id="todo">to do list<?php if(!App::isMobile()){ ?><span class="menulab">ctrl+t</span><?php } ?></li>
                <li class="menuitem" id="coverview">cost overview<?php if(!App::isMobile()){ ?><span class="menulab">ctrl+c</span><?php } ?></li>
                <li class="menuitem" id="searchactivity">search activities<?php if(!App::isMobile()){ ?><span class="menulab">ctrl+f</span><?php } ?></li>
                <li class="menuitem" id="suggestact">suggest an activity<?php if(!App::isMobile()){ ?><span class="menulab">ctrl+s</span><?php } ?></li>
                <li class="menuitem" id="savedview">saved calendar<?php if(!App::isMobile()){ ?><span class="menulab">ctrl+z</span><?php } ?></li>
                <li class="menuitem" id="saveview">save calendar view<?php if(!App::isMobile()){ ?><span class="menulab">ctrl+v</span><?php } ?></li>
                <li class="menuitem" id="exportactivity">export to PDF<?php if(!App::isMobile()){ ?><span class="menulab">ctrl+p</span><?php } ?></li>
                <li class="menuitem" id="atempl">preset activities</li>
                <li class="menuitem" id="atypes">activity types</li>
                <li class="menuitem" id="viewopts">view options</li>
                <li class="menuitem" id="timecalc">time calc</li>
                <li class="menuitem" id="quitbro">quit</li>
            </ul>
        </div>
        <?php for($i=0;$i<24;$i++){?>
            <div class="anhour header anhour_<?php echo $i; ?>">
                <?php $h = strlen($i) == 1 ? '0'.$i.':00' : $i.':00';echo $h; ?>
            </div>
        <?php } ?>
    </div>
    <?php
        foreach($pagevar['dayinaweek'] as $k=>$v){
         ?>   
            
            <div class="aday <?php if($k==0) echo 'first'; ?>">
                <div class="theday <?php if($v->format('Y-m-d')== $pagevar['thisday']) echo 'thisday'; ?> <?php if($v->format('l')=='Sunday') echo 'sundae';?>"><div class="table"><div class="tablecell"><div class="addadeactiv"></div><?php echo $v->format('l').'<br/>'.$v->format('Y-m-d'); ?></div></div></div>
                <div class="hourinaday">
                    <?php for($i=0;$i<24;$i++){ ?>
                        <div class="anhour anhour_<?php echo $i; ?> <?php if($k==0 && $pagevar['thistime']==$i) echo 'thisthetime'; ?>"></div>
                    <?php  } ?>
                </div>  
            </div>  
           
         <?php 
        }
    ?>
</div>