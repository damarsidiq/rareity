const electron = require('electron')
const app = electron.app
const BrowserWindow = electron.BrowserWindow

let win

const {ipcMain} = require('electron')
ipcMain.on('asynchronous-message', (event, arg) => {
  if(arg.split('<edsep>')[0] == 'resetbro'){
    win.webContents.session.clearCache(function(){win.reload();});
  }
  else if(arg.split('<edsep>')[0] == 'quitbro'){
    win.destroy();
  }
})

function draw() {
    win = new BrowserWindow({icon:'/media/damarsidiq/pic/icons/rareityicon.png', width: 1334, height: 526,frame:false,resizable: true,y:0,x:2,webPreferences: {
      webSecurity: false
    } });
    win.setTitle('Rareity');
        //win.setMenu(null);
    win.setMenuBarVisibility(false);

    win.isMaximizable(false);
    win.isResizable(true);
    win.setAlwaysOnTop(false, "floating");
    win.loadURL('http://pxpedia/pxpedia/?app=rareity&d[electronapp]=1');
    win.webContents.session.clearCache(function(){});
    win.reload();
    win.show();
}
app.on('ready', draw)