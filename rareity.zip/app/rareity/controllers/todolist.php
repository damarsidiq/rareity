<?php 
Class Todolist extends Controller{
	function __construct(){
		parent::__construct();
	}
	public function fetchlist($data){
	    $list = $this->model('activity')->getrecords(array('parentactivity'=>-1),null,array('priority','desc'));
	    $this->setPagevar('response',$list);
	    return 'ajax';
	}
	public function submitform($data){
	    if($data['id']=='false'){
	        $this->createnew($data);
	    }
	    else{
	        $this->editold($data);
	    }
	    
	    return 'ajax';
	}
	public function editold($data){
	    $old = $data['id'];
	    unset($data['id']);
	    
	    $data['time'] = '1970-01-01 00:00:00';
	    $data['parentactivity'] = -1;
	    
	    $response['result'] = $this->model('activity')->updaterecord($data,array('id'=>$old));
	    
	    $this->setPagevar('response',$response);
	}
	public function createnew($data){
	    unset($data['id']);
	    
	    $data['time'] = '1970-01-01 00:00:00';
	    $data['parentactivity'] = -1;
	    
	    foreach($data as $k=>$v){
	       $keys[]=$k;
	       $vals[]=$v;
	    }
	    $response['result'] = $this->model('activity')->addrecord($keys,$vals); 
	    
	    $this->setPagevar('response',$response);
	}
}
