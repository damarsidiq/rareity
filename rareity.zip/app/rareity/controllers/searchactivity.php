<?php 
Class Searchactivity extends Controller{
	function __construct(){
		parent::__construct();
	}
	public function savedcal($data){
	    date_default_timezone_set("Asia/Jakarta");
	    
	    $actlistcount = array();
	    $data['saved'] = json_decode($data['saved']);
	    foreach($data['saved'] as $k=>$v){
	        if(strpos($v->viewmode,'_') !== false){
	            $data_['time'] = $v->startdate;
                $data_['range'] = $v->viewmode;
                $this->controller('activityc')->gotodatendays($data_);
                $calitem = $this->controller('activityc')->pagevar['response']['activities'];
	        }
	        else{
	            if($v->viewmode == 'monthly'){
	                $data_['time'] = $v->startdate;
                    $data_['range'] = 1;
                    $this->controller('activityc')->gotodate($data_);
                    $calitem = $this->controller('activityc')->pagevar['response']['activities'];  
	            }
	            else{
	                $data['startdate'] = $v->startdate;
	                $calitem = $this->model('activity')->getcalendar($data);
	            }
	        }
	        $actlistcount[] = count($calitem);
	    }
	    
	    $response['result'] = $actlistcount;
	    
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
	public function suggestactivity($data){
	    $response['results'] = array();
	    $q = 'select *,TIMESTAMP(DATE(time),"'. $data['time'] .'") AS ts from '.$this->model('activity')->table.' where parentactivity>-1 and duration >0 and duration <= '.$data['duration'];
	    if($data['type'] !='type'){
	        $q.= ' and type ='.$data['type'];
	    }
	    $q.=' group by name,duration,description order by if(HOUR(ts)>=18,if(if(TIMESTAMPDIFF(MINUTE,ts,time) < 0,TIMESTAMPDIFF(MINUTE,time,ts),TIMESTAMPDIFF(MINUTE,ts,time)) >1080,if(TIMESTAMPDIFF(MINUTE,ts,time) < 0,TIMESTAMPDIFF(MINUTE,time,ts),TIMESTAMPDIFF(MINUTE,ts,time)) %1080,if(TIMESTAMPDIFF(MINUTE,ts,time) < 0,TIMESTAMPDIFF(MINUTE,time,ts),TIMESTAMPDIFF(MINUTE,ts,time))),if(TIMESTAMPDIFF(MINUTE,ts,time) < 0,TIMESTAMPDIFF(MINUTE,time,ts),TIMESTAMPDIFF(MINUTE,ts,time)) )  ASC,duration desc,priority desc';
	    $q.= !isset($data['loadmore']) ? ' limit 0,20' : ' limit '.$data['loadmore'].',20';
	    $query = $this->model('activity')->query($q);
	    
	    if($query && count($query)){
	        $response['results'] = $this->fetchQueryResult($query);
	        foreach($response['results'] as $rk=>$rv){
	            $response['results'][$rk]['descriptiontext'] = $rv['description'] == '' ? '' : substr($rv['description'],0,50);
	        }
	    }
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
	public function getactivity($data){
	    $response['result'] = $this->model('activity')->getrecord(array('id'=>$data['id']));
	    
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
	public function submitsearch($data){
	    if($data['category'] !='category'){
	        $data['category'] = explode('~',$data['category']);
    	    foreach($data['category'] as $k=>$v){
    	        $data['category'][$k] = '"'.$v.'"';
    	    }
    	    $data['category'] = implode(',',$data['category']);   
	    }
	    
	    $q = 'select * from '.$this->model('activity')->table.' where parentactivity>-1';
	    if($data['keyword'] !='keyword'){
	        $q.=' and ';
	        $q .= '(name like "%'. $data['keyword'] .'%" or description like "%'.$data['keyword'].'%")';
	    }
	    if($data['startdate'] != 'start date'){
	        $q.=' and ';
	        $q.= 'time >="'.$data['startdate'].'"';
	    }
	    if($data['enddate'] != 'end date'){
	        $data['enddate'] = new DateTime($data['enddate']);
	        $data['enddate'] = $data['enddate']->add(new DateInterval('P1D'));
	        $q.=' and ';
	        $q.= 'time <="'.$data['enddate']->format('Y-m-d').'"';
	    }
	    if($data['category'] !='category'){
	        $q.=' and ';
	        $q.= 'type in('.$data['category'].')';
	    }
	    $q.= ' order by time asc';
	    
	    $qs = $this->query($q);
	    if($qs){
	     	$res = $this->fetchQueryResult($qs);
    	    if(count($res)){
    	        $response['results'] = $res;
    	    }
    	    else{
    	        $response['results'] = array();
    	    }   
	    }
	    
	    if(isset($data['pdfit'])){
	        return $response['results'];
	    }
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
}
