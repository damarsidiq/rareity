<?php 
Class Activtype extends Controller{
	function __construct(){
		parent::__construct();
	}
	
	public function submitedited($data){
	    $response['result'] = true;
        if($data['id']=='false'){
            unset($data['id']);
            $response['newinsert'] = $this->model('activitytype')->addrecord(array_keys($data),array_values($data));
            $response['debug'] = $this->model('activitytype')->printerrors(false);
            
        }
        else{
            $response['result'] = $this->model('activitytype')->updaterecord($data,array('id'=>$data['id']));
            $response['debug'] = $this->model('activitytype')->querystring();
        }
        
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function deletetype($data){
        $response['result'] = $this->model('activitytype')->deleterecord(array('id'=>$data['id']));
        
        
        $this->setPagevar('response',$response);
        return 'ajax';
    }
}
