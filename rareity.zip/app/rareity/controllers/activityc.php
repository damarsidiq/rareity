<?php 
Class Activityc extends Controller{
    var $thefuture;
	function __construct(){
		parent::__construct();
	}
	public function totodo($data){
	    $response['result'] = $this->model('activity')->updaterecord(array('parentactivity'=>-1),array('id'=>$data['id']));
	    $this->setPagevar('response',$response);
	    
	    return 'ajax';
	}
	public function deleteoftype($data){
	    $response['result'] = $this->model('activity')->deleterecord(array('type'=>$data['type']));
	    $this->setPagevar('response',$response);
	    
	    return 'ajax';
	}
	public function countactoftype($data){
	    $response['nactivities'] = $this->model('activity')->countrows(array('type'=>$data['type']));
	    $this->setPagevar('response',$response);
	    
	    return 'ajax';
	}
	public function gotoforward($data){
	    $data['time'] = new DateTime($data['time']);
	    if(strpos($data['range'],'_')!==false){
	        $daycount = explode('_',$data['range'])[0];
	        $data['time']->add(new DateInterval('P'.$daycount.'D'));
	        $data['time'] = $data['time']->format('Y-m-d');
	        return $this->gotodatendays($data);
	    }
	    else{
	        switch($data['range']){
    	       case 1:
    	           $data['time']->add(new DateInterval('P1M'));
    	       break;
    	       case 2:
    	           $data['time']->add(new DateInterval('P8D'));
    	       break;
    	    }   
	    }
	    $data['time'] = $data['time']->format('Y-m-d');
	    return $this->gotodate($data);
	}
	public function gotobackward($data){
	    $data['time'] = new DateTime($data['time']);
	     if(strpos($data['range'],'_')!==false){
	        $daycount = explode('_',$data['range'])[0];
	        $data['time']->sub(new DateInterval('P'.$daycount.'D'));
	        $data['time'] = $data['time']->format('Y-m-d');
	        return $this->gotodatendays($data);
	    }
	    switch($data['range']){
	       case 1:
	           $data['time']->sub(new DateInterval('P1M'));
	       break;
	       case 2:
	           $data['time']->sub(new DateInterval('P8D'));
	       break;
	    }
	    $data['time'] = $data['time']->format('Y-m-d');
	    return $this->gotodate($data);
	}
	public function gotodatendays($data){
	    $daycount = explode('_',$data['range'])[0];
	    $response = $data;
	    $dayinaweek=array();
        date_default_timezone_set("Asia/Jakarta");
        
        $dayinaweek[] = new DateTime($data['time']);
        $range = new DateTime($data['time']);
        $range->add(new DateInterval('P'.($daycount-1).'D'));
        
        $response['debug'] = $range->format('Y-m-d');
        $c=0;
        while($dayinaweek[$c]->format('Y-m-d') != $range->format('Y-m-d')){
            $dayinaweek[$c+1] = new DateTime($dayinaweek[$c]->format('Y-m-d'));
            $dayinaweek[$c+1]->add(new DateInterval('P1D'));
            $c++;
        }
        $this->setPagevar('dayinaweek',$dayinaweek);
        $this->setPagevar('thistime',$dayinaweek[0]->format('H'));
        $this->setPagevar('thisday',date('Y-m-d',time()));
        
        $range->add(new DateInterval('P1D'));
        $response['activities'] = $this->model('activity')->getcalendar(array('startdate'=>$dayinaweek[0]->format('Y-m-d'),'enddate'=>$range->format('Y-m-d')));
        
        $this->setPagevar('response',$response);
        $this->setPagevar('ajax',true);
        
	    return 'home';
	}
	public function gotodate($data){
	    $response = $data;
	    $dayinaweek=array();
        date_default_timezone_set("Asia/Jakarta");
        
        $dayinaweek[] = new DateTime($data['time']);
        $range = new DateTime($data['time']);
        if($data['range']==1){
            $range->add(new DateInterval('P1M'));
        }
        else{
            $range->add(new DateInterval('P7D'));
        }
        
        $c=0;
        while($dayinaweek[$c]->format('Y-m-d') != $range->format('Y-m-d')){
            $dayinaweek[$c+1] = new DateTime($dayinaweek[$c]->format('Y-m-d'));
            $dayinaweek[$c+1]->add(new DateInterval('P1D'));
            $c++;
        }
        $this->setPagevar('dayinaweek',$dayinaweek);
        $this->setPagevar('thistime',$dayinaweek[0]->format('H'));
        $this->setPagevar('thisday',date('Y-m-d',time()));
        
        $response['debug'] = $range->format('Y-m-d');
        $range->add(new DateInterval('P1D'));
        $response['activities'] = $this->model('activity')->getcalendar(array('startdate'=>$dayinaweek[0]->format('Y-m-d'),'enddate'=>$range->format('Y-m-d')));
        
        $this->setPagevar('response',$response);
        $this->setPagevar('ajax',true);
        
	    return 'home';
	}
	public function backupaweek($data){
	    $dayinaweek=array();
        date_default_timezone_set("Asia/Jakarta");
        
        if(isset($data['viewmode']) && $data['viewmode'] == 'monthly'){
            $dayinaweek[] = new DateTime($data['startdate']);
            $dayinaweek[0]->sub(new DateInterval('P1M'));
            
            $c=0;
            while($dayinaweek[$c]->format('Y-m-d') != $data['startdate']){
                $dayinaweek[$c+1] = new DateTime($dayinaweek[$c]->format('Y-m-d'));
                $dayinaweek[$c+1]->add(new DateInterval('P1D'));
                $c++;
            }
                $enddate = new DateTime($dayinaweek[$c]->format('Y-m-d'));
                $enddate->add(new DateInterval('P1D'));
                
            $response['activities'] = $this->model('activity')->getcalendar(array('startdate'=>$dayinaweek[0]->format('Y-m-d'),'enddate'=>$enddate->format('Y-m-d')));
        }
        else{
            $dayinaweek[] = new DateTime($data['startdate']);
            $dayinaweek[0]->sub(new DateInterval('P8D'));
            
            for($i=1;$i<8;$i++){
                $dayinaweek[$i] = new DateTime($dayinaweek[$i-1]->format('Y-m-d'));
                $dayinaweek[$i]->add(new DateInterval('P1D'));
            }   
            
            $response['activities'] = $this->model('activity')->getcalendar(array('startdate'=>$dayinaweek[0]->format('Y-m-d')));
        }
        $this->setPagevar('dayinaweek',$dayinaweek);
        $this->setPagevar('thistime',$dayinaweek[0]->format('H'));
        $this->setPagevar('thisday',$dayinaweek[0]->format('d'));
        
        $this->setPagevar('response',$response);
        $this->setPagevar('ajax',true);
        return 'home';
	}
	public function forwardaweek($data){
	    $dayinaweek=array();
        date_default_timezone_set("Asia/Jakarta");
        
         if(isset($data['viewmode']) && $data['viewmode'] == 'monthly'){
            $dayinaweek[] = new DateTime($data['startdate']);
            $dayinaweek[0]->add(new DateInterval('P1M'));
            
            $enddate = new DateTime($dayinaweek[0]->format('Y-m-d'));
            $enddate->add(new DateInterval('P1M'));
            $enddate->add(new DateInterval('P1D'));
            
            $c=0;
            while($dayinaweek[$c]->format('Y-m-d') != $enddate->format('Y-m-d')){
                $dayinaweek[$c+1] = new DateTime($dayinaweek[$c]->format('Y-m-d'));
                $dayinaweek[$c+1]->add(new DateInterval('P1D'));
                $c++;
            }
                
            $response['activities'] = $this->model('activity')->getcalendar(array('startdate'=>$dayinaweek[0]->format('Y-m-d'),'enddate'=>$enddate->format('Y-m-d')));
        }
        else{
            $dayinaweek[] = new DateTime($data['startdate']);
            $dayinaweek[0]->add(new DateInterval('P8D'));
            
            for($i=1;$i<8;$i++){
                $dayinaweek[$i] = new DateTime($dayinaweek[$i-1]->format('Y-m-d'));
                $dayinaweek[$i]->add(new DateInterval('P1D'));
            }
            $response['activities'] = $this->model('activity')->getcalendar(array('startdate'=>$dayinaweek[0]->format('Y-m-d')));   
        }
        
        $this->setPagevar('dayinaweek',$dayinaweek);
        $this->setPagevar('thistime',$dayinaweek[0]->format('H'));
        $this->setPagevar('thisday',$dayinaweek[0]->format('d'));
        
        $this->setPagevar('response',$response);
        $this->setPagevar('ajax',true);
        return 'home';
	}
	public function deleterecurring($data){
	    $c = $this->model('activity')->getrecord(array('parentactivity'=>$data['id']));
	    
	    if($c!==false){
	        $this->model('activity')->deleterecord(array('id'=>$c['id']));
	        $this->deleterecurring($c);
	    }
	}
	public function getthefuture($dataid){
	    $afuture = $this->model('activity')->getrecord(array('parentactivity'=>$dataid));
	    
	    if($afuture !==false){
	        $this->thefuture[] = $afuture;
	        $this->getthefuture($afuture['id']);
	    }
	}
	public function handle_edit_recurring($data,$iter,$weekly=array()){
	    if(isset($data['todolistitem'])){
	        return array();
	    }
	    if($data['id']!='false' && $data['id']!=0){
	        $check =$this->model('activity')->getrecords(array('parentactivity'=>$data['id']));
	        if(count($check)){
	            if($data['recurringtype']==0){
	                $this->deleterecurring($data);
	                return array('recurringedited'=>true,'deleterecurring'=>true);
	            }
	            else{
	                $recurringdate = DateTime::createFromFormat('Y-m-d H:i:s',$data['time']);
	                $dataid=$data['id'];
	                unset($data['id']);
	                unset($data['parentactivity']);
	                $editid=false;
	                
	                $this->thefuture = array();
	                $this->getthefuture($dataid);
	                $check = $this->thefuture;
                    foreach($check as $ck=>$cv){
                        switch($data['recurringtype']){
                           case 1:
                               $recurringdate->add(new DateInterval('P1Y'));
                           break;
                           case 2:
                               $recurringdate->add(new DateInterval('P1M'));
                           break;
                           case 3:
                               $recurringdate->add(new DateInterval('P1W'));
                           break;
                        }
                        $data['time']=$recurringdate->format('Y-m-d H:i:s');
                        if($data['recurringtype']==3 && $ck==0){
                            $this->model('activity')->updaterecord($data,array('id'=>$cv['id']));
                            $editid = $cv['id'];
                        }
                        else
                            $this->model('activity')->updaterecord($data,array('id'=>$cv['id']));
                    }
                    if($editid!==false){
                        return array('recurringedited'=>true,'weekly'=>$this->formatactivity($this->model('activity')->getrecord(array('id'=>$editid))));
                    }
	            }
	            return array('recurringedited'=>true);
	        }
	        else{
	            if($data['recurringtype']==3){
	                $recurringdate = DateTime::createFromFormat('Y-m-d H:i:s',$data['time']);
                    $recurringdate->add(new DateInterval('P1W'));
                    
                    $data['time']=$recurringdate->format('Y-m-d H:i:s');
                    unset($data['id']);
        
        	        $keys = array();
        	        $vals = array();
        	        foreach($data as $k=>$v){
        	            $keys[] = $k;
        	            $vals[] = $v;
        	        }
        	        $editid = $this->model('activity')->addrecord($keys,$vals);
        	        if($iter<3){
        	            $data['id'] = 0;
        	            $data['parentactivity'] = $editid;
        	            $weekly[] = $this->formatactivity($this->model('activity')->getrecord(array('id'=>$editid)));
        	            return $this->handle_edit_recurring($data,($iter+1),$weekly);
        	        }
        	        else{
        	            $weekly[] = $this->formatactivity($this->model('activity')->getrecord(array('id'=>$editid)));
        	            return array('recurringedited'=>true,'weekly'=>$weekly);
        	        }
	            }
	        }
	    }
	    else{
	        if($data['recurringtype']==3){
                $recurringdate = DateTime::createFromFormat('Y-m-d H:i:s',$data['time']);
                $recurringdate->add(new DateInterval('P1W'));
                
                $data['time']=$recurringdate->format('Y-m-d H:i:s');
                unset($data['id']);
    
    	        $keys = array();
    	        $vals = array();
    	        foreach($data as $k=>$v){
    	            $keys[] = $k;
    	            $vals[] = $v;
    	        }
    	        $editid = $this->model('activity')->addrecord($keys,$vals);
    	        if($iter<3){
    	            $data['id'] = 0;
    	            $data['parentactivity'] = $editid;
    	            $weekly[] = $this->formatactivity($this->model('activity')->getrecord(array('id'=>$editid)));
    	            return $this->handle_edit_recurring($data,($iter+1),$weekly);
    	        }
    	        else{
    	            $weekly[] = $this->formatactivity($this->model('activity')->getrecord(array('id'=>$editid)));
    	            return array('recurringedited'=>$editid,'weekly'=>$weekly);
    	        }
            }
	    }
	}
	public function submitform($data){
	    $data = $this->durationfix($data);
	    $response = $this->handle_edit_recurring($data,0);
	    if($data['id']=='false' || $data['id']==0){
	        unset($data['id']);
	        
	        $keys = array();
	        $vals = array();
	        foreach($data as $k=>$v){
               if($k=='description' && $v=='description'){
                    $v = '';
                }
	            $keys[] = $k;
	            $vals[] = $v;
	        }
	        $response['result'] = $this->model('activity')->addrecord($keys,$vals);
	        if(isset($response['recurringedited']) && $response['recurringedited'] && isset($response['weekly'])){
	            $parentdata = array('parentactivity'=>$response['result']);
	            $this->model('activity')->updaterecord($parentdata,array('id'=>$response['weekly'][0]['id']));
	            $response['weekly'][0]['parentactivity'] = $response['result'];
	        }
	    }
	    else{
	        $dataid = $data['id'];
	        unset($data['id']);
	        
	        if(isset($data['todolistitem'])){
	            $data['parentactivity'] = 0;
	            date_default_timezone_set("Asia/Jakarta");
	            unset($data['todolistitem']);
	            if(isset($data['startnow'])){
	                $data['time'] = date('Y-m-d H:i:s',time());
	                $response['time'] = $data['time'];
	                unset($data['startnow']);
	            }
	            $response['currenttimejs'] = date('m/d/Y H:i:s',time());
	        }
	        $response['result'] = $this->model('activity')->updaterecord($data,array('id'=>$dataid));
	    }
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
	public function formatactivity($data){
	    $data['date'] = explode(' ',$data['time'])[0];
        $data['time'] = explode(' ',$data['time'])[1];   
	    
	    return $data;
	}
	public function durationfix($data){
	    if($data['duration']=='all day'){
	        $data['duration'] = 1440;
	    }
	    return $data;
	}
	public function deleteact($data){
	    if(isset($data['todolistitem'])){
	        $response['result'] = $this->model('activity')->deleterecord(array('id'=>$data['id']));
	    }
	    else{
	     	$this->deleterecurring($data);
    	    if($data['recurringtype'] == 0){
    	        $response['result'] =$this->model('activity')->deleterecord(array('id'=>$data['id']));
    	    }
    	    else{
    	        $response['result'] = $this->model('activity')->deleterecord(array('id'=>$data['id']));
    	        $this->model('activity')->updaterecord(array('recurringtype'=>0),array('id'=>$data['parentactivity']));
    	    }   
	    }
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
}
