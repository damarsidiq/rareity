<?php
Class Ajax extends Controller{
    function __construct(){
        parent::__construct();
    }
    public function pagevarinit($data=false){
        date_default_timezone_set("Asia/Jakarta");
        $response['activtype']  = $this->model('activitytype')->activtype();
        $response['adeactivtype']  = $this->model('activitytype')->adeactivtype();
        $response['activities'] = $this->model('activity')->getcalendar($data);
        $response['currenttime'] = date('Y-m-d H:i:s',time());
        $response['currenttimejs'] = date('m/d/Y H:i:s',time());
        
        if(isset($data['viewmode']) && $data['viewmode']=='monthly'){
            $data['time'] = $data['startdate'];
            $data['range'] = 1;
            $this->controller('activityc')->gotodate($data);
            $this->pagevar = array_merge($this->pagevar,$this->controller('activityc')->pagevar);
            $this->pagevar['response'] = array_merge($this->pagevar['response'],$response);
            return 'home';
        }
        
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function pagereload($data){
        date_default_timezone_set("Asia/Jakarta");
        $response['activtype']  = $this->model('activitytype')->activtype();
        $response['adeactivtype']  = $this->model('activitytype')->adeactivtype();
        $response['activities'] = $this->model('activity')->getcalendar($data);
        $response['currenttime'] = date('Y-m-d H:i:s',time());
        $response['currenttimejs'] = date('m/d/Y H:i:s',time());
        
            $data['time'] = $data['startdate'];
            $data['range'] = $data['viewmode'] == 'monthly' ? 1 : 2;
            $this->controller('activityc')->gotodate($data);
            $this->pagevar = array_merge($this->pagevar,$this->controller('activityc')->pagevar);
            $this->pagevar['response'] = array_merge($this->pagevar['response'],$response);
            return 'home';
    }
}
?>