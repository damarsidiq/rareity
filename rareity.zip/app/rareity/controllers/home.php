<?php

Class Home extends Controller{
    function __construct() {
        parent::__construct();
    }
    public function cleanalarm($data){
        $data['url'] = explode('/',$data['url']);
        $loc = $data['url'][count($data['url'])-2].'/'.$data['url'][count($data['url'])-1];
        $loc = App::getConfig('uploads').$loc;
        
        unlink($loc);
        return 'plain';
    }
    public function uncachealarm_($type){
        $alarms = scandir(App::getConfig('uploads').'alarms');
        foreach($alarms as $ak=>$av){
            if(strpos($av,'alarm') !==false){
                $ax = explode('_',$av);
                if($ax[0] == $type){
                    return App::getConfig('uploads').'alarms/'.$av;
                }
            }
        }
    }
    public function uncachealarm($data){
        $data['alarmurl'] = explode('/',$data['alarmurl']);
        $thename = $data['alarmurl'][count($data['alarmurl'])-1];
        $thetype = explode('_',$thename)[0];
        
        $data['alarmurl'] = $this->uncachealarm_($thetype);
        
        $next = time();
        $nname = $thetype.'_'.$next.'.mp3';
        
        $copy = copy($data['alarmurl'],App::getConfig('uploads').'uncachealarm/'.$nname);
        if($copy){
            $response['success'] = true;
            $response['alarmurl'] = App::getConfig('uploads').'uncachealarm/'.$nname;
        }
        else{
            $response['success'] = false;
        }
        
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function prepuncachefolder(){
        if(!file_exists(App::getConfig('uploads').'uncachealarm')){
            $dir = mkdir(App::getConfig('uploads').'uncachealarm',0777);
            if(!$dir){
                return false;
            }
        }
        return true;
    }
    public function handlealarm(){
        $this->prepuncachefolder();
        $alarmvar = array();
        $alarms = scandir(App::getConfig('uploads').'alarms');
        foreach($alarms as $ak=>$av){
            if(strpos($av,'alarm') !==false){
                $ax = explode('_',$av);
                $alarmvar[$ax[0]] = App::getConfig('uploads').'alarms/'.$av;
            }
        }
        return $alarmvar;
    }
    public function pageInit($data=null,$view='home'){
        $this->setPagevar('alarms',$this->handlealarm());
        $dayinaweek=array();
        date_default_timezone_set("Asia/Jakarta");
        
        $dayinaweek[] = new DateTime(date('Y-m-d',time()));
        $dayinaweek[0]->setTimestamp(time());
        
        for($i=1;$i<8;$i++){
            $dayinaweek[$i] = new DateTime($dayinaweek[$i-1]->format('Y-m-d'));
            $dayinaweek[$i] = $dayinaweek[$i]->add(new DateInterval('P1D'));
        }
        $this->setPagevar('dayinaweek',$dayinaweek);
        $this->setPagevar('thistime',$dayinaweek[0]->format('H'));
        $this->setPagevar('thisday',date('Y-m-d',time()));
        
        if(App::isMobile()){
            $this->setPagevar('ismobile','true');
             $this->addheadfootsrc(false,array('mobile'=>App::getConfig('appviews').'/styles/mobile.css'));
        }
        else{
            $this->setPagevar('ismobile','false');
        }
        
	    return $view;
    }
    
}