<?php 
Class Spendly extends Controller{
    var $spendlyexists;
	function __construct(){
		parent::__construct();
		$this->spendlyexists = (count($this->model('spendlyblog')->db->errors) > 0 ? false : true );
	}
	
	public function reqbudgetinfo(){
	    $budgettotalobj = $this->model('spendlyblog')->entries(1,0,array('category'=>array('=',10)) , array('created','desc'));
        if(!count($budgettotalobj)){
            return 0;
        }
        foreach($budgettotalobj as $k=>$v){
            $budgettotal = $this->model('spendlyblogattribute')->attribute($v['id'],'amount');
            return $budgettotal;
        }
	}
	public function budgetinfo($data){
	    if(!$this->spendlyexists){
	        $response['result'] = 0;
	    }
	    else{
	        $response['result'] = $this->reqbudgetinfo();
	    }
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
}
