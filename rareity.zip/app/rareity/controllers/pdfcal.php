<?php 
Class Pdfcal extends Controller{
    var $types;
    var $timehead;
    var $localcat;
	function __construct(){
		parent::__construct();
		$this->localcat = array();
	}
	public function pdfdescript($type,$data,$content,$calitem){
	    $description = '';
	    switch($type){
	       case 'search':
	           	if($data['category'] !='category'){
        	        $data['category'] = explode('~',$data['category']);
            	    foreach($data['category'] as $k=>$v){
            	        $data['category'][$k] = $v;
            	    }
            	    $description .= '<span class="actattrtype header"><strong>Category</strong></span><span class="colon header">:</span><span class="actattrval header">'.$this->typeidtoname($data['category']).'</span><br/>';   
        	    }
        	    if($data['keyword'] !='keyword'){
        	        $description .= '<span class="actattrtype header"><strong>Keyword</strong></span><span class="colon header">:</span><span class="actattrval header">'.$data['keyword'].'</span><br/>';
        	    }
        	    if($data['startdate'] != 'start date'){
        	        $description .= '<span class="actattrtype header"><strong>Start</strong></span><span class="colon header">:</span><span class="actattrval header">'.$data['startdate'].'</span><br/>';
        	    }
        	    if($data['enddate'] != 'end date'){
        	        $description .= '<span class="actattrtype header"><strong>End</strong></span><span class="colon header">:</span><span class="actattrval header">'.$data['enddate'].'</span><br/>';
        	    }
        	    if($data['startdate'] != 'start date' && $data['enddate'] != 'end date'){
        	        $sd = new DateTime($data['startdate']);
        	        $ed = new DateTime($data['enddate']);
        	        $length = $ed->diff($sd,true);
        	        $length = $length->format('%a');
        	        $description .= '<span class="actattrtype header"><strong>Length</strong></span><span class="colon header">:</span><span class="actattrval header">'.$length.' days</span><br/>';
        	    }
	       break;
	       case 'calendar':
	           $description .= '<span class="actattrtype header"><strong>Start</strong></span><span class="colon header">:</span><span class="actattrval header">'.$data['startdate'].'</span><br/>';
	           $description .= '<span class="actattrtype header"><strong>Length</strong></span><span class="colon header">:</span><span class="actattrval header">'. ($data['range'] === 1 ? '1 Month' : ((strpos($data['range'],'_') !== false) ? $data['range'] : '1 Week')).'</span><br/>';
	       break;
	       case 'todolist':
	           
	       break;
	    }
	    
	    $totaldur = 0;
	    $totalcost = 0;
	    $idx = 0;
	    $sd=0;
	    $ed=0;
	    $num = count($calitem)-1;
	    $typecount = array();
	    $superlat = array();
	    foreach($calitem as $k=>$v){
	        $totaldur  += $v['duration'] == 1440 ? 0 : floatval($v['duration']);
	        $totalcost += floatval($v['cost']);
	        if(!count($superlat)){
	            $superlat['min'] = $v;
	            $superlat['max'] = $v;
	            
	            if($v['duration'] != 1440){
	             	$superlat['maxdur'] = $v;
	                $superlat['mindur'] = $v;   
	            }
	        }
	        else{
            	if($superlat['max']['cost'] < floatval($v['cost'])){
	                $superlat['max'] = $v;
	            }
	            if($superlat['min']['cost'] > floatval($v['cost'])){
	                $superlat['min'] = $v;
	            }
    	            

	            if($v['duration'] != 1440){
	                if(isset($superlat['maxdur'])){
        	            if($superlat['maxdur']['duration'] < $v['duration']){
        	                $superlat['maxdur'] = $v;
        	            }
        	            if($superlat['mindur']['duration'] > $v['duration']){
        	                $superlat['mindur'] = $v;
        	            }   
        	        }
        	        else{
        	            $superlat['maxdur'] = $v;
	                    $superlat['mindur'] = $v;   
        	        }
	            }
	        }
	        if($idx== 0){
	            $sd = new DateTime($v['time']);
	        }
	        else{
	            if($num == $idx){
	                $ed = new DateTime($v['time']);
	            }
	        }
	        $idx++;
	        
	        if(isset($this->types[$v['type']])){
    	        $typecount[$this->types[$v['type']]] = isset($typecount[$this->types[$v['type']]]) ? ($typecount[$this->types[$v['type']]]+1) : 1;
	        }
	        else{
	           if(isset($this->localcat[$v['type']]))
    	            $typecount[$this->localcat[$v['type']]] = isset($typecount[$this->localcat[$v['type']]]) ? ($typecount[$this->localcat[$v['type']]]+1) : 1;
	        }
	    }
	    $avgdivider = $ed->diff($sd,true);
	    $avgdivider = max(1,$avgdivider->format('%a'));
	    
	    $description .= '<br/><span class="actattrtype header"><strong>Total Activities</strong></span><span class="colon header">:</span><span class="actattrval header">'.number_format($num+1).'</span><br/>';
	    foreach($typecount as $tk=>$tv){
	        $description .= '<span class="actattrtype header"> - '.$tk.'</span><span class="colon header">:</span><span class="actattrval header">'.$tv.'</span><br/>';
	    }
	    $description .= '<br/>';
	    
	    $description .= '<span class="actattrtype header"><strong>Total Duration</strong></span><span class="colon header">:</span><span class="actattrval header">'.number_format($totaldur).' minutes</span><br/>';
	    $description .= '<span class="actattrtype header"> - Average</span><span class="colon header">:</span><span class="actattrval header">'.number_format($totaldur/($num+1)).' minutes</span><br/>';
	    
	    if($type!='todolist')
	    $description .= '<span class="actattrtype header"> - Average a Day</span><span class="colon header">:</span><span class="actattrval header">'.number_format($totaldur/$avgdivider).' minutes</span><br/>';
	    
	    $description .= '<span class="actattrtype header"> - Longest</span><span class="colon header">:</span><span class="actattrval header">'.number_format($superlat['maxdur']['duration']).' minutes</span><br/>';
	    $description .= '<span class="actattrtype header"> - Shortest</span><span class="colon header">:</span><span class="actattrval header">'.number_format($superlat['mindur']['duration']).' minutes</span><br/><br/>';
	    
	    if($type!='todolist'){
    	    $description .= '<span class="actattrtype header"><strong>Total Cost</strong></span><span class="colon header">:</span><span class="actattrval header">'.number_format($totalcost).'</span><br/>';
    	    $description .= '<span class="actattrtype header"> - Average</span><span class="colon header">:</span><span class="actattrval header">'.number_format($totalcost/($num+1)).'</span><br/>';
    	    $description .= '<span class="actattrtype header"> - Average a Day</span><span class="colon header">:</span><span class="actattrval header">'.number_format($totalcost/$avgdivider).'</span><br/>';
    	    $description .= '<span class="actattrtype header"> - Most Expensive</span><span class="colon header">:</span><span class="actattrval header">'.number_format($superlat['max']['cost']).'</span><br/>';
    	    $description .= '<span class="actattrtype header"> - Least Expensive</span><span class="colon header">:</span><span class="actattrval header">'.number_format($superlat['min']['cost']).'</span><br/>';
	    }
	    $description .= '<div class="descending"></div>';
	    
	    $description.='<br/><br/>';
	    
	    return $description.$content;
	}
    public function pdfsearch($data){
        $this->preplocalcat($data['localcat']);
        $response = array();
        $data['searchdata']['pdfit'] = true;
	    $calitem = $this->controller('searchactivity')->submitsearch($data['searchdata']);
	    $content = '';
	    
	    $calitem = $this->sortcalitem($calitem);
	    $content = $this->pdfcontent($calitem,0);
	    $content = $this->pdfdescript('search',$data['searchdata'],$content,$calitem);
	    
	    return $this->txtpdf(array('content'=>$content));
	}
	public function preptype($types){
	    $this->types = array();
	    foreach($types as $k=>$v){
	        $this->types[$v['id']] = $v['name'];
	    }
	}
	public function preplocalcat($data){
	    $te = json_decode($data);
	    if(count($te)){
	        foreach($te as $k=>$v){
	            $this->localcat[$v->id] = $v->name;
	        }
	    }
	}
	public function typeidtoname($id){
	   if(is_array($id)){
	       $cats = '';
	       foreach($id as $k=>$v){
	           if($cats != ''){
	               $cats.=', ';
	           }
	           $cats .= '"'.$this->typeidtoname($v).'"';
	       }
	       return $cats;
	   }
	   if(isset($this->types[$id]))
	        return $this->types[$id];
	        
	   if(isset($this->localcat[$id]))
	        return $this->localcat[$id];
	    
	   return $id;
	}
	public function sortcalitem($calitem){
	    uasort($calitem,function($a,$b){
	        
	        $atime = new DateTime($a['time']);
	        $btime = new DateTime($b['time']);
	        
            if($atime < $btime)
                return -1;
            elseif($atime == $btime)
                return 0;
            else
                return 1;
        });
        return $calitem;
	}
	public function fixdesc($desc){
	    return ($desc == '' || $desc == 'description') ? '---' : $desc;
	}
	public function timecontent($time){
	    if($time == '1970-01-01 00:00:00'){
	        return '';
	    }
	    $timehead = explode(' ',$time);
	    if($this->timehead != $timehead[0]){
	        $this->timehead = $timehead[0];
	        return '<span class="datetime header">'.$time.'</span>';
	    }
	    else{
	        return '<span class="datetime">'.$timehead[1].'</span>';
	    }
	}
	public function pdfcontent($calitem,$mode){
	    $types = $this->model('activitytype')->getrecords();
	    $this->preptype($types);
	    
	    $content = '';
	    $this->timehead = '';
	    if(count($calitem))
	    foreach($calitem as $k=>$v){
	        switch($mode){
	            case 0:
	                $content .= '<h3><span class="name">'.$v['name'].'</span>'.$this->timecontent($v['time']).'</h3>';
	                $content .= '<span class="actattrtype">id</span><span class="colon">:</span><span class="actattrval">'.$v['id'].'</span><br/><span class="actattrtype">type</span><span class="colon">:</span><span class="actattrval">'.$this->typeidtoname($v['type']).'</span><br/><span class="actattrtype">priority</span><span class="colon">:</span><span class="actattrval">'.$v['priority'].'</span><br/><span class="actattrtype">duration</span><span class="colon">:</span><span class="actattrval">'.$v['duration'].' minutes</span><br/><span class="actattrtype">cost</span><span class="colon">:</span><span class="actattrval">'.$v['cost'].'</span><br/><br/><p class="desc">'.$this->fixdesc($v['description']).'</p><div class="descending"></div>';
	            break;
	            case 1:
	                $content .= '<h3><span class="name">'.$v['name'].'</span>'.$this->timecontent($v['time']).'</h3>';
	                $content .= '<span class="actattrtype">id</span><span class="colon">:</span><span class="actattrval">'.$v['id'].'</span><br/><span class="actattrtype">type</span><span class="colon">:</span><span class="actattrval">'.$this->typeidtoname($v['type']).'</span><br/><span class="actattrtype">priority</span><span class="colon">:</span><span class="actattrval">'.$v['priority'].'</span><br/><span class="actattrtype">duration</span><span class="colon">:</span><span class="actattrval">'.$v['duration'].' minutes</span><br/><span class="actattrtype">cost</span><span class="colon">:</span><span class="actattrval">'.$v['cost'].'</span><br/><br/><p class="desc">'.$this->fixdesc($v['description']).'</p><div class="descending"></div>';
	            break;
	        }
	    }
	    return $content;
	}
    public function pdflist($data){
	    $response = array();
	    date_default_timezone_set("Asia/Jakarta");
	    $this->preplocalcat($data['localcat']);
        
        $calitem = $this->model('activity')->getrecords(array('parentactivity'=>-1),null,array('priority','desc'));
        
        $content = $this->pdfcontent($calitem,1);
        $content = $this->pdfdescript('todolist',$data,$content,$calitem);
        
	    return $this->txtpdf(array('content'=>$content));
	}
	public function pdfcalendar($data){
	    $response = array();
	    date_default_timezone_set("Asia/Jakarta");
	    $this->preplocalcat($data['localcat']);
        
        if(isset($data['viewmode']) && $data['viewmode']=='monthly'){
            $data['time'] = $data['startdate'];
            $data['range'] = 1;
            $this->controller('activityc')->gotodate($data);
            $calitem = $this->controller('activityc')->pagevar['response']['activities'];
        }
        else if(strpos($data['viewmode'],'_') !== false){
            $data['time'] = $data['startdate'];
            $data['range'] = $data['viewmode'];
            $this->controller('activityc')->gotodatendays($data);
            $calitem = $this->controller('activityc')->pagevar['response']['activities'];
        }
        else{
            $data['range'] = $data['viewmode'];
            $calitem = $this->model('activity')->getcalendar($data);
        }
        
        foreach($calitem as $k=>$v){
            $calitem[$k]['time'] = $v['date'].' '.$v['time'];
        }
        $calitem = $this->sortcalitem($calitem);
        $content = $this->pdfcontent($calitem,1);
        $type = 'calendar';
        
        $content = $this->pdfdescript($type,$data,$content,$calitem);
        
	    return $this->txtpdf(array('content'=>$content));
	}
	public function txtpdf($data){
        $this->preppdffolder();
        $pdf = @scandir(App::getConfig('uploads').'pdfcal');
        $pdfid = count($pdf);
        
        $handler = @fopen(App::getConfig('uploads').'pdfcal/'.$pdfid.'.txt','wb');
        fputs($handler,$data['content']);
        
        $response['pdfid']= $pdfid;
        $this->setPagevar('response',$response);
        return 'ajax';
    }
	public function preppdffolder(){
        if(!file_exists(App::getConfig('uploads').'pdfcal')){
            $dir = mkdir(App::getConfig('uploads').'pdfcal',0777);
            if(!$dir){
                return false;
            }
        }
        return true;
    }
	public function calendartxt($pdfid){
	    $repcontent = file_get_contents(App::getConfig('uploads').'pdfcal/'.$pdfid.'.txt');
        return $repcontent;
	}
	public function downloadpdf($data){
        $this->model('calpdf')->pdfcontent = $this->calendartxt($data['pdfid']);
        $this->model('calpdf')->outputdompdf();
    }
}
