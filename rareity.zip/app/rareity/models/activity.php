<?php 
Class Activity extends Model{
	function __construct(){
		parent::__construct('activity');
	}
	public function getovertimeline($data){
	    $overtime = array();
	    $end = new DateTime($data);
	    $end->sub(new DateInterval('P1D'));
	    $startdate = new DateTime($data);
	    
	    $q  = $this->query('select * from '.$this->table.' where parentactivity>-1 and time>="'.$end->format('Y-m-d').'" and time<"'.$startdate->format('Y-m-d').'"');
	    $r  = $this->fetchQueryResults($q);
	    foreach($r as $k=>$v){
	        if(($v['duration']/60) > (24-date('H',strtotime($v['time'])))-(date('i',strtotime($v['time']))/60) ){
	            $v['durationlineonly'] = true;
	            $v['date'] = explode(' ',$v['time'])[0];
	            $v['time'] = explode(' ',$v['time'])[1];
	            
	            $overtime[] = $v;
	        }
	    }
	    return $overtime;
	}
	public function getcalendar($data){
	    if(isset($data['enddate'])){
	        $start = new DateTime($data['startdate']);
    	    $end = new DateTime($data['enddate']);
    	    
    	    $startweekly    = new DateTime($data['startdate']);
    	    $startweekly->sub(new DateInterval('P7D'));
    	    $endweekly      = new DateTime($end->format('Y-m-d'));
    	    $endweekly->sub(new DateInterval('P1W'));
    	    
    	    $startmonthly   = new DateTime($data['startdate']);
    	    $startmonthly->sub(new DateInterval('P1M'));
    	    $endmonthly     = new DateTime($end->format('Y-m-d'));
    	    $endmonthly->sub(new DateInterval('P1M'));
    	    
    	    $startyearly    = new DateTime($data['startdate']);
    	    $startyearly->sub(new DateInterval('P1Y'));
    	    $endyearly      = new DateTime($end->format('Y-m-d'));
    	    $endyearly->sub(new DateInterval('P1Y'));        
	    }
	    else{
    	    $start = new DateTime($data['startdate']);
    	    if(isset($data['viewmode']) && $data['viewmode']=='monthly'){
    	        $end = new DateTime($data['startdate']);
    	        $end->add(new DateInterval('P1M'));
    	        $end->add(new DateInterval('P1D'));
    	    }
    	    else{
    	        $end = new DateTime($data['startdate']);
    	        $end->add(new DateInterval('P8D'));   
    	    }
    	    
    	    $startweekly    = new DateTime($data['startdate']);
    	    $startweekly->sub(new DateInterval('P7D'));
    	    $endweekly      = new DateTime($end->format('Y-m-d'));
    	    $endweekly->sub(new DateInterval('P1W'));
    	    
    	    $startmonthly   = new DateTime($data['startdate']);
    	    $startmonthly->sub(new DateInterval('P1M'));
    	    $endmonthly     = new DateTime($end->format('Y-m-d'));
    	    $endmonthly->sub(new DateInterval('P1M'));
    	    
    	    $startyearly    = new DateTime($data['startdate']);
    	    $startyearly->sub(new DateInterval('P1Y'));
    	    $endyearly      = new DateTime($end->format('Y-m-d'));
    	    $endyearly->sub(new DateInterval('P1Y'));    
	    }
	    
	    /*weekly*/
	    $q2 = $this->query('select * from '.$this->table.' where parentactivity>-1 and recurringtype=3 and time>="'.$startweekly->format('Y-m-d').'" and time<"'.$endweekly->format('Y-m-d').'"');
	    /*monthly*/
	    $q3 = $this->query('select * from '.$this->table.' where parentactivity>-1 and recurringtype=2 and time>="'.$startmonthly->format('Y-m-d').'" and time<"'.$endmonthly->format('Y-m-d').'"');
	    /*yearly*/
	    $q4 = $this->query('select * from '.$this->table.' where parentactivity>-1 and recurringtype=1 and time>="'.$startyearly->format('Y-m-d').'" and time<"'.$endyearly->format('Y-m-d').'"');

	    $r2  = $this->fetchQueryResults($q2);
	    $s2  = array();
	    if(count($r2))
	    foreach($r2 as $rk=>$rv){
	        //echo print_r($rv,true).'@@@@@@';
	        $r2[$rk] = $this->recurringevent(array($rv),$data['startdate'],$end->format('Y-m-d'));
	    }
	    
	    $r3  = $this->fetchQueryResults($q3);
	    $s3  = array();
	    if(count($r3))
	    foreach($r3 as $rk=>$rv){
	        $r3[$rk] = $this->recurringevent(array($rv),$data['startdate'],$end->format('Y-m-d'));
	    }
	    
	    $r4  = $this->fetchQueryResults($q4);
	    $s4  = array();
	    if(count($r4))
	    foreach($r4 as $rk=>$rv){
	        $r4[$rk] = $this->recurringevent(array($rv),$data['startdate'],$end->format('Y-m-d'));
	    }
	    
	    /*rareity*/
	    $q  = $this->query('select * from '.$this->table.' where parentactivity>-1 and time>="'.$data['startdate'].'" and time<"'.$end->format('Y-m-d').'"');
	    $r  = $this->fetchQueryResults($q);
	    //echo  'select * from '.$this->table.' where time>="'.$data['startdate'].'" and time<"'.$end->format('Y-m-d').'"###'.count($r).'!!!';
	    if(count($r))
	    foreach($r as $rk=>$rv){
	        $r[$rk]['date'] = explode(' ',$r[$rk]['time'])[0];
	        $r[$rk]['time'] = explode(' ',$r[$rk]['time'])[1];
	    }
	    $r = array_merge($r,$this->getovertimeline($start->format('Y-m-d')));
	    
	    return $r;
	}
	
	public function recurringevent($recurrings,$start,$end){
	    $startobj = new DateTime($start);
	    $endobj =  new DateTime($end);
	    
	    $rv = $recurrings[count($recurrings)-1];
	    
	    $q  = $this->query('select * from '.$this->table.' where time>="'.$start.'" and time<"'.$end.'" and parentactivity='.$rv['id']);
	    $r  = $this->fetchQueryResults($q);
	    //echo 'select * from '.$this->table.' where time>="'.$start.'" and time<"'.$end.'" and parentactivity='.$rv['id'].'~~~~~~~';
	    if(count($r)){
	        $recurrings[] = $r[0];
	        $rv = $recurrings[count($recurrings)-1];
	        
                $newtime = DateTime::createFromFormat('Y-m-d H:i:s',$rv['time']);
                switch($rv['recurringtype']){
                    case 1:
                        $newtime->add(new DateInterval('P1Y'));
                    break;
                    case 2:
                        $newtime->add(new DateInterval('P1M'));
                    break;
                    case 3:
                        $newtime->add(new DateInterval('P1W'));
                    break;
                }
                
                //echo $newtime->format('Y-m-d H:i:s');
            	if($newtime <= $endobj && $newtime >= $startobj){
                    return $this->recurringevent($recurrings,$start,$end);
                }
                else{
                    return array(false,$recurrings);   
                }
	    }
	    else{
	     	$newtime = '';
        	$keys = array('parentactivity');
            $vals = array($rv['id']);
            $rv['parentactivity']=$rv['id'];
            unset($rv['id']);
            foreach($rv as $k=>$v){
                if($k=='parentactivity'){
                    
                }
                elseif($k=='time'){
                    $keys[] = $k;
                    $newtime = DateTime::createFromFormat('Y-m-d H:i:s',$v);
                    switch($rv['recurringtype']){
                        case 1:
                            $newtime->add(new DateInterval('P1Y'));
                            $vals[] = $newtime->format('Y-m-d H:i:s');
                            
                            $nexttime    = new DateTime($newtime->format('Y-m-d'));
        	                $nexttime->add(new DateInterval('P1Y'));
                        break;
                        case 2:
                            $newtime->add(new DateInterval('P1M'));
                            $vals[] = $newtime->format('Y-m-d H:i:s');
                            
                            $nexttime    = new DateTime($newtime->format('Y-m-d'));
        	                $nexttime->add(new DateInterval('P1M'));
                        break;
                        case 3:
                            $newtime->add(new DateInterval('P1W'));
                            $vals[] = $newtime->format('Y-m-d H:i:s');
                            
                            $nexttime    = new DateTime($newtime->format('Y-m-d'));
        	                $nexttime->add(new DateInterval('P1W'));
                        break;
                    }
                }
                else{
                    if($k=='description' && $v=='description'){
                        $v = '';
                    }
                    $keys[] = $k;
                    $vals[] = $v;   
                }
            }
    	    $add = $this->addrecord($keys,$vals);
    	    if($add){
    	        $rv['id']=$add;
    	        $rv['time']=$newtime->format('Y-m-d H:i:s');
    	            
	            $recurrings[] = $rv;
	            
	            if($nexttime <= $endobj && $nexttime >= $startobj){
	                //echo $nexttime->format('Y-m-d H:i:s').'^^^^^';
                    return $this->recurringevent($recurrings,$start,$end);
                }
                else{
                    //echo $nexttime->format('Y-m-d H:i:s').'$$$$$';
                    return array(false,$recurrings);   
                }
    	    }
    	    else{
    	        return $this->printerrors(false);
    	    }   
	    }
	}
}
?>
