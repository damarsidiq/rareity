<?php 
Class Activitytype extends Model{
	function __construct(){
		parent::__construct('activitytype');
	}
	public function activtype(){
	    return $this->getrecords(array('ade'=>0));
	}
	public function adeactivtype(){
	    return $this->getrecords(array('ade'=>1));
	}
}
?>
