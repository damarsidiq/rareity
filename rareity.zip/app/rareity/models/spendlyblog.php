<?php 
Class Spendlyblog extends Model{
    function __construct(){
        parent::__construct('blog',App::getappid('spendly'));
    }
    
    public function entries($limit=30,$offset=0,$conditions=false,$order=array('id','desc'),$fields=null){
        $condi = array('status'=>1);
        if($conditions !== false){
            $condi = array_merge($condi,$conditions);
        }
        $blogs = $this->getrecords($condi,$fields,$order,$offset.','.$limit);
        return $blogs;
    }
}
?>
