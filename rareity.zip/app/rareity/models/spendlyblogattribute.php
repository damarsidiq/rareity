<?php 
Class Spendlyblogattribute extends Model{
	function __construct(){
		parent::__construct('blogattribute',App::getappid('spendly'));
	}
	/**
	 * attribute. get blog entry attribute
	 *
	 * @param int $blogid the blog ID
	 * @param string $attrkey the blog attribute name
	 * 
	 * @return array
	 */
    public function attribute($blogid,$attrkey=false){
        if($attrkey === false)
            return $this->getrecord(array('blogid'=>$blogid),'value');
        
        return $this->getrecord(array('blogid'=>$blogid,'attrkey'=>$attrkey),'value');
    }
    /**
	 * blogattributes. get blog entry attributes
	 *
	 * @param int $blogid the blog ID
	 * 
	 * @return array
	 */
    public function blogattributes($blogid){
        $attributes = $this->getrecords(array('blogid'=>$blogid),array('attrkey','value'));
        
        return $attributes;
    }
}
?>
