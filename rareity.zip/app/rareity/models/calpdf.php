<?php 
Class Calpdf extends Model{
    var $pdfheader;
    var $pdfcontent;
    
	function __construct(){
		parent::__construct();
		
        $this->pdfheader    = '<style type="text/css">
                    <!--
                        html{font-family:Arial;font-size:12px}
                        li{padding:0px;margin:5px 0px;}
                        p{display: block;margin-bottom: 1em;margin-top: 1em;}
                        ul{padding:0px;margin:0px;}
                        .name{display:inline-block;position:absolute;left:0px;color:#404040;line-height:15px;}
                        .datetime{display:inline-block;position:absolute;right:0px;color:#404040;line-height:15px;font-weight:normal}
                        .datetime.header{font-weight:bold;}
                        .desc{margin-bottom:5px;padding-bottom:5px;height:auto;}
                        .descending{border-bottom: 2px solid #ebebeb;height:20px;width:100%;margin-bottom:15px;}
                        h3{padding:0px;margin:0px;margin-bottom:5px;border-bottom:1px solid #bdbdbd;height:15px;}
                        .actattrtype{width:63px;display:block;float:left;}
                        .actattrtype.header{width:135px;}
                        .actattrval{width:auto;}
                        .colon{width:auto;margin-right:3px;}
                    -->
                    </style>';
        
        $this->undecoded = array('&apos;','&lt;','&gt;');
        $this->undecodedreplacement = array('','(',')');
        $this->pdfcontent = '';
	}
	public function cleanstr($str,$setlandscape=false){
         //return str_replace(array('<figcaption','figcaption>','<figure','figure>','<section','section>','<aside','aside>'),array('<p','p>','<p','p>','<div','div>','<div','div>'),htmlspecialchars_decode(str_replace($this->undecoded,$this->undecodedreplacement,$str),ENT_QUOTES));
         $cs = htmlspecialchars_decode(str_replace($this->undecoded,$this->undecodedreplacement,$str),ENT_QUOTES);

         return $cs;
    }
	 public function outputdompdf(){
        require_once Pxpedia::getConfig('resources').'dompdf/lib/html5lib/Parser.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-svg-lib/src/autoload.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Autoloader.php';


        require_once Pxpedia::getConfig('resources').'dompdf/src/CanvasFactory.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Options.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Dompdf.php';
        Dompdf\Autoloader::register();

        $dompdf = new Dompdf\Dompdf();
        
        $this->pdfcontent = $this->cleanstr($this->pdfcontent);
        
        $dompdf->loadHtml($this->pdfheader.$this->pdfcontent);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        //echo $this->pdfheader.$this->pdfcontent;
        $this->pdfcontent = '';
        //exit();

        $dompdf->stream('calendar.pdf');
    }
}
?>
